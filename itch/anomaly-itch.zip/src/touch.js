// Touch controls for phones and tablets: a floating joystick under the left thumb, drag-to-aim on the right,
// and a cluster of action buttons. The layer turns on at the first touch and off again on keyboard or pad input.
import { $, clamp } from './util.js';
import { G, P, input } from './state.js';
import { settings } from './settings.js';
import { slash, hellfire, startReload } from './combat.js';
import { throwKatana } from './blade.js';
import { pauseGame } from './game.js';

/** Keep getting a finger's moves even when it slides off the element (a capture can fail; the control still works). */
const capture = (el, id) => { try { el.setPointerCapture(id); } catch { /* not capturable */ } };

let on = false;
export const touchMode = () => on;
function setMode(v) {
  if (on === v) return;
  on = v; document.body.classList.toggle('touch', v);
  if (!v) { input.touch.x = input.touch.y = 0; input.fire = false; input.slashHeld = false; }
}

const LOOK = 0.0048, STICK = 56; // radians per pixel of drag; joystick radius in px
const BUTTONS = [
  // [id, label, press, release]
  ['fire', 'Fire', () => { input.fire = true; }, () => { input.fire = false; }],
  ['jump', 'Jump', () => { input.jump = true; }],
  ['slash', 'Blade', () => { slash(); input.slashHeld = true; }, () => { input.slashHeld = false; }],
  ['dive', 'Dive', () => { input.dive = true; }],
  ['focus', 'Slow', () => { input.focusToggle = !input.focusToggle; }],
  ['reload', 'Reload', () => startReload()],
  ['throw', 'Throw', () => throwKatana()],
  ['hellfire', 'Hellfire', () => hellfire()],
];

function build() {
  const layer = document.createElement('div'); layer.id = 'touch';
  const stick = document.createElement('div'); stick.className = 'tstick'; stick.innerHTML = '<i></i>';
  const cluster = document.createElement('div'); cluster.className = 'tbuttons';
  for (const [id, label, down, up] of BUTTONS) {
    const b = document.createElement('button'); b.type = 'button'; b.className = 'tbtn t-' + id; b.textContent = label;
    b.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); capture(b, e.pointerId); b.classList.add('down'); if (G.mode === 'play') down(); });
    const release = e => { b.classList.remove('down'); if (up) up(); };
    b.addEventListener('pointerup', release); b.addEventListener('pointercancel', release);
    cluster.append(b);
  }
  const pause = document.createElement('button'); pause.type = 'button'; pause.className = 'tpause'; pause.textContent = 'II'; pause.setAttribute('aria-label', 'Pause');
  pause.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); pauseGame(); });
  layer.append(stick, cluster, pause);
  $('hud').append(layer);
  return { layer, stick, knob: stick.firstChild };
}

export function bindTouch() {
  const ui = build();
  let stickId = null, lookId = null, ox = 0, oy = 0, lx = 0, ly = 0;
  // the empty screen: left half steers, right half aims
  ui.layer.addEventListener('pointerdown', e => {
    if (e.pointerType !== 'touch' || G.mode !== 'play') return;
    e.preventDefault();
    if (e.clientX < innerWidth * 0.45 && stickId === null) {
      stickId = e.pointerId; ox = e.clientX; oy = e.clientY;
      ui.stick.style.left = ox + 'px'; ui.stick.style.top = oy + 'px'; ui.stick.classList.add('live');
    } else if (lookId === null) { lookId = e.pointerId; lx = e.clientX; ly = e.clientY; }
    capture(ui.layer, e.pointerId);
  });
  ui.layer.addEventListener('pointermove', e => {
    if (e.pointerId === stickId) {
      let dx = e.clientX - ox, dy = e.clientY - oy; const d = Math.hypot(dx, dy);
      if (d > STICK) { dx *= STICK / d; dy *= STICK / d; }
      ui.knob.style.transform = `translate(${dx}px, ${dy}px)`;
      input.touch.x = dx / STICK; input.touch.y = -dy / STICK;
    } else if (e.pointerId === lookId && G.mode === 'play') {
      const inv = settings.invertY === 'on' ? -1 : 1, k = LOOK * settings.mouseSens;
      P.yaw -= (e.clientX - lx) * k; P.pitch = clamp(P.pitch - (e.clientY - ly) * k * inv, -1.25, 1.2);
      lx = e.clientX; ly = e.clientY;
    }
  });
  const end = e => {
    if (e.pointerId === stickId) { stickId = null; input.touch.x = input.touch.y = 0; ui.knob.style.transform = ''; ui.stick.classList.remove('live'); }
    if (e.pointerId === lookId) lookId = null;
  };
  ui.layer.addEventListener('pointerup', end); ui.layer.addEventListener('pointercancel', end);
  // switch the layer on at the first touch, off when a keyboard or controller takes over
  addEventListener('pointerdown', e => { if (e.pointerType === 'touch') setMode(true); }, true);
  addEventListener('keydown', () => setMode(false), true);
  addEventListener('gamepadconnected', () => setMode(false));
}
