// HUD and screens: bars, counters, banners, callouts, floating score popups.
import { camera } from './engine.js';
import { $, pad, V3 } from './util.js';
import { T, POWER } from './config.js';
import { G, P, world, input } from './state.js';
import { level } from './physics.js';
import { topScore } from './scores.js';
import { announce } from './audio.js';

const el = {
  hud: $('hud'), menu: $('menu'), pause: $('pause'), over: $('over'),
  waveN: $('waveN'), remain: $('remain'), score: $('score'), hi: $('hi'), hpN: $('hpN'), fcN: $('fcN'),
  hp: $('hpBar'), hpI: $('hpBar').firstElementChild, fcI: $('focusBar').firstElementChild,
  ammo: $('ammo'), reload: $('reloadMsg'), xh: $('xh'), hitm: $('hitm'), feed: $('feed'),
  banner: $('banner'), hint: $('hint'), tmode: $('tmode'), callout: $('callout'), pops: $('pops'),
  lives: $('lives'), bombs: $('bombs'), comboBox: $('comboBox'), comboN: $('comboN'), comboI: $('comboBox').querySelector('.bar i'),
  boss: $('boss'), bossI: $('boss').querySelector('.bar i'), bossL: $('boss').querySelector('.lbl'), power: $('power'),
  lockHint: $('lockHint'),
};

/** Show exactly one of: 'menu', 'play' (HUD), 'pause' (HUD behind), 'over'. */
export function showScreen(name) {
  el.menu.hidden = name !== 'menu';
  el.pause.hidden = name !== 'pause';
  el.over.hidden = name !== 'over';
  el.hud.hidden = !(name === 'play' || name === 'pause');
  if (name !== 'play') document.body.classList.remove('cinema');
}

let hitTimer = 0;
export function flashHit(kill) {
  el.hitm.classList.add('on'); el.hitm.classList.toggle('kill', kill);
  clearTimeout(hitTimer); hitTimer = setTimeout(() => el.hitm.classList.remove('on'), kill ? 220 : 90);
}
export function addFeed(tags) {
  if (!tags.length) return;
  const row = document.createElement('div'); row.className = 'kill';
  for (const tag of tags) { const s = document.createElement('span'); s.className = 'tag'; s.textContent = tag; row.append(s); }
  el.feed.prepend(row);
  while (el.feed.children.length > 4) el.feed.lastChild.remove();
  setTimeout(() => { row.style.opacity = '0'; setTimeout(() => row.remove(), 400); }, 2500);
}
function restartAnimation(node) { node.classList.remove('on'); void node.offsetWidth; node.classList.add('on'); }
let bannerTimer = 0;
export function banner(text, sub = '', ms = 2200) {
  el.banner.textContent = text;
  if (sub) { const s = document.createElement('small'); s.textContent = sub; el.banner.append(s); }
  restartAnimation(el.banner);
  clearTimeout(bannerTimer); bannerTimer = setTimeout(() => el.banner.classList.remove('on'), ms);
  announce(text === 'warning' && sub ? `warning. ${sub}` : text.replace(/\bwave 0*(\d+)/, 'wave $1'));
}
export function callout(text) { el.callout.textContent = text; restartAnimation(el.callout); announce(text.replace(/^NEW THREAT: /, 'new threat. ')); }
export function hint(text, ms = 5000) {
  el.hint.textContent = text; el.hint.classList.add('on');
  setTimeout(() => el.hint.classList.remove('on'), ms);
}

// ---- floating text anchored to a world position
let pops = [];
const proj = new V3();
export function popup(pos, text, cls = '') {
  const node = document.createElement('div'); node.className = 'pop ' + cls; node.textContent = text;
  el.pops.append(node); pops.push({ node, p: pos.clone(), t: 0 });
}
export function updatePops(dt) {
  for (let i = pops.length - 1; i >= 0; i--) {
    const o = pops[i]; o.t += dt; o.p.y += dt * 1.1;
    if (o.t > 1.2) { o.node.remove(); pops.splice(i, 1); continue; }
    proj.copy(o.p).project(camera);
    if (proj.z > 1) { o.node.style.opacity = '0'; continue; }
    const x = (proj.x * 0.5 + 0.5) * innerWidth, y = (-proj.y * 0.5 + 0.5) * innerHeight;
    o.node.style.transform = `translate(${x}px,${y}px) translate(-50%,-50%) scale(${1 + Math.max(0, 0.25 - o.t) * 3})`;
    o.node.style.opacity = o.t > 0.85 ? String((1.2 - o.t) / 0.35) : '1';
  }
}
export function clearHudEffects() {
  for (const o of pops) o.node.remove();
  pops = [];
  el.feed.textContent = '';
  shown.lives = shown.hellfire = -1;
}

// ---- per-frame HUD
const shown = { lives: -1, hellfire: -1 };
function icons(node, n, cls) {
  node.textContent = '';
  for (let i = 0; i < Math.max(3, n); i++) { const d = document.createElement('i'); d.className = cls + (i < n ? '' : ' off'); node.append(d); }
}
export function updateHUD() {
  const alive = world.soldiers.filter(s => !s.dead && !s.idle).length + world.drones.filter(d => !d.dead).length;
  const left = alive + G.toSpawn + (G.bossPending ? 1 : 0);
  el.waveN.textContent = 'WAVE ' + pad(G.wave, 2);
  el.remain.textContent = `${level.info.label} · ${left} soldier${left === 1 ? '' : 's'} left`;
  el.score.textContent = pad(G.score, 7);
  el.hi.textContent = 'HI ' + pad(Math.max(G.score, topScore()), 7);
  if (G.lives !== shown.lives) { shown.lives = G.lives; icons(el.lives, G.lives, 'life'); }
  if (G.hellfire !== shown.hellfire) { shown.hellfire = G.hellfire; icons(el.bombs, G.hellfire, 'bomb'); }
  const comboLeft = T.comboWindow - (G.clock - G.lastKill);
  const comboOn = G.combo > 1 && comboLeft > 0;
  el.comboBox.classList.toggle('on', comboOn);
  if (comboOn) { el.comboN.textContent = '×' + G.combo; el.comboI.style.width = (comboLeft / T.comboWindow * 100) + '%'; }
  const boss = world.soldiers.find(s => s.boss && !s.dead && s.spawnT <= 0);
  el.boss.hidden = !boss;
  if (boss) {
    el.bossI.style.width = Math.max(0, boss.hp / boss.maxHp * 100) + '%';
    const plates = boss.armor ? boss.armor.filter(a => a.hp > 0).length : 0;
    const label = 'Juggernaut' + (plates ? '  ·  armor ' + '■'.repeat(plates) : boss.bs && boss.bs.state === 'stun' ? '  ·  stunned' : '');
    if (el.bossL.textContent !== label) el.bossL.textContent = label;
  }
  el.power.hidden = !(P.powerT > 0 && P.power);
  if (!el.power.hidden) el.power.textContent = `${POWER[P.power].label} ${Math.ceil(P.powerT)}`;
  const hp = Math.max(0, Math.ceil(P.hp));
  el.hpN.textContent = hp; el.hpI.style.width = hp + '%'; el.hp.classList.toggle('low', hp < 35);
  el.fcN.textContent = Math.floor(P.focus); el.fcI.style.width = P.focus + '%';
  el.ammo.firstChild.nodeValue = (G.daily && G.daily.mod === 'katana' ? 'BLADE' : P.powerT > 0 && P.power === 'rapid' ? '∞' : P.ammo) + ' ';
  el.reload.textContent = P.reloadT > 0 ? 'RELOADING' : P.dashCd > 0 ? `DASH ${Math.ceil(P.dashCd)}` : '';
  // crosshair opens up with speed, tightens in slow motion
  const hv = Math.hypot(P.vel.x, P.vel.z);
  const gap = G.focusActive || P.diveT > 0 ? 5 : 7 + Math.min(hv / 9.5, 1) * 8 + (P.grounded ? 0 : 5);
  const [u, d, l, r] = el.xh.children;
  u.style.top = (-gap - 8) + 'px'; d.style.top = gap + 'px'; l.style.left = (-gap - 8) + 'px'; r.style.left = gap + 'px';
  el.tmode.classList.toggle('on', G.focusActive || P.diveT > 0);
  // the mouse isn't captured (lock refused or lost) but is being used to aim: ask for a click before it wanders off
  el.lockHint.classList.toggle('on', G.mode === 'play' && !document.pointerLockElement && performance.now() - input.mouseAt < 4000);
}
