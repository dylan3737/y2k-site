// World leaderboard: each player's best run, shared with everyone who can open the published game.
// Lives in the artifact's db (one document per player at leaderboard/<their id>). Anywhere that
// isn't available (a local copy, a viewer without access) the game just shows the local table.
import { pad } from './util.js';
import { todayKey } from './daily.js';

const TOP = 10;
let db = null, uid = null, writable = true;
let top = [], mine = null, daily = [];
const listeners = [];

/** Connect when the page is running as a published artifact; calls onChange whenever the board moves. */
export async function initLeaderboard(onChange) {
  listeners.push(onChange);
  if (!window.claude || typeof window.claude.use !== 'function') return;
  const [d, user] = await Promise.all([window.claude.use('db'), window.claude.use('user')]);
  if (!d) return;
  db = d;
  uid = user ? await user.id() : null;
  if (user && (await user.can('data.write')) === false) writable = false;
  db.collection('leaderboard').orderBy('s', 'desc').limit(TOP).onSnapshot(
    snap => { top = snap.docs.map(doc => ({ ...doc.data(), id: doc.id })); notify(); },
    () => { db = null; notify(); },
  );
  // today's challenge board: the same documents, filtered to today's date
  db.collection('leaderboard').where('dailyDate', '==', todayKey()).orderBy('dailyScore', 'desc').limit(TOP).onSnapshot(
    snap => { daily = snap.docs.map(doc => ({ ...doc.data(), id: doc.id })); notify(); },
    () => { /* the all-time board still works */ },
  );
  if (uid) {
    try { const snap = await db.doc('leaderboard/' + uid).get(); if (snap.exists) mine = snap.data(); } catch { /* board still shows */ }
  }
  notify();
}
function notify() { for (const fn of listeners) fn(); }

export const worldReady = () => db !== null;
/** Would this score become the player's new world best? */
export const beatsWorldBest = score => db !== null && uid !== null && writable && score > 0 && (!mine || score > mine.s);

/** Record a run as this player's best (only if it beats their last one). */
export async function submitWorld(entry) {
  if (!beatsWorldBest(entry.s)) return;
  // keep any daily fields already on this player's document
  const body = { ...(mine || {}), n: entry.n, s: entry.s, wave: entry.wave, stage: entry.stage, at: new Date().toISOString() };
  mine = body;
  try { await db.doc('leaderboard/' + uid).set(body); }
  catch (e) { if (e && e.code === 'invalid_argument') writable = false; } // view-only here: keep playing locally
  notify();
}

/** Would this be the player's best score in today's challenge? */
export const beatsDailyBest = (score, key) => db !== null && uid !== null && writable && score > 0 && !(mine && mine.dailyDate === key && mine.dailyScore >= score);
export async function submitDaily(entry) {
  if (!beatsDailyBest(entry.s, entry.key)) return;
  const body = { ...(mine || {}), dailyDate: entry.key, dailyScore: entry.s, dailyN: entry.n, dailyMod: entry.mod };
  mine = body;
  try { await db.doc('leaderboard/' + uid).set(body); }
  catch (e) { if (e && e.code === 'invalid_argument') writable = false; }
  notify();
}
function fill(ol, list, name, score, empty) {
  ol.textContent = '';
  if (!list.length) { const li = document.createElement('li'); li.className = 'empty'; li.textContent = empty; ol.append(li); return; }
  list.forEach((e, i) => {
    const li = document.createElement('li'); if (e.id === uid) li.className = 'me';
    const rank = document.createElement('span'); rank.textContent = (i + 1) + '.';
    const n = document.createElement('span'); n.textContent = String(e[name] || '---').slice(0, 3);
    const sc = document.createElement('b'); sc.textContent = pad(Math.max(0, Math.floor(Number(e[score]) || 0)), 7);
    li.append(rank, n, sc); ol.append(li);
  });
}
/** Today's challenge top ten. */
export function renderDaily(ol) { fill(ol, daily, 'dailyN', 'dailyScore', 'Nobody yet today. Be first.'); }

/** Fill a list with the world top ten; the viewer's own row blinks. */
export function renderWorld(ol) {
  fill(ol, top.filter(e => Number(e.s) > 0), 'n', 's', 'No runs yet. Be first.'); // daily-only players have no all-time score
}
