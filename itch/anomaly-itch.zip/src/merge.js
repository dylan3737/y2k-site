// Draw-call savers. Characters are built from dozens of small meshes; the ones that hang off the same joint
// and share a material never move relative to each other, so they can be one mesh. Building boxes use a
// material per face; splitting them into walls + roof lets them join the stage's merged scenery.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

/**
 * Under every node of root, merge the leaf meshes that share a material (and outline setting) into one.
 * Meshes marked userData.keep (armour plates that fly off, a drone's eye...) are left alone.
 */
export function mergeRigidParts(root) {
  const nodes = [];
  root.traverse(n => nodes.push(n));
  for (const node of nodes) {
    const groups = new Map();
    for (const c of node.children) {
      if (!c.isMesh || c.userData.keep || c.children.length || Array.isArray(c.material)) continue;
      const key = c.material.uuid + (c.userData.noOutline ? '|n' : '') + (c.castShadow ? '|s' : '');
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(c);
    }
    for (const list of groups.values()) {
      if (list.length < 2) continue;
      const geos = list.map(m => {
        m.updateMatrix();
        let g = m.geometry.clone().applyMatrix4(m.matrix);
        if (g.index) g = g.toNonIndexed();
        for (const name of Object.keys(g.attributes)) if (!['position', 'normal', 'uv'].includes(name)) g.deleteAttribute(name);
        return g;
      });
      const merged = mergeGeometries(geos, false);
      geos.forEach(g => g.dispose());
      if (!merged) continue;
      const mesh = new THREE.Mesh(merged, list[0].material);
      mesh.castShadow = list[0].castShadow; mesh.receiveShadow = list[0].receiveShadow;
      mesh.userData.noOutline = !!list[0].userData.noOutline;
      for (const m of list) node.remove(m);
      node.add(mesh);
    }
  }
  return root;
}

/** Split a BoxGeometry into its four walls and its top + bottom (faces 0,1,4,5 and 2,3). */
export function splitBox(geo) {
  const idx = geo.index.array, walls = [], caps = [];
  for (const g of geo.groups) {
    const into = g.materialIndex === 2 || g.materialIndex === 3 ? caps : walls;
    for (let i = g.start; i < g.start + g.count; i++) into.push(idx[i]);
  }
  const part = list => { const p = new THREE.BufferGeometry(); for (const [k, a] of Object.entries(geo.attributes)) p.setAttribute(k, a.clone()); p.setIndex(list); return p; };
  return [part(walls), part(caps)];
}
