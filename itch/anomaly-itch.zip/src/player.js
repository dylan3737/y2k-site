// Player movement and abilities: run, jump, wall-run, climb, shootdodge, stomp, body surf.
// Plus the over-the-shoulder camera and taking damage.
import * as THREE from 'three';
import { camera } from './engine.js';
import { rumble } from './rumble.js';
import { droneNear } from './drones.js';
import { V3, rand, clamp, damp, lerpAngle, MOTION, tmpA, tmpB, tmpC } from './util.js';
import { level, overlaps, moveBody, rayWorld, groundBelow } from './physics.js';
import { sparks, embers, bleed, splat } from './fx.js';
import { sfx, setAmbience } from './audio.js';
import { T } from './config.js';
import { settings, SHAKE } from './settings.js';
import { G, P, input, world } from './state.js';
import { isLive } from './soldiers.js';
import { stomp, groundSlam, damageSoldier } from './combat.js';
import { popup } from './ui.js';
import { addScore, loseLife } from './game.js';

/** The player moves a little faster than the world in slow motion. */
export const playerDt = dtR => dtR * (0.42 + 0.58 * G.timeScale);
const AXES = [[1, 0], [-1, 0], [0, 1], [0, -1]];

// ---- wall probes: n is the wall's outward normal
function probe(nx, nz, minTop, maxBottom) {
  tmpC.set(P.pos.x - nx * 0.3, P.pos.y, P.pos.z - nz * 0.3);
  for (const b of level.boxes) {
    if (b.max.y < P.pos.y + minTop || b.min.y > P.pos.y + maxBottom) continue;
    if (overlaps(tmpC, P.r, P.h, b)) return true;
  }
  return false;
}
/** A wall tall enough to run along. */
const wallAt = (nx, nz) => probe(nx, nz, 1.1, 0.6);
/** Anything at body height (walls, cars, crates): climbable or vaultable. */
const blockAt = (nx, nz) => probe(nx, nz, 0.3, 1.6);

/** Input as a world-space wish direction plus the camera basis. */
function readIntent() {
  const sy = Math.sin(P.yaw), cy = Math.cos(P.yaw);
  const m = input.move;
  const ix = clamp((m.right ? 1 : 0) - (m.left ? 1 : 0) + input.pad.x + input.touch.x, -1, 1);
  const iz = clamp((m.forward ? 1 : 0) - (m.back ? 1 : 0) + input.pad.y + input.touch.y, -1, 1);
  const fx = -sy, fz = -cy, rx = cy, rz = -sy;
  let wx = fx * iz + rx * ix, wz = fz * iz + rz * ix;
  const wl = Math.hypot(wx, wz); if (wl > 0) { wx /= wl; wz /= wl; }
  return { ix, iz, wx, wz, wl, fx, fz, rx, rz, sy, cy, hv: Math.hypot(P.vel.x, P.vel.z) };
}

function tickTimers(dt, dtR) {
  P.wallCd -= dt; P.diveCd -= dt; P.climbCd -= dt;
  if (P.diveT > 0) { P.diveT -= dt; P.diveAge += dt; }
  if (P.slideT > 0) P.slideT -= dt;
  if (P.slashT > 0) P.slashT = Math.max(0, P.slashT - dtR);
  if (P.slashCd > 0) P.slashCd -= dtR;
  if (P.swordT > 0) P.swordT -= dtR;
  if (P.dashCd > 0) P.dashCd -= dtR;
  if (P.dashT > 0) { P.dashT -= dt; if (P.dashT <= 0) { P.vel.x *= 0.3; P.vel.z *= 0.3; } }
}

// ---- abilities
/** Shift: dive the way you're pushing; the world drops into slow motion and you keep shooting. */
function startDive(it) {
  if (P.diveT > 0 || P.diveCd > 0) return;
  if (P.surf) endSurf(false);
  const dx = it.wl > 0 ? it.wx : it.fx, dz = it.wl > 0 ? it.wz : it.fz;
  const sp = Math.max(it.hv, T.diveSpeed);
  P.vel.x = dx * sp; P.vel.z = dz * sp;
  P.flip = !P.grounded && !P.wall;
  P.vel.y = P.grounded ? T.diveLift : Math.max(P.vel.y, 4.5);
  Object.assign(P, { diveT: T.diveTime, diveAge: 0, grounded: false, wall: null, climb: null, slideT: 0 });
  sfx.dive();
}

/** Coming down on a soldier's head. */
function checkStomp() {
  if (P.vel.y >= -5 || P.grounded) return;
  const dr = droneNear(tmpA.set(P.pos.x, P.pos.y - 0.2, P.pos.z), 0.9);
  if (dr) { dr.hurt(999, ['STOMP']); P.vel.y = 11; P.airJumps = 1; sfx.stomp(); G.shake = Math.max(G.shake, 0.4); return; }
  for (const s of world.soldiers) {
    if (!isLive(s)) continue;
    const top = s.pos.y + 1.95 * s.scale;
    if (Math.hypot(P.pos.x - s.pos.x, P.pos.z - s.pos.z) < 0.5 * s.scale + 0.4 && P.pos.y <= top + 0.4 && P.pos.y >= top - 1) { stomp(s); return; }
  }
}

function probeWallRun(hv) {
  if (hv < 3.5) return null;
  let best = null, bestScore = 0.1;
  for (const [nx, nz] of AXES) {
    if (!wallAt(nx, nz)) continue;
    const dot = (P.vel.x * nx + P.vel.z * nz) / hv;
    if (dot > 0.3) continue; // moving away from it
    const score = 1 - Math.abs(dot);
    if (score > bestScore) { bestScore = score; best = { nx, nz, t: 0 }; }
  }
  return best;
}

/** Start or stop wall-running (along a wall) and climbing (straight at one). */
function updateWallStates(dt, it) {
  const free = !P.surf && P.diveT <= 0 && P.dashT <= 0;
  if (free && !P.grounded && !P.wall && !P.climb && P.wallCd <= 0 && it.iz > 0) {
    const w = probeWallRun(it.hv);
    if (w) { P.wall = w; P.vel.y = Math.max(P.vel.y, 3); P.airJumps = 1; P.slideT = 0; }
  }
  if (free && !P.climb && !P.wall && P.climbCd <= 0 && P.climbLeft > 0.2 && it.iz > 0.5) {
    for (const [nx, nz] of AXES) {
      if (-(it.wx * nx + it.wz * nz) < 0.72 || !blockAt(nx, nz)) continue;
      P.climb = { nx, nz }; P.slideT = 0; P.airJumps = 1; break;
    }
  }
  if (P.climb) {
    const c = P.climb;
    P.climbLeft -= dt;
    if (!blockAt(c.nx, c.nz)) {
      // cleared the top edge: vault up and over
      P.vel.x = -c.nx * T.vaultPush; P.vel.z = -c.nz * T.vaultPush; P.vel.y = Math.max(P.vel.y, T.vaultUp);
      P.climb = null; P.climbCd = 0.25; sfx.jump();
      embers(tmpA.set(P.pos.x, P.pos.y + 1, P.pos.z), 10, 2, 0.4, 3);
    } else if (P.climbLeft <= 0 || it.iz <= 0) {
      P.vel.x = c.nx * 2; P.vel.z = c.nz * 2; P.climb = null; P.climbCd = 0.5;
    }
  }
  if (P.wall) {
    P.wall.t += dt;
    if (!wallAt(P.wall.nx, P.wall.nz) || P.grounded || P.wall.t > T.wallRunTime || it.iz <= 0) { P.wall = null; P.wallCd = 0.35; }
  }
}

/** Set horizontal velocity for whichever movement state we're in, then gravity. */
function steer(dt, it) {
  if (P.dashT > 0) {
    P.vel.x = P.dashV.x; P.vel.z = P.dashV.z; P.vel.y = 0; // the dash-cut: flat and fast
    return;
  }
  if (P.climb) {
    const c = P.climb;
    P.vel.x = -c.nx * 2; P.vel.z = -c.nz * 2;
    P.vel.y = P.climbLeft < 0.4 ? 5 : T.climbSpeed;
    if (Math.random() < 0.3) embers(tmpA.set(P.pos.x - c.nx * 0.3, P.pos.y + 0.2, P.pos.z - c.nz * 0.3), 1, 1, 0.3, 6);
  } else if (P.surf) {
    // steer toward the input; speed slowly bleeds off
    const sp = Math.max(8, it.hv - 1.4 * dt);
    const cur = Math.atan2(P.vel.x, P.vel.z), h = lerpAngle(cur, it.wl > 0 ? Math.atan2(it.wx, it.wz) : cur, 1 - Math.exp(-3.5 * dt));
    P.vel.x = Math.sin(h) * sp; P.vel.z = Math.cos(h) * sp;
  } else if (P.wall) {
    const { nx, nz } = P.wall;
    const vn = P.vel.x * nx + P.vel.z * nz;
    let ax = P.vel.x - nx * vn, az = P.vel.z - nz * vn, al = Math.hypot(ax, az);
    if (al < 0.5) { const fn = it.fx * nx + it.fz * nz; ax = it.fx - nx * fn; az = it.fz - nz * fn; al = Math.hypot(ax, az) || 1; }
    const sp = Math.max(al, T.wallRunSpeed);
    P.vel.x = ax / al * sp - nx * 1.5; P.vel.z = az / al * sp - nz * 1.5;
    P.vel.y -= (P.wall.t < 0.6 ? 3 : 9) * dt;
  } else if (P.grounded && P.slideT <= 0) {
    P.vel.x = damp(P.vel.x, it.wx * T.runSpeed, T.groundAccel, dt); P.vel.z = damp(P.vel.z, it.wz * T.runSpeed, T.groundAccel, dt);
  } else if (P.grounded) {
    P.vel.x *= 1 - 1.1 * dt; P.vel.z *= 1 - 1.1 * dt; // sliding
  } else if (P.diveT <= 0) {
    P.vel.x += it.wx * T.airAccel * dt; P.vel.z += it.wz * T.airAccel * dt;
    const nh = Math.hypot(P.vel.x, P.vel.z), cap = Math.max(it.hv, T.runSpeed);
    if (nh > cap) { P.vel.x *= cap / nh; P.vel.z *= cap / nh; }
  }
  if (!P.wall && !P.climb) P.vel.y -= T.gravity * dt;
}

function jump(it) {
  if (P.surf) {
    endSurf(true); P.vel.y = 10.5; P.airJumps = 1; sfx.airJump();
  } else if (P.climb || P.wall) {
    // kick off the wall
    const n = P.climb || P.wall, push = P.climb ? 1.5 : 2;
    P.vel.x = (P.climb ? 0 : P.vel.x) + n.nx * T.wallKick + it.fx * push;
    P.vel.z = (P.climb ? 0 : P.vel.z) + n.nz * T.wallKick + it.fz * push;
    P.vel.y = 8.8;
    if (P.climb) P.climbCd = 0.3;
    P.climb = null; P.wall = null; P.wallCd = 0.28; P.airJumps = 1; sfx.airJump();
  } else if (P.grounded || G.clock - P.lastGround < T.coyote) {
    P.vel.y = T.jump; P.grounded = false; P.lastGround = -9; P.slideT = 0; sfx.jump();
  } else if (P.airJumps > 0) {
    P.airJumps--; P.vel.y = T.airJump;
    if (it.wl > 0) { const h = Math.max(it.hv, 7); P.vel.x = it.wx * h; P.vel.z = it.wz * h; }
    embers(tmpA.copy(P.pos), 24, 3, 0.4, 0);
    sfx.airJump();
  }
}

/** Move with collision, then handle what landing means. */
/** Stages with walls round them (bounds: [x0, x1, z0, z1], their inner faces) can't be climbed or jumped out of. */
function keepInBounds() {
  const b = level.info.bounds; if (!b) return;
  const r = P.r;
  if (P.pos.x < b[0] + r) { P.pos.x = b[0] + r; P.vel.x = Math.max(0, P.vel.x); }
  if (P.pos.x > b[1] - r) { P.pos.x = b[1] - r; P.vel.x = Math.min(0, P.vel.x); }
  if (P.pos.z < b[2] + r) { P.pos.z = b[2] + r; P.vel.z = Math.max(0, P.vel.z); }
  if (P.pos.z > b[3] - r) { P.pos.z = b[3] - r; P.vel.z = Math.min(0, P.vel.z); }
}

function integrate(dt) {
  const vyBefore = P.vel.y;
  const steps = Math.ceil(dt / 0.008);
  let grounded = false;
  for (let i = 0; i < steps; i++) grounded = moveBody(P, dt / steps) || grounded;
  const landed = grounded && !P.grounded;
  if (landed && vyBefore < -11) { G.shake = Math.max(G.shake, 0.25); sfx.land(); rumble(0.2, 0.25, 70); }
  if (landed && vyBefore < -T.slamSpeed && G.mode === 'play') groundSlam(-vyBefore);
  if (grounded && P.diveT > 0 && P.diveAge > 0.12) {
    // land the dive and roll straight into a slide
    P.diveT = 0; P.diveCd = 0.3; P.slideT = 0.5; sfx.land();
    embers(tmpA.set(P.pos.x, P.pos.y + 0.1, P.pos.z), 14, 3, 0.4, 4);
  }
  keepInBounds();
  P.grounded = grounded;
  if (grounded) {
    P.lastGround = G.clock; P.airJumps = 1; P.climbLeft = T.climbTime; P.climb = null;
    if (groundBelow(P.pos.x, P.pos.z, P.pos.y)) P.safe.copy(P.pos);
  }
}

// ---- body surfing
/** Slide or dive into a corpse to ride it. */
function checkSurfStart() {
  if (P.surf || (P.slideT <= 0 && P.diveT <= 0) || G.mode !== 'play') return;
  for (const s of world.soldiers) {
    if (!s.dead || s.surfed || !s.bounced || s.surfAgain > G.clock) continue;
    if (Math.hypot(P.pos.x - s.pos.x, P.pos.z - s.pos.z) < 1.2 && Math.abs(P.pos.y - s.pos.y) < 1.2) { startSurf(s); return; }
  }
}
function startSurf(s) {
  P.surf = { body: s, t: 0, trail: 0 }; s.surfed = true;
  P.diveT = 0; P.slideT = 0;
  const hv = Math.hypot(P.vel.x, P.vel.z) || 1, sp = Math.max(hv, 14);
  P.vel.x = P.vel.x / hv * sp; P.vel.z = P.vel.z / hv * sp;
  addScore(250); popup(tmpA.set(P.pos.x, P.pos.y + 2.4, P.pos.z), 'BODY SURF!', 'gold'); sfx.surf();
}
export function endSurf(jumped) {
  if (!P.surf) return;
  const s = P.surf.body; P.surf = null;
  s.surfed = false; s.surfAgain = G.clock + 1.2;
  s.vel.set(P.vel.x * (jumped ? 0.8 : 0.4), 0, P.vel.z * (jumped ? 0.8 : 0.4));
  s.fallAxis = 'x'; s.fallSign = 1; s.deathT = Math.min(s.deathT, 8);
}
function updateSurf(dt) {
  if (!P.surf) return;
  const surf = P.surf, s = surf.body, heading = Math.atan2(P.vel.x, P.vel.z);
  surf.t += dt;
  s.pos.copy(P.pos);
  s.model.position.set(P.pos.x, P.pos.y + 0.16 * s.scale, P.pos.z);
  s.model.rotation.set(-Math.PI / 2, heading + Math.PI, 0);
  surf.trail -= dt;
  if (P.grounded && surf.trail <= 0) { surf.trail = 0.12; splat(P.pos, rand(0.15, 0.25)); }
  if (P.grounded && Math.random() < 0.6) { sparks.emit(tmpA.set(P.pos.x, P.pos.y + 0.05, P.pos.z), 2, 2.5, 3, 1.6, 0.5, 0.25, 10, 1.5); bleed(tmpA, 1, 1, 0.5); }
  for (const other of world.soldiers) {
    if (!isLive(other)) continue;
    if (Math.hypot(P.pos.x - other.pos.x, P.pos.z - other.pos.z) < 1 + other.r && Math.abs(P.pos.y - other.pos.y) < 1.5) {
      damageSoldier(other, other.boss ? 150 : 999, false, tmpB.set(Math.sin(heading), 0, Math.cos(heading)), ['ROADKILL']);
      surf.t = Math.max(0, surf.t - 0.6); G.shake = Math.max(G.shake, 0.35);
    }
  }
  if (surf.t > T.surfTime || (Math.hypot(P.vel.x, P.vel.z) < 5 && surf.t > 0.3)) endSurf(false);
}

function pushOutOfSoldiers() {
  for (const s of world.soldiers) {
    if (s.dead || s.spawnT > 0) continue;
    const dx = P.pos.x - s.pos.x, dz = P.pos.z - s.pos.z, d = Math.hypot(dx, dz);
    if (d < 0.72 && d > 1e-4 && P.pos.y < s.pos.y + 1.8) { P.pos.x += dx / d * (0.72 - d); P.pos.z += dz / d * (0.72 - d); }
  }
}

// ---- kill-cam: a slow orbit round the last soldier of a wave, easing in from and back to the normal view
const kcTarget = new V3(), kcPos = new V3(), kcDir = new V3();
const kcQ0 = new THREE.Quaternion(), kcQ1 = new THREE.Quaternion();
const ease = t => t * t * (3 - 2 * t);
function updateKillCam(dtR) {
  const kc = G.killCam;
  kc.t += dtR;
  if (kc.t >= kc.dur || G.mode !== 'play') { G.killCam = null; document.body.classList.remove('cinema'); return; }
  // optional framing: aim (height on the body to look at), lift (how high the camera sits), rad (distance)
  const s = kc.s, k = kc.t / kc.dur;
  kcTarget.set(s.model.position.x, s.model.position.y + (kc.aim ?? 0.75) * s.scale, s.model.position.z);
  const ang = kc.a0 + kc.spin * kc.t, r = (kc.rad ?? 3 - 0.7 * k) * s.scale;
  kcDir.set(Math.sin(ang), kc.lift ?? 0.32, Math.cos(ang)).normalize();
  const clear = rayWorld(kcTarget, kcDir, r + 0.3) - 0.3;          // never inside a wall
  kcPos.copy(kcTarget).addScaledVector(kcDir, Math.max(0.8, Math.min(r, clear)));
  const blend = ease(Math.min(1, kc.t / 0.18)) * ease(Math.min(1, (kc.dur - kc.t) / 0.25));
  kcQ0.copy(camera.quaternion);
  camera.position.lerp(kcPos, blend);
  camera.lookAt(kcTarget); kcQ1.copy(camera.quaternion);
  camera.quaternion.copy(kcQ0).slerp(kcQ1, blend);
}

// ---- camera: over the right shoulder, pulled in when something is behind us
function updateCamera(dtR, dt, it) {
  P.eye = damp(P.eye, P.slideT > 0 ? 0.95 : P.diveT > 0 ? 1.1 : P.surf ? 1.85 : 1.62, 12, dtR);
  const roll = P.wall ? -(P.wall.nx * it.rx + P.wall.nz * it.rz) * 0.22 : (P.slideT > 0 ? 0.07 : 0) - it.ix * 0.018;
  P.roll = damp(P.roll, roll * MOTION, 8, dtR);
  const hv = Math.hypot(P.vel.x, P.vel.z);
  let bob = 0;
  if (P.grounded && P.slideT <= 0 && hv > 1) { P.bob += hv * dt * 1.15; bob = Math.sin(P.bob * 2) * 0.045 * Math.min(1, hv / 9) * MOTION; }
  const sh = G.shake * G.shake * 0.25 * MOTION * SHAKE[settings.shake];
  const cp = Math.cos(P.pitch);
  const hx = P.pos.x, hy = P.pos.y + P.eye + 0.15 + bob * 0.5, hz = P.pos.z;
  tmpA.set(hx, hy, hz);
  tmpB.set(it.sy * cp * 3.4 + it.rx * 0.8, -Math.sin(P.pitch) * 3.4 + 0.25, it.cy * cp * 3.4 + it.rz * 0.8);
  const want = tmpB.length(); tmpB.divideScalar(want);
  const clear = Math.min(want, Math.max(0.2, rayWorld(tmpA, tmpB, want + 0.4) - 0.35));
  G.camDist = clear < G.camDist ? clear : damp(G.camDist, clear, 5, dtR);
  camera.position.set(hx + tmpB.x * G.camDist + rand(-sh, sh), hy + tmpB.y * G.camDist + rand(-sh, sh), hz + tmpB.z * G.camDist + rand(-sh, sh));
  camera.rotation.set(P.pitch, P.yaw, P.roll * 0.6);
  const fov = settings.fov + clamp((hv - 9.5) * 0.9, 0, 12) - (G.focusActive ? 6 : 0);
  if (Math.abs(camera.fov - fov) > 0.05) { camera.fov = damp(camera.fov, fov, 6, dtR); camera.updateProjectionMatrix(); }
  G.shake = Math.max(0, G.shake - dtR * 2.2);
  if (G.killCam) updateKillCam(dtR);
  const rushing = P.wall || P.climb || P.slideT > 0 || P.surf || P.diveT > 0;
  setAmbience(rushing ? 0.14 : Math.min(0.05, hv / 400 + (P.grounded ? 0 : 0.02)), G.focusActive);
}

/** One frame of player movement. */
export function updatePlayer(dtR) {
  const dt = playerDt(dtR);
  tickTimers(dt, dtR);
  const it = readIntent();
  if (input.dive) { input.dive = false; startDive(it); }
  if (G.mode === 'play') checkStomp();
  updateWallStates(dt, it);
  steer(dt, it);
  if (input.jump) { input.jump = false; jump(it); }
  integrate(dt);
  checkSurfStart();
  updateSurf(dt);
  pushOutOfSoldiers();
  updateCamera(dtR, dt, it);
  if (P.pos.y < level.info.killY) fellOff();
}

// ---- taking damage
export function hurtPlayer(dmg) {
  if (P.invT > 0) return;
  if (G.daily && G.daily.mod === 'onehit') dmg = 9999;       // any hit costs a life today
  if (G.daily && G.daily.mod === 'glass') dmg *= 2;
  rumble(0.35, 0.4, 120);
  P.hp -= dmg; P.lastHurt = G.clock; G.waveHurt = true; G.hurtFlash = 1; G.shake = Math.max(G.shake, 0.5);
  sfx.hurt();
  bleed(tmpA.set(P.pos.x, P.pos.y + 1.2, P.pos.z), 10, 3, 1);
  if (P.hp <= 0 && G.mode === 'play') loseLife();
}
/** Fell off the rooftops: lose some health and come back at the last safe spot. */
function fellOff() {
  P.hp -= 30; P.lastHurt = G.clock; G.waveHurt = true; G.hurtFlash = 1; G.shake = 0.6;
  sfx.hurt(); sfx.whoosh(0.6);
  P.pos.copy(P.safe); P.vel.set(0, 0, 0); P.wall = null; P.climb = null; G.camDist = 0.6;
  popup(tmpA.set(P.pos.x, P.pos.y + 2.2, P.pos.z), 'FELL  -30', 'red');
  if (P.hp <= 0) { loseLife(); return; }
  P.invT = Math.max(P.invT, 1.5);
}
