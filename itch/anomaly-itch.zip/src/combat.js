// Everything that hurts soldiers: pistols, katana, stomps, ground slams and Hellfire. Plus kill scoring.
import * as THREE from 'three';
import { camera } from './engine.js';
import { V3, rand, clamp, tmpA, tmpB, MOTION } from './util.js';
import { rayAABB, rayWorld } from './physics.js';
import { sparks, EMBER, embers, bleed, spawnGibs, splat, addFx, ownMat, spawnTracer, shockRing } from './fx.js';
import { sfx, announce } from './audio.js';
import { settings } from './settings.js';
import { T, POWER, CHAIN_NAMES } from './config.js';
import { G, P, world, input } from './state.js';
import { hero, muzzleLight } from './hero.js';
import { tryDodge, isLive, beginDeath, shieldBlocks } from './soldiers.js';
import { clearBullets, deflectBullet } from './bullets.js';
import { bossDamage, counterBoss } from './boss.js';
import { dropPickup, rollDrop } from './pickups.js';
import { flashHit, addFeed, popup, callout } from './ui.js';
import { addScore } from './game.js';
import { rumble } from './rumble.js';
import { barrelAlong, explodeBarrel, explodeBarrelsNear } from './barrels.js';
import { droneAlong } from './drones.js';
import { track, look } from './style.js';
import { dailyMod } from './daily.js';
import { bladeInHand } from './blade.js';
import { ejectCasing, bulletHole } from './look.js';

// ---- pistols
/** Hits along a ray, nearest first. Without pierce, only the first soldier counts and may dodge. */
function shootRay(origin, dir, pierce) {
  const tWorld = rayWorld(origin, dir, 250);
  const hits = [];
  for (const s of world.soldiers) {
    if (s.dead || s.spawnT > 0) continue;
    const p = s.pos, k = s.scale;
    const tHead = rayAABB(origin, dir, p.x - 0.18 * k, p.y + 1.58 * k, p.z - 0.18 * k, p.x + 0.18 * k, p.y + 1.98 * k, p.z + 0.18 * k, tWorld);
    const tBody = rayAABB(origin, dir, p.x - 0.33 * k, p.y, p.z - 0.33 * k, p.x + 0.33 * k, p.y + 1.58 * k, p.z + 0.33 * k, tWorld);
    if (tHead < Infinity || tBody < Infinity) hits.push({ s, head: tHead <= tBody, t: Math.min(tHead, tBody) });
  }
  hits.sort((a, b) => a.t - b.t);
  let list = pierce ? hits : hits.slice(0, 1);
  if (!pierce && list.length && !list[0].s.idle && tryDodge(list[0].s)) list = [];
  const tEnd = !pierce && list.length ? list[0].t : tWorld;
  return { list, tWorld, end: origin.clone().addScaledVector(dir, Math.min(tEnd, 250)) };
}

/** One shot from alternating hands. Aims through the crosshair; tracers leave from the muzzle. */
export function fire() {
  if (P.reloadT > 0) return;
  if (dailyMod('katana')) { P.fireCd = 0.5; sfx.empty(); return; } // guns locked today
  const power = P.powerT > 0 ? P.power : null;
  if (power !== 'rapid') {
    if (P.ammo <= 0) { sfx.empty(); startReload(); return; }
    P.ammo--;
  }
  P.side ^= 1;
  const hand = hero.hands[P.side];
  const dir = new V3(); camera.getWorldDirection(dir);
  const origin = camera.position.clone();
  const hv = Math.hypot(P.vel.x, P.vel.z);
  const spread = G.focusActive ? 0.002 : 0.009 + Math.min(hv / 9.5, 1) * 0.01 + (P.grounded ? 0 : 0.006);
  dir.x += rand(-spread, spread); dir.y += rand(-spread, spread); dir.z += rand(-spread, spread); dir.normalize();
  const up = new V3(0, 1, 0);
  const dirs = power === 'spread' ? [dir, dir.clone().applyAxisAngle(up, 0.075), dir.clone().applyAxisAngle(up, -0.075)] : [dir];

  hand.aimT = 0.35; P.swordT = 0; // the guns come back out
  rumble(0.14, 0, 35);
  hand.shoulder.rotation.x = -(Math.PI / 2 + P.pitch); hand.elbow.rotation.x = 0; // snap the arm up so the muzzle is in place
  hero.root.updateMatrixWorld(true);
  const muzzle = hand.muzzle.getWorldPosition(new V3());
  ejectCasing(muzzle, P.side ? 1 : -1);
  const color = power ? POWER[power].color : look.tracer;
  sparks.emit(muzzle, 8, 2.5, 3, 1.6, 0.5, 0.15, 0);
  for (const d of dirs) {
    const r = shootRay(origin, d, power === 'pierce');
    const hitDrone = droneAlong(origin, d, r.list.length ? r.list[0].t : r.tWorld);
    if (hitDrone) {
      // a drone in the way takes the round
      hitDrone.d.hurt(T.bodyDamage, []);
      spawnTracer(muzzle, origin.clone().addScaledVector(d, hitDrone.t), color, 1.6);
      if (power !== 'pierce') continue;
    }
    const hitBarrel = barrelAlong(origin, d, r.tWorld + 0.05);
    if (hitBarrel && (power === 'pierce' || !r.list.length || hitBarrel.t < r.list[0].t)) {
      // a barrel in the line of fire goes up (a pierce round carries on through it)
      explodeBarrel(hitBarrel.b);
      if (power !== 'pierce') { spawnTracer(muzzle, origin.clone().addScaledVector(d, hitBarrel.t), color, 1.6); continue; }
    }
    spawnTracer(muzzle, r.end, color, power === 'pierce' ? 3.5 : 1.6);
    for (const h of r.list) {
      const at = origin.clone().addScaledVector(d, h.t);
      if (shieldBlocks(h.s, d, h.head)) { sparks.emit(at, 14, 5, 3, 1.6, 0.5, 0.2, 10); sfx.ricochet(); break; }
      bleed(at, h.head ? 34 : 16, h.head ? 5 : 3.5, 1);
      sparks.emit(at, 5, 5, 3, 1.8, 0.8, 0.1, 0);
      damageSoldier(h.s, h.head ? T.headDamage : T.bodyDamage, h.head, d);
    }
    if (!r.list.length && r.tWorld < 250) { sparks.emit(r.end, 10, 5, 3, 2, 0.8, 0.3, 12); bulletHole(r.end, d); }
  }
  hand.flashT = 0.06; hand.kick = 1; hand.flash.material.rotation = Math.random() * 6;
  muzzleLight.intensity = 30; muzzleLight.position.copy(muzzle);
  G.shake = Math.max(G.shake, 0.12);
  sfx.shot(0.9, 0.55 + 0.45 * G.timeScale);
  if (P.ammo === 0 && power !== 'rapid') startReload();
}
export function startReload() {
  if (P.reloadT > 0 || P.ammo === T.magSize) return;
  P.reloadT = T.reloadTime; sfx.reload();
}

// ---- katana
const slashGeo = new THREE.RingGeometry(1.75, 2.3, 36, 1, Math.PI / 2 - 1.35, 2.7); slashGeo.rotateX(-Math.PI / 2);
/** Swings alternate direction, with a short cooldown. Cuts soldiers in a wide arc and bats bullets back. */
const COMBO_GAP = 0.5;      // press again within this long to chain the next cut
const PERFECT_WINDOW = 0.14; // a bullet this close to hitting you is a perfect parry
export function slash() {
  if (P.slashCd > 0 || G.mode !== 'play') return;
  if (!bladeInHand()) { P.slashCd = 0.3; sfx.empty(); return; } // it's stuck in a wall somewhere
  // a three-cut string: quick follow-ups, then a wide horizontal finisher and a longer reset
  P.slashStep = G.clock - P.lastSlashAt < COMBO_GAP && P.slashStep < 3 ? P.slashStep + 1 : 1;
  P.lastSlashAt = G.clock;
  const finisher = P.slashStep === 3;
  P.slashCd = finisher ? 0.55 : 0.2;
  P.slashDir = -(P.slashDir || 1); P.slashT = T.slashTime; P.swordT = 0.7;
  P.slashTilt = finisher ? -P.slashDir * rand(0, 0.12) : -P.slashDir * rand(0.2, 0.8);
  if (!hero.katana.visible) embers(hero.hands[1].muzzle.getWorldPosition(tmpA), 16, 1.5, 0.3, 0);
  const fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw);
  let hits = 0;
  for (const s of world.soldiers) {
    if (!isLive(s)) continue;
    const dx = s.pos.x - P.pos.x, dz = s.pos.z - P.pos.z, d = Math.hypot(dx, dz);
    if (d < (finisher ? 3.4 : 2.9) + s.r && (dx * fx + dz * fz) / (d || 1) > (finisher ? -0.1 : 0.1) && Math.abs(s.pos.y - P.pos.y) < 2) {
      const k = (s.boss ? 0.2 : 1) * (finisher ? 2 : 1);
      s.knock.set(fx * 7 * k, (finisher ? 4 : 2.5) * (s.boss ? 0.2 : 1), fz * 7 * k);
      bleed(tmpA.set(s.pos.x, s.pos.y + 1.2 * s.scale, s.pos.z), 30, 5, 1.5);
      cutFlash(s, finisher);
      counterBoss(s); // a cut into a charging Juggernaut stops him dead
      damageSoldier(s, T.slashDamage * (finisher ? 1.6 : 1), false, tmpB.set(fx, 0, fz), finisher ? ['KATANA', 'FINISHER'] : ['KATANA']);
      hits++;
    }
  }
  for (const dr of world.drones) {
    if (dr.dead || dr.spawnT > 0) continue;
    const dx = dr.pos.x - P.pos.x, dy = dr.pos.y - (P.pos.y + 1.1), dz = dr.pos.z - P.pos.z, dd = Math.hypot(dx, dz);
    if (Math.hypot(dd, dy) < (finisher ? 3.6 : 3.1) && (dx * fx + dz * fz) / (dd || 1) > -0.1) { dr.hurt(T.slashDamage, ['KATANA']); hits++; }
  }
  let batted = 0, perfect = 0;
  for (const b of world.bullets) {
    if (b.friendly || !inSwingArc(b.pos, 3.2)) continue;
    // time until it would have hit: cut it at the last instant for a perfect parry
    const tti = Math.hypot(b.pos.x - P.pos.x, b.pos.y - (P.pos.y + 1.1), b.pos.z - P.pos.z) / (b.vel.length() || 1);
    if (tti < PERFECT_WINDOW) { b.perfect = true; perfect++; }
    deflectBullet(b, true); batted++;
  }
  if (perfect) {
    // freeze-frame, then slow motion while the round flies back as a guaranteed headshot
    G.parryT = 0.5; G.hitStop = Math.max(G.hitStop, 0.07); G.flash = Math.max(G.flash, 0.25);
    addScore(250 * perfect); sfx.parry(); rumble(0.5, 0.35, 140); track('parry', perfect);
    popup(tmpA.set(P.pos.x, P.pos.y + 2.3, P.pos.z), 'PERFECT PARRY', 'gold'); announce('perfect');
  } else if (batted) {
    popup(tmpA.set(P.pos.x, P.pos.y + 2.3, P.pos.z), batted > 1 ? `${batted} DEFLECTED` : 'DEFLECT', 'cyan');
    rumble(0.3, 0.1, 60);
  }
  // the swing arc
  const outer = new THREE.Group(); outer.position.set(P.pos.x, P.pos.y + 1.15, P.pos.z); outer.rotation.y = P.yaw;
  const mat = ownMat(THREE.MeshBasicMaterial, { color: new THREE.Color(...(look.slash || [3.6, 1.5, 0.45]).map(v => v * 0.47)), transparent: true, opacity: 0.45, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
  const arc = new THREE.Mesh(slashGeo, mat); arc.rotation.z = P.slashTilt; arc.scale.x = P.slashDir; outer.add(arc);
  const dirSign = P.slashDir, peak = hits ? 0.8 : 0.5; // the arc burns brighter when it connects
  addFx(outer, 0.26, (o, k) => {
    const on = k < 0.35 ? (k / 0.35) ** 2 : (1 - (k - 0.35) / 0.65) ** 2; // brightest as the blade passes
    mat.opacity = peak * on; arc.scale.set(dirSign * (0.9 + 0.2 * k), 1, 0.9 + 0.2 * k);
  }, true);
  sfx.slash();
  if (hits) {
    // the freeze-frame grows a little with each extra body in the arc, and most on the finisher
    G.shake = Math.max(G.shake, finisher ? 0.55 : 0.3);
    G.hitStop = Math.max(G.hitStop, Math.min(0.14, (finisher ? 0.11 : 0.065) + 0.015 * (hits - 1)));
    G.flash = Math.max(G.flash, finisher ? 0.16 : 0.08);
    sfx.impact(); sfx.cut();
    rumble(0.4, finisher ? 0.45 : 0.25, finisher ? 120 : 80);
  } else rumble(0.18, 0.04, 45);
}

// a white-hot line across the body along the swing, flaring out and fading in a blink, with sparks thrown off the edge
const cutGeo = new THREE.PlaneGeometry(1, 0.035);
function cutFlash(s, finisher) {
  const chest = new V3(s.pos.x, s.pos.y + 1.2 * s.scale, s.pos.z);
  const outer = new THREE.Group(); outer.position.copy(chest).lerp(camera.position, 0.08); // just in front of the body, toward the camera
  outer.quaternion.copy(camera.quaternion);
  const mat = ownMat(THREE.MeshBasicMaterial, { color: new THREE.Color(4, 3.2, 2.2), transparent: true, opacity: 1, blending: THREE.AdditiveBlending, depthWrite: false, depthTest: false, side: THREE.DoubleSide });
  const line = new THREE.Mesh(cutGeo, mat); line.rotation.z = P.slashTilt * 0.8 + (finisher ? 0 : P.slashDir * 0.35); outer.add(line);
  const len = (finisher ? 1.5 : 1.1) * s.scale;
  addFx(outer, 0.16, (o, k) => { mat.opacity = (1 - k) ** 2; line.scale.set(len * (0.6 + 0.6 * Math.sqrt(k)), 1 + 2.5 * k, 1); }, true);
  sparks.emit(chest, finisher ? 26 : 16, finisher ? 8 : 6, 4, 2.6, 1.2, 0.18, 6);
  sparks.emit(chest, 8, 3, EMBER[0], EMBER[1], EMBER[2], 0.35, 4);
}

// ---- charged dash-cut: hold the katana button, release to cut through everything in a line
const CHARGE_READY = 0.45, DASH_LEN = 9, DASH_TIME = 0.16;
/** Called every frame of play: builds the charge while the button is held, fires on release. */
export function updateKatanaCharge(dtR) {
  const held = (input.slashHeld || input.pad.slash) && G.mode === 'play' && bladeInHand();
  if (held) {
    P.chargeT += dtR;
    if (P.chargeT > 0.2) P.swordT = Math.max(P.swordT, 0.3); // keep the blade out while charging
    if (P.chargeT >= CHARGE_READY && !P.chargeReady && P.dashCd <= 0) {
      P.chargeReady = true; sfx.charge(); rumble(0.2, 0.1, 60);
      if (!G.hints.dash) { G.hints.dash = true; }
    }
    if (P.chargeReady && Math.random() < 0.6) embers(hero.katana.getWorldPosition(tmpA), 2, 1, 0.3, 2);
  } else {
    if (P.chargeReady) dashCut();
    P.chargeT = 0; P.chargeReady = false;
  }
}

const streakGeo = new THREE.BoxGeometry(0.06, 0.06, 1); streakGeo.translate(0, 0, 0.5);
function dashCut() {
  if (P.surf) return; // riding a body: no dash
  const fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw);
  tmpA.set(P.pos.x, P.pos.y + 1, P.pos.z); tmpB.set(fx, 0, fz);
  const len = Math.max(1.5, Math.min(DASH_LEN, rayWorld(tmpA, tmpB, DASH_LEN) - 0.6));
  P.dashT = DASH_TIME; P.dashV.set(fx * len / DASH_TIME, 0, fz * len / DASH_TIME);
  P.invT = Math.max(P.invT, 0.35); P.diveT = 0; P.slideT = 0; P.wall = null; P.climb = null;
  // the cut animation, horizontal
  P.slashDir = -(P.slashDir || 1); P.slashT = T.slashTime; P.swordT = 0.7; P.slashTilt = 0; P.slashStep = 0;
  P.slashCd = 0.3; P.dashCd = T.dashCooldown;
  // everyone along the path
  let hits = 0;
  const ox = P.pos.x, oz = P.pos.z;
  for (const s of world.soldiers) {
    if (!isLive(s)) continue;
    const dx = s.pos.x - ox, dz = s.pos.z - oz, along = dx * fx + dz * fz, side = Math.abs(dx * fz - dz * fx);
    if (along < -0.5 || along > len + 1 || side > 1.3 + s.r || Math.abs(s.pos.y - P.pos.y) > 2) continue;
    const sgn = dx * fz - dz * fx > 0 ? 1 : -1;
    s.knock.set(fz * sgn * 6 + fx * 3, 3, -fx * sgn * 6 + fz * 3);
    bleed(tmpA.set(s.pos.x, s.pos.y + 1.2 * s.scale, s.pos.z), 40, 6, 2);
    damageSoldier(s, s.boss ? T.slashDamage * 2 : 999, false, tmpB.set(fx, 0, fz), ['KATANA', 'DASH CUT']);
    hits++;
  }
  for (const b of world.bullets) {
    if (b.friendly) continue;
    const dx = b.pos.x - ox, dz = b.pos.z - oz, along = dx * fx + dz * fz;
    if (along > -0.5 && along < len + 1 && Math.abs(dx * fz - dz * fx) < 1.6) deflectBullet(b, true);
  }
  // a streak of fire along the path
  const mat = ownMat(THREE.MeshBasicMaterial, { color: new THREE.Color(3, 1.1, 0.3), transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
  const streak = new THREE.Mesh(streakGeo, mat);
  streak.position.set(ox, P.pos.y + 1.05, oz); streak.lookAt(ox + fx, P.pos.y + 1.05, oz + fz); streak.scale.set(1, 1, len);
  addFx(streak, 0.35, (o, k) => { mat.opacity = 0.9 * (1 - k) * (1 - k); o.scale.set(1 + 5 * k, 1 + 2 * k, len); }, true);
  embers(tmpA.set(ox, P.pos.y + 0.6, oz), 24, 4, 0.4, 2);
  sfx.dash(); sfx.slash();
  G.shake = Math.max(G.shake, hits ? 0.55 : 0.25);
  if (hits) { G.hitStop = Math.max(G.hitStop, 0.07); sfx.impact(); popup(tmpA.set(P.pos.x + fx * len, P.pos.y + 2.3, P.pos.z + fz * len), hits > 1 ? `DASH CUT x${hits}` : 'DASH CUT', 'gold'); }
  rumble(0.4, 0.35, 160);
}

/** Is p within `reach` of the hero's chest and not behind them? */
export function inSwingArc(p, reach) {
  const fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw);
  const dx = p.x - P.pos.x, dy = p.y - (P.pos.y + 1.1), dz = p.z - P.pos.z;
  return Math.hypot(dx, dy, dz) < reach && (dx * fx + dz * fz) / (Math.hypot(dx, dz) || 1) > -0.2;
}

// ---- damage and kills
export function damageSoldier(s, dmg, head, dir, extraTags = []) {
  if (s.dead) return;
  if (dailyMod('headhunter') && !head && !extraTags.length) { sparks.emit(s.pos.clone().setY(s.pos.y + 1.2), 6, 3, 2.6, 2.4, 2.8, 0.2, 4); return; } // body shots do nothing today
  if (s.boss && s.bs) dmg = bossDamage(s, dmg);
  s.hp -= dmg;
  s.knock.addScaledVector(dir, (head ? 1.5 : 0.8) / s.scale);
  s.flinch = s.boss ? 0.5 : 1; s.hitDir.copy(dir).setY(0).normalize();
  if (!s.boss) {
    // the hit staggers him, longer the harder it lands: his aim drops, he can't fire or roll away, his knees give
    const heavy = extraTags.includes('KATANA') ? 1 : head ? 0.8 : 0.45;
    s.stagger = Math.max(s.stagger, 0.12 + 0.3 * heavy);
    s.fireCd = Math.max(s.fireCd, s.stagger + 0.25); s.charge = 0;
    if (head) s.headSnap = 1;
  }
  flashHit(false); sfx.hit();
  if (s.hp <= 0) killSoldier(s, head, extraTags);
}

/** Style tags for how the kill happened, in addition to the weapon's own tags. */
function styleTags(head, extra) {
  const tags = [...extra];
  if (head) tags.push('HEADSHOT');
  if (P.surf) tags.push('BODY SURF');
  else if (P.climb) tags.push('WALL CLIMB');
  else if (P.diveT > 0) tags.push(P.flip ? 'FLIP' : 'SHOOTDODGE');
  else if (P.wall) tags.push('WALL-RUN');
  else if (!P.grounded) tags.push('AIRBORNE');
  if (P.slideT > 0) tags.push('SLIDE');
  if (G.focusActive) tags.push('BULLET TIME');
  return tags;
}

/** Score a kill at pos: base points, +50% per style tag, times the chain (which this kill extends). */
export function awardKill(pos, base, head, extra, height = 2.1, bonus = 0, drone = false) {
  const tags = styleTags(head, extra);
  G.combo = G.clock - G.lastKill < T.comboWindow ? Math.min(G.combo + 1, 9) : 1;
  G.lastKill = G.clock;
  const pts = Math.round(base * (1 + 0.5 * tags.length) * G.combo) + bonus;
  addScore(pts); G.kills++;
  track('kill', 1, { head, tags: extra, drone }); track('chain', G.combo);
  P.focus = Math.min(100, P.focus + 14);
  addFeed(tags);
  popup(tmpA.set(pos.x, pos.y + height, pos.z), '+' + pts, G.combo >= 3 || bonus ? 'gold' : '');
  if (!bonus && G.combo >= 2) { callout(CHAIN_NAMES[G.combo]); sfx.blip(); }
  return pts;
}
/** If that was the wave's last enemy, slow the moment down (and swing the kill-cam round a soldier). */
export function checkLastKill(s) {
  const others = world.soldiers.some(o => o !== s && !o.dead && !o.idle) || world.drones.some(d => !d.dead);
  if (others || G.toSpawn > 0 || G.bossPending || G.mode !== 'play') return;
  G.finalT = 1.1; G.flash = Math.max(G.flash, 0.3); rumble(0.3, 0.5, 200);
  if (s && MOTION > 0.5 && settings.killcam === 'on') {
    // kill-cam: swing round the body in slow motion from one side of the player's view
    const side = Math.random() < 0.5 ? -1 : 1;
    G.killCam = { s, t: 0, dur: 1.7, a0: Math.atan2(camera.position.x - s.pos.x, camera.position.z - s.pos.z) + side * 0.9, spin: side * 0.55 };
    G.finalT = 1.7; document.body.classList.add('cinema');
  }
}

export function killSoldier(s, head, extra) {
  // fall the way the killing blow pushed; big hits launch the body
  const impact = new V3(s.knock.x, 0, s.knock.z);
  if (impact.lengthSq() < 1e-4) impact.set(s.pos.x - P.pos.x, 0, s.pos.z - P.pos.z);
  impact.normalize();
  const kind = extra.includes('STOMP') || extra.includes('CRUSHED') ? 'crush' : head ? 'head'
    : ['KATANA', 'HELLFIRE', 'IMPACT', 'ROADKILL', 'FREEFALL', 'TRAMPLED', 'LIGHTNING', 'KABOOM', 'RECALL'].some(t => extra.includes(t)) ? 'blast' : 'shot';
  s.vel.set(s.knock.x * 1.6, kind === 'blast' ? 3 : 0.4, s.knock.z * 1.6); s.knock.set(0, 0, 0);
  beginDeath(s, kind, impact);

  // gore, scaled by how brutal the kill was
  const brutal = head || s.boss || ['STOMP', 'KATANA', 'ROADKILL', 'HELLFIRE', 'KABOOM'].some(t => extra.includes(t));
  const chest = new V3(s.pos.x, s.pos.y + 1.2 * s.scale, s.pos.z);
  bleed(chest, s.boss ? 180 : brutal ? 70 : 40, s.boss ? 8 : 5, 2);
  spawnGibs(chest, s.boss ? 18 : brutal ? 7 : 3, s.boss ? 8 : 5);
  splat(s.pos, s.boss ? 0.9 : 0.3);
  if (head || extra.includes('STOMP')) {
    s.head.visible = false;
    const neck = tmpA.set(s.pos.x, s.pos.y + 1.75 * s.scale, s.pos.z);
    bleed(neck, 45, 3, 5); spawnGibs(neck, 4, 4);
  }

  const base = { grunt: 100, rusher: 150, sniper: 200, shield: 250 }[s.kind] || 100;
  awardKill(s.pos, base, head, extra, 2.1 * s.scale, s.boss ? 5000 * Math.ceil(G.wave / 5) : 0);
  checkLastKill(s);
  if (s.boss) {
    callout('JUGGERNAUT DOWN'); track('boss');
    for (const t of ['life', 'hellfire', 'health']) dropPickup(s.pos, t);
    G.hitStop = 0.5; G.flash = 1; G.shake = 1;
  } else {
    rollDrop(s.pos);
    G.hitStop = Math.max(G.hitStop, head ? 0.08 : 0.05); G.flash = Math.max(G.flash, 0.18);
  }
  flashHit(true); sfx.kill();
}

// ---- stomps and slams
export function stomp(s) {
  P.vel.y = 11; P.airJumps = 1; P.diveT = 0;
  damageSoldier(s, s.boss ? 250 : 999, false, tmpB.set(0, -1, 0), ['STOMP']);
  if (s.boss && !s.dead) { bleed(tmpA.set(s.pos.x, s.pos.y + 2.9, s.pos.z), 30, 4, 3); s.knock.set(0, 0, 0); }
  G.shake = Math.max(G.shake, s.boss ? 0.32 : 0.8); G.hitStop = Math.max(G.hitStop, 0.09); sfx.stomp(); rumble(0.4, 0.4, 110);
  embers(tmpA.copy(P.pos), 20, 4, 0.4, 4);
}
/** A long drop hits the ground hard enough to take out everyone nearby. */
export function groundSlam(speed) {
  const reach = clamp(speed / 5, 3.5, 6.5);
  for (const s of world.soldiers) {
    if (!isLive(s)) continue;
    const dx = s.pos.x - P.pos.x, dz = s.pos.z - P.pos.z, d = Math.hypot(dx, dz) || 1;
    if (d > reach || Math.abs(s.pos.y - P.pos.y) > 1.5) continue;
    s.knock.set(dx / d * 10, 6, dz / d * 10);
    damageSoldier(s, s.boss ? 200 : 999, false, tmpB.set(dx / d, 0, dz / d), ['IMPACT']);
  }
  shockRing(P.pos, [3, 1.2, 0.3], reach, 0.45);
  embers(tmpA.set(P.pos.x, P.pos.y + 0.2, P.pos.z), 50, 7, 0.5, 6);
  G.shake = Math.max(G.shake, 0.9); G.hitStop = Math.max(G.hitStop, 0.1); G.flash = Math.max(G.flash, 0.3); sfx.stomp(); rumble(0.55, 0.6, 170);
}

// ---- Hellfire (Q): the screen-clearing bomb
const fireballGeo = new THREE.IcosahedronGeometry(1, 3);
export function hellfire() {
  if (G.mode !== 'play') return;
  if (G.hellfire <= 0) { sfx.empty(); return; }
  G.hellfire--;
  const c = new V3(P.pos.x, P.pos.y + 1, P.pos.z);
  explodeBarrelsNear(c, 16);
  for (const dr of world.drones) if (!dr.dead && dr.pos.distanceTo(c) < 18) dr.hurt(999, ['HELLFIRE']);
  const burned = world.bullets.length;
  for (const b of world.bullets) embers(b.pos, 6, 2, 0.5, 0);
  clearBullets();
  if (burned) { addScore(burned * 25); popup(tmpA.set(c.x, c.y + 1.6, c.z), `${burned} BULLETS BURNED`, 'gold'); }
  for (const s of world.soldiers) {
    if (!isLive(s)) continue;
    const dx = s.pos.x - c.x, dz = s.pos.z - c.z, d = Math.hypot(dx, dz) || 1;
    if (d > 16) continue;
    const k = s.boss ? 0.3 : 1;
    s.knock.set(dx / d * 18 * k, 7 * k, dz / d * 18 * k);
    damageSoldier(s, s.boss ? 300 : 250, false, tmpB.set(dx / d, 0, dz / d), ['HELLFIRE']);
  }
  const ball = new THREE.Mesh(fireballGeo, ownMat(THREE.MeshBasicMaterial, { color: new THREE.Color(3, 0.9, 0.2), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }));
  ball.position.copy(c);
  addFx(ball, 0.7, (o, k) => { o.scale.setScalar(0.5 + k * 16); o.material.opacity = 0.55 * (1 - k) * (1 - k); }, true);
  shockRing(tmpA.set(c.x, P.pos.y, c.z), [3, 2.6, 0.8], 16, 0.6);
  sparks.emit(c, 180, 13, EMBER[0], EMBER[1], EMBER[2], 0.8, 2);
  G.flash = 1; G.shake = 0.9; P.invT = Math.max(P.invT, 1.2); G.hitStop = Math.max(G.hitStop, 0.12);
  callout('HELLFIRE'); sfx.hellfire();
}
