// Visual effects: particle clouds, gore, and short-lived meshes (tracers, rings, flares).
import * as THREE from 'three';
import { scene } from './engine.js';
import { dotTex } from './textures.js';
import { V3, rand, tmpA } from './util.js';
import { level, moveBody } from './physics.js';

// ---- particle clouds
function makeCloud(max, size, blending) {
  const pos = new Float32Array(max * 3).fill(-999), col = new Float32Array(max * 3), vel = new Float32Array(max * 3), base = new Float32Array(max * 3);
  const life = new Float32Array(max), maxLife = new Float32Array(max), grav = new Float32Array(max);
  let next = 0;
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({ size, map: dotTex, vertexColors: true, transparent: true, depthWrite: false, blending }));
  pts.frustumCulled = false; scene.add(pts);
  return {
    /** n particles from p in random directions; colour fades to black over their life. */
    emit(p, n, spd, r, g, b, lf, gravity = 9, up = 0) {
      for (let k = 0; k < n; k++) {
        const i = next; next = (next + 1) % max;
        let x = Math.random() * 2 - 1, y = Math.random() * 2 - 1, z = Math.random() * 2 - 1;
        const l = Math.hypot(x, y, z) || 1, s = spd * rand(0.3, 1) / l;
        pos[i * 3] = p.x; pos[i * 3 + 1] = p.y; pos[i * 3 + 2] = p.z;
        vel[i * 3] = x * s; vel[i * 3 + 1] = y * s + up; vel[i * 3 + 2] = z * s;
        base[i * 3] = r; base[i * 3 + 1] = g; base[i * 3 + 2] = b;
        life[i] = maxLife[i] = lf * rand(0.6, 1.2); grav[i] = gravity;
      }
    },
    update(dt) {
      for (let i = 0; i < max; i++) {
        if (life[i] <= 0) continue;
        life[i] -= dt;
        if (life[i] <= 0) { pos[i * 3 + 1] = -999; continue; }
        vel[i * 3 + 1] -= grav[i] * dt;
        pos[i * 3] += vel[i * 3] * dt; pos[i * 3 + 1] += vel[i * 3 + 1] * dt; pos[i * 3 + 2] += vel[i * 3 + 2] * dt;
        const k = life[i] / maxLife[i];
        col[i * 3] = base[i * 3] * k; col[i * 3 + 1] = base[i * 3 + 1] * k; col[i * 3 + 2] = base[i * 3 + 2] * k;
      }
      geo.attributes.position.needsUpdate = true; geo.attributes.color.needsUpdate = true;
    },
  };
}
/** Glowing sparks (additive). */
export const sparks = makeCloud(2400, 0.11, THREE.AdditiveBlending);
/** Blood (normal blending, so it can be dark). */
const goreCloud = makeCloud(1800, 0.16, THREE.NormalBlending);

export const EMBER = [3, 1.15, 0.28];
export function embers(p, n, spd = 3, life = 0.5, gravity = -2) { sparks.emit(p, n, spd, EMBER[0], EMBER[1], EMBER[2], life, gravity); }
export function bleed(p, n, spd = 4, up = 1.5) { goreCloud.emit(p, n, spd, rand(0.4, 0.6), 0.015, 0.01, 0.9, 16, up); }

// ---- gibs and blood splats
const gibGeo = new THREE.BoxGeometry(1, 1, 1);
const gibMats = [0x7a0c0a, 0x9c1f18, 0x560505, 0xc79a86].map(c => new THREE.MeshStandardMaterial({ color: c, roughness: 0.45, metalness: 0.05 }));
let gibs = [];
export function spawnGibs(p, n, spd = 6) {
  for (let i = 0; i < n; i++) {
    const m = new THREE.Mesh(gibGeo, gibMats[(Math.random() * gibMats.length) | 0]);
    const sz = rand(0.08, 0.2); m.scale.set(sz, sz * rand(0.6, 1.2), sz * rand(0.7, 1.3)); m.castShadow = true; scene.add(m);
    gibs.push({
      m, t: 0, landed: false, r: 0.06, h: 0.08,
      pos: new V3(p.x + rand(-0.2, 0.2), p.y + rand(-0.2, 0.3), p.z + rand(-0.2, 0.2)),
      vel: new V3(rand(-1, 1) * spd, rand(2, 7), rand(-1, 1) * spd),
      spin: new V3(rand(-12, 12), rand(-12, 12), rand(-12, 12)),
    });
  }
  while (gibs.length > 90) scene.remove(gibs.shift().m);
}
function updateGibs(dt) {
  for (let i = gibs.length - 1; i >= 0; i--) {
    const g = gibs[i]; g.t += dt;
    if (g.t > 9 || g.pos.y < level.info.killY) { scene.remove(g.m); gibs.splice(i, 1); continue; }
    g.vel.y -= 22 * dt;
    const vy = g.vel.y;
    if (moveBody(g, dt)) {
      if (!g.landed && vy < -3) { g.landed = true; splat(g.pos, rand(0.1, 0.22)); }
      g.vel.x *= 0.82; g.vel.z *= 0.82;
      if (vy < -4) g.vel.y = -vy * 0.3;
      g.spin.multiplyScalar(0.8);
    } else if (Math.random() < 0.3) bleed(g.pos, 1, 0.3, 0);
    g.m.position.set(g.pos.x, g.pos.y + 0.04, g.pos.z);
    g.m.rotation.x += g.spin.x * dt; g.m.rotation.y += g.spin.y * dt; g.m.rotation.z += g.spin.z * dt;
    if (g.t > 7.5) g.m.scale.multiplyScalar(1 - 2 * dt);
  }
}
const splatGeo = new THREE.CircleGeometry(1, 14); splatGeo.rotateX(-Math.PI / 2);
const splatMat = new THREE.MeshBasicMaterial({ color: 0x2c0202, transparent: true, opacity: 0.88, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -16 });
let splats = [];
export function splat(p, size) {
  const m = new THREE.Mesh(splatGeo, splatMat);
  m.position.set(p.x, p.y + 0.022, p.z); m.scale.set(size * rand(0.7, 1.3), 1, size * rand(0.7, 1.3)); m.rotation.y = Math.random() * 6;
  scene.add(m); splats.push(m);
  if (splats.length > 140) scene.remove(splats.shift());
  return m;
}
export function clearGore() {
  for (const g of gibs) scene.remove(g.m);
  for (const m of splats) scene.remove(m);
  gibs = []; splats = [];
}
export function updateParticles(dt) { sparks.update(dt); goreCloud.update(dt); updateGibs(dt); }

// ---- short-lived meshes
const effects = [];
/** Add obj to the scene for `life` seconds (world time unless realTime), calling onUpdate(obj, 0..1) each frame. */
export function addFx(obj, life, onUpdate, realTime = false) { effects.push({ obj, t: 0, life, onUpdate, realTime }); scene.add(obj); }
export function updateFx(dtReal, dtWorld) {
  for (let i = effects.length - 1; i >= 0; i--) {
    const f = effects[i];
    f.t += f.realTime ? dtReal : dtWorld;
    const k = f.t / f.life;
    if (k >= 1) {
      scene.remove(f.obj);
      f.obj.traverse(c => { if (c.material && c.material.userData.own) c.material.dispose(); });
      effects.splice(i, 1); continue;
    }
    f.onUpdate(f.obj, k);
  }
}
/** A material owned by one effect, disposed with it. */
export function ownMat(Ctor, opts) { const m = new Ctor(opts); m.userData.own = true; return m; }
const additive = color => ({ color: new THREE.Color(...color), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });

const tracerGeo = new THREE.CylinderGeometry(0.012, 0.012, 1, 5, 1, true); tracerGeo.rotateX(Math.PI / 2); tracerGeo.translate(0, 0, 0.5);
export function spawnTracer(a, b, color, thick = 1) {
  const m = new THREE.Mesh(tracerGeo, ownMat(THREE.MeshBasicMaterial, additive(color)));
  m.position.copy(a); m.lookAt(b); m.scale.set(thick, thick, a.distanceTo(b));
  addFx(m, 0.09, (o, k) => { o.material.opacity = 1 - k; });
}

export const ringGeo = new THREE.TorusGeometry(0.16, 0.009, 6, 28);
/** Air ripple left behind a bullet in slow motion. */
export function spawnRipple(p, vel) {
  const m = new THREE.Mesh(ringGeo, ownMat(THREE.MeshBasicMaterial, { ...additive([1.4, 1.05, 0.8]), opacity: 0.5 }));
  m.position.copy(p); m.lookAt(tmpA.copy(p).add(vel));
  addFx(m, 0.75, (o, k) => { const s = 1 + k * 5; o.scale.set(s, s, 1); o.material.opacity = 0.45 * (1 - k); }, true);
}
/** Flat shockwave ring on the ground, growing to `reach` metres. */
export function shockRing(p, color, reach, life) {
  const m = new THREE.Mesh(ringGeo, ownMat(THREE.MeshBasicMaterial, additive(color)));
  m.rotation.x = -Math.PI / 2; m.position.set(p.x, p.y + 0.12, p.z);
  addFx(m, life, (o, k) => { const s = 1 + k * reach * 6.25; o.scale.set(s, s, 1); o.material.opacity = 1 - k; }, true);
}
const flareGeo = new THREE.CylinderGeometry(0.8, 0.8, 9, 24, 1, true); flareGeo.translate(0, 4.5, 0);
/** Red flare column where a soldier is about to drop in. */
export function spawnFlare(x, y, z, size = 1) {
  const m = new THREE.Mesh(flareGeo, ownMat(THREE.MeshBasicMaterial, { ...additive([3, 0.55, 0.15]), opacity: 0, side: THREE.DoubleSide }));
  m.position.set(x, y, z);
  addFx(m, 1.3, (o, k) => { o.material.opacity = Math.sin(k * Math.PI) * 0.35; o.scale.set((1 - k * 0.5) * size, size, (1 - k * 0.5) * size); });
}
