// Keyboard, mouse (with pointer lock) and gamepad.
import { renderer } from './engine.js';
import { $, clamp } from './util.js';
import { toggleMusic } from './audio.js';
import { settings, setSetting } from './settings.js';
import {
  openSettings, closeSettings, isSettingsOpen, settingsMove, settingsAdjust, settingsActivate,
  isCapturing, captureDevice, endCapture,
} from './settingsUI.js';
import { bindings, keyAction, setKey, setPad, setPadStyle } from './bindings.js';
import { openStyle, closeStyle, isStyleOpen, styleMove, styleAdjust, styleActivate } from './style.js';
import { G, P, input } from './state.js';
import { setRumblePad } from './rumble.js';
import { slash, hellfire, startReload } from './combat.js';
import { throwKatana } from './blade.js';
import { navSync, navMove, navActivate, navShow } from './menuNav.js';
import {
  startGame, continueGame, pauseGame, resumeGame, quitToMenu, lockPointer,
  submitInitials, awaitingInitials, canContinue, selectStartStage, startTraining, startDaily,
} from './game.js';

const LOOK = 0.0022;
const PITCH_MIN = -1.25, PITCH_MAX = 1.2;
const toggleCrt = () => setSetting('crt', settings.crt === 'on' ? 'off' : 'on');
const invert = () => (settings.invertY === 'on' ? -1 : 1);

function bindMouseAndKeys() {
  let hadLock = false;
  document.addEventListener('pointerlockchange', () => {
    if (document.pointerLockElement === renderer.domElement) hadLock = true;
    else if (hadLock && G.mode === 'play') pauseGame();
  });
  // a mouse button binds like a key: 'Mouse0' left, 'Mouse1' middle, 'Mouse2' right
  addEventListener('mousedown', e => {
    if (isCapturing() && captureDevice() === 'key') { setKey(isCapturing(), 'Mouse' + e.button); endCapture(); e.preventDefault(); e.stopPropagation(); }
  }, true);
  renderer.domElement.addEventListener('mousedown', e => {
    if (G.mode !== 'play') return;
    if (!document.pointerLockElement) lockPointer();
    actionDown('Mouse' + e.button);
  });
  addEventListener('mouseup', e => actionUp('Mouse' + e.button));
  addEventListener('contextmenu', e => e.preventDefault());
  addEventListener('mousemove', e => {
    if (G.mode !== 'play') { if (Math.abs(e.movementX) + Math.abs(e.movementY) > 2) navShow(false); return; }
    input.mouseAt = performance.now();
    P.yaw -= e.movementX * LOOK * settings.mouseSens;
    P.pitch = clamp(P.pitch - e.movementY * LOOK * settings.mouseSens * invert(), PITCH_MIN, PITCH_MAX);
  });
  addEventListener('keydown', e => {
    if (isStyleOpen()) {
      if (e.code === 'Escape') closeStyle();
      else if (e.code === 'ArrowUp') { styleMove(-1); e.preventDefault(); }
      else if (e.code === 'ArrowDown') { styleMove(1); e.preventDefault(); }
      else if (e.code === 'ArrowLeft') { styleAdjust(-1); e.preventDefault(); }
      else if (e.code === 'ArrowRight') { styleAdjust(1); e.preventDefault(); }
      else if (e.code === 'Enter' || e.code === 'Space') { styleActivate(); e.preventDefault(); }
      return;
    }
    if (isCapturing()) {
      // remapping: the next key becomes the binding (Esc cancels)
      if (captureDevice() === 'key' && e.code !== 'Escape') setKey(isCapturing(), e.code);
      endCapture(); e.preventDefault(); return;
    }
    if (isSettingsOpen()) {
      // keyboard control of the settings page
      if (e.code === 'Enter') { settingsActivate(false); e.preventDefault(); }
      if (e.code === 'Escape') closeSettings();
      else if (e.code === 'ArrowUp') { settingsMove(-1); e.preventDefault(); }
      else if (e.code === 'ArrowDown') { settingsMove(1); e.preventDefault(); }
      else if (e.code === 'ArrowLeft') { settingsAdjust(-1); e.preventDefault(); }
      else if (e.code === 'ArrowRight') { settingsAdjust(1); e.preventDefault(); }
      return;
    }
    if (e.target && e.target.tagName === 'INPUT') return; // typing initials
    if (!e.repeat && e.code === 'KeyM') toggleMusic();
    if (!e.repeat && e.code === 'KeyV') toggleCrt();
    if (!e.repeat && e.code === 'KeyN') setSetting('announcer', settings.announcer === 'on' ? 'off' : 'on');
    if (G.mode !== 'play') return;
    if (e.code === 'Escape') { if (!document.pointerLockElement) pauseGame(); return; }
    if (keyAction(e.code)) e.preventDefault();
    if (!e.repeat) actionDown(e.code);
  });
  addEventListener('keyup', e => actionUp(e.code));
  addEventListener('blur', () => {
    Object.assign(input.move, { forward: false, back: false, left: false, right: false });
    input.fire = input.focus = input.slashHeld = false;
  });
}
const MOVES = new Set(['forward', 'back', 'left', 'right']);
/** A bound key or mouse button went down during play. */
function actionDown(code) {
  const a = keyAction(code);
  if (!a || G.mode !== 'play') return;
  if (MOVES.has(a)) { input.move[a] = true; return; }
  switch (a) {
    case 'jump': input.jump = true; break;
    case 'dive': input.dive = true; break;
    case 'fire': input.fire = true; break;
    case 'focus': input.focus = true; break;
    case 'focusToggle': input.focusToggle = !input.focusToggle; break;
    case 'reload': startReload(); break;
    case 'slash': slash(); input.slashHeld = true; break;
    case 'hellfire': hellfire(); break;
    case 'throw': throwKatana(); break;
  }
}
function actionUp(code) {
  const a = keyAction(code);
  if (!a) return;
  if (MOVES.has(a)) input.move[a] = false;
  else if (a === 'fire') input.fire = false;
  else if (a === 'focus') input.focus = false;
  else if (a === 'slash') input.slashHeld = false;
}

function bindScreens() {
  $('playBtn').addEventListener('click', startGame);
  $('againBtn').addEventListener('click', startGame);
  $('contBtn').addEventListener('click', continueGame);
  $('resumeBtn').addEventListener('click', resumeGame);
  $('pauseMenuBtn').addEventListener('click', quitToMenu);
  $('overMenuBtn').addEventListener('click', quitToMenu);
  $('initForm').addEventListener('submit', e => { e.preventDefault(); submitInitials(); });
  for (const radio of document.querySelectorAll('input[name="stage"]')) {
    radio.addEventListener('change', () => { if (radio.checked) selectStartStage(+radio.value); });
  }
  $('settingsBtn').addEventListener('click', () => openSettings($('menu')));
  $('styleBtn').addEventListener('click', () => openStyle($('menu')));
  $('tutorialBtn').addEventListener('click', startTraining);
  $('dailyBtn').addEventListener('click', startDaily);
  $('pauseSettingsBtn').addEventListener('click', () => openSettings($('pause')));
}

// ---- gamepad (standard mapping: Xbox, PlayStation, Switch Pro)
const BTN = { A: 0, B: 1, X: 2, Y: 3, LB: 4, RB: 5, LT: 6, RT: 7, START: 9, L3: 10, UP: 12, DOWN: 13, LEFT: 14, RIGHT: 15 };
let padPrev = [];
const navHeld = {};
const deadzone = v => (Math.abs(v) < 0.18 ? 0 : (v - Math.sign(v) * 0.18) / 0.82);
function setPadNote() { $('padNote').textContent = 'Controller connected. D-pad or left stick to move · A / Cross to select · Start / Options to play. Shortcuts: X / Square style · Y / Triangle settings · L1 / LB tutorial · R1 / RB daily challenge.'; }

function navDir(up, down, left, right) {
  if (up) navMove(0, -1); else if (down) navMove(0, 1);
  else if (left) navMove(-1, 0); else if (right) navMove(1, 0);
}

export function pollGamepad(dt) {
  const pad = input.pad;
  const gp = [...(navigator.getGamepads ? navigator.getGamepads() : [])].find(g => g && g.connected);
  setRumblePad(gp || null);
  if (!gp) { if (pad.on) Object.assign(pad, { on: false, x: 0, y: 0, fire: false, focus: false, slash: false }); return; }
  if (!pad.on) { pad.on = true; setPadNote(); navShow(true); }
  setPadStyle(gp.id);
  if (isCapturing()) {
    // remapping: the next button pressed becomes the binding (Start / Options cancels)
    const b = gp.buttons.findIndex((x, i) => x.pressed && !padPrev[i]);
    if (b >= 0) { if (captureDevice() === 'pad' && b !== 9) setPad(isCapturing(), b); endCapture(); }
    padPrev = gp.buttons.map(x => x.pressed);
    return;
  }
  const held = i => !!(gp.buttons[i] && gp.buttons[i].pressed);
  const pressed = i => held(i) && !padPrev[i];
  const value = i => (gp.buttons[i] ? gp.buttons[i].value : 0);
  // d-pad, or the left stick pushed hard, with auto-repeat
  const dir = (btn, axis, sign) => held(btn) || (gp.axes[axis] || 0) * sign > 0.6;
  const repeat = (name, on) => {
    if (!on) { navHeld[name] = 0; return false; }
    navHeld[name] = (navHeld[name] || 0) + dt;
    if (navHeld[name] === dt) return true;
    if (navHeld[name] > 0.4) { navHeld[name] -= 0.12; return true; }
    return false;
  };
  const up = repeat('up', dir(BTN.UP, 1, -1)), down = repeat('down', dir(BTN.DOWN, 1, 1));
  const left = repeat('left', dir(BTN.LEFT, 0, -1)), right = repeat('right', dir(BTN.RIGHT, 0, 1));

  if (isStyleOpen()) {
    if (up) styleMove(-1); if (down) styleMove(1);
    if (left) styleAdjust(-1); if (right) styleAdjust(1);
    if (pressed(BTN.A)) styleActivate();
    if (pressed(BTN.B) || pressed(BTN.START)) closeStyle();
  } else if (isSettingsOpen()) {
    if (up) settingsMove(-1); if (down) settingsMove(1);
    if (left) settingsAdjust(-1); if (right) settingsAdjust(1);
    if (pressed(BTN.A)) settingsActivate(true);
    if (pressed(BTN.B) || pressed(BTN.START)) closeSettings();
  } else if (G.mode === 'menu') {
    navSync();
    if (pressed(BTN.START)) startGame();
    else if (pressed(BTN.A)) navActivate();
    else if (pressed(BTN.Y)) openSettings($('menu'));
    else if (pressed(BTN.X)) openStyle($('menu'));
    else if (pressed(BTN.LB)) startTraining();
    else if (pressed(BTN.RB)) startDaily();
    else navDir(up, down, left, right);
  } else if (G.mode === 'paused') {
    navSync();
    if (pressed(BTN.START)) resumeGame();
    else if (pressed(BTN.A)) navActivate();
    else if (pressed(BTN.Y)) openSettings($('pause'));
    else if (pressed(BTN.B)) quitToMenu();
    else navDir(up, down, left, right);
  } else if (G.mode === 'dead' && !$('over').hidden) {
    navSync();
    if (pressed(BTN.A) && awaitingInitials()) submitInitials();
    else if (pressed(BTN.A)) navActivate();
    else if (pressed(BTN.START)) {
      if (awaitingInitials()) submitInitials();
      else if (canContinue()) continueGame();
      else startGame();
    } else if (pressed(BTN.B)) quitToMenu();
    else if (pressed(BTN.Y)) startGame();
    else navDir(up, down, left, right);
  } else if (G.mode === 'play') {
    pad.x = deadzone(gp.axes[0] || 0); pad.y = -deadzone(gp.axes[1] || 0);
    const rx = deadzone(gp.axes[2] || 0), ry = deadzone(gp.axes[3] || 0);
    if (pad.x || pad.y || rx || ry) input.mouseAt = 0; // playing on the pad: no need to capture the mouse
    P.yaw -= rx * Math.abs(rx) * 3.4 * settings.padSens * dt;
    P.pitch = clamp(P.pitch - ry * Math.abs(ry) * 2.4 * settings.padSens * invert() * dt, PITCH_MIN, PITCH_MAX);
    const bp = bindings.pad;
    pad.fire = value(bp.fire) > 0.3;
    pad.focus = value(bp.focus) > 0.3;
    pad.slash = held(bp.slash);
    if (pressed(bp.jump)) input.jump = true;
    if (pressed(bp.dive) || (pressed(BTN.L3) && !Object.values(bp).includes(BTN.L3))) input.dive = true;
    if (pressed(bp.slash)) slash();
    if (pressed(bp.reload)) startReload();
    if (pressed(bp.focusToggle)) input.focusToggle = !input.focusToggle;
    if (pressed(bp.hellfire)) hellfire();
    if (pressed(bp.throw)) throwKatana();
    if (pressed(BTN.START)) pauseGame();
  }
  padPrev = gp.buttons.map(b => b.pressed);
}

export function bindInput() {
  bindMouseAndKeys();
  bindScreens();
  addEventListener('gamepadconnected', setPadNote);
}
