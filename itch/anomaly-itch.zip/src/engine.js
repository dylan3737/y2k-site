// Renderer, scene, camera, lights and the post-processing stack.
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { $ } from './util.js';

const pixelRatio = Math.min(devicePixelRatio, 1.5);

export const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
renderer.setPixelRatio(pixelRatio);
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.35;
$('stage').appendChild(renderer.domElement);

export const scene = new THREE.Scene();
scene.background = new THREE.Color(0x070403);
scene.fog = new THREE.FogExp2(0x0a0503, 0.021);

export const camera = new THREE.PerspectiveCamera(82, innerWidth / innerHeight, 0.08, 300);
camera.rotation.order = 'YXZ';
scene.add(camera);

// strong warm sky fill so nothing sits in pure black
export const hemi = new THREE.HemisphereLight(0xffc9a0, 0x3a2418, 1.1);
scene.add(hemi);
export const sun = new THREE.DirectionalLight(0xffd2a8, 1.5);
sun.position.set(18, 40, 12);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, { left: -46, right: 46, top: 36, bottom: -36, near: 1, far: 100 });
sun.shadow.bias = -0.0006;
scene.add(sun, sun.target);

/** Keep the shadow frustum centred on the action (snapped to reduce shimmer). */
export function followSun(p) {
  const x = Math.round(p.x / 4) * 4, z = Math.round(p.z / 4) * 4;
  sun.target.position.set(x, 0, z);
  sun.position.set(x + 18, 40 + Math.max(0, p.y), z + 12);
}

export function setFov(fov) {
  if (Math.abs(camera.fov - fov) > 0.05) { camera.fov = fov; camera.updateProjectionMatrix(); }
}

// ---- post: bloom, then a grade pass (CRT, slow-motion sepia, hurt vignette, flash)
// 4x MSAA on the scene render: stops thin ledges, parapets and edges crawling as the camera moves
const sceneTarget = new THREE.WebGLRenderTarget(innerWidth * pixelRatio, innerHeight * pixelRatio, { type: THREE.HalfFloatType, samples: 4 });
export const composer = new EffectComposer(renderer, sceneTarget);
composer.setPixelRatio(pixelRatio);
composer.setSize(innerWidth, innerHeight);
composer.addPass(new RenderPass(scene, camera));
export const bloom = new UnrealBloomPass(new THREE.Vector2(innerWidth, innerHeight), 0.85, 0.45, 0.72);
composer.addPass(bloom);

export const grade = new ShaderPass({
  uniforms: {
    tDiffuse: { value: null }, amount: { value: 0 }, hurt: { value: 0 }, flash: { value: 0 }, crt: { value: 1 },
    lo: { value: new THREE.Vector3(1, 1, 1) }, hi: { value: new THREE.Vector3(1, 1, 1) }, sat: { value: 1 }, con: { value: 1 }, // per-stage grade
    res: { value: new THREE.Vector2(innerWidth, innerHeight) },
  },
  vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
  fragmentShader: `
    uniform sampler2D tDiffuse; uniform float amount; uniform float hurt; uniform float flash; uniform float crt; uniform vec2 res; varying vec2 vUv;
    uniform vec3 lo; uniform vec3 hi; uniform float sat; uniform float con;
    void main(){
      vec2 uv=vUv;
      if(crt>0.5){
        vec2 cc=uv-0.5; uv=0.5+cc*(1.0+0.28*dot(cc,cc))*0.975;
        if(uv.x<0.0||uv.x>1.0||uv.y<0.0||uv.y>1.0){ gl_FragColor=vec4(0.0,0.0,0.0,1.0); return; }
        vec2 px=res/2.0; uv=(floor(uv*px)+0.5)/px;
      }
      vec2 c=uv-0.5; float d=length(c);
      float ca=0.0015+amount*0.012*d+crt*0.0015;
      vec3 col=vec3(texture2D(tDiffuse,uv+c*ca).r, texture2D(tDiffuse,uv).g, texture2D(tDiffuse,uv-c*ca).b);
      if(amount>0.01){
        vec3 acc=vec3(0.0);
        for(int i=0;i<7;i++){ float s=1.0-float(i)*0.014*amount*d; acc+=texture2D(tDiffuse,0.5+c*s).rgb; }
        col=mix(col,acc/7.0,amount*0.7);
        float lum=dot(col,vec3(0.299,0.587,0.114));
        float red=clamp((col.r-max(col.g,col.b))*3.0,0.0,1.0);
        col=mix(col,vec3(lum*1.22,lum*0.92,lum*0.7),amount*0.8*(1.0-red));
      }
      // the stage's grade: saturation, contrast about mid-grey, then a tint for the shadows and one for the lights
      float l0=dot(col,vec3(0.2126,0.7152,0.0722));
      col=mix(vec3(l0),col,sat);
      col=0.18*pow(max(col,vec3(0.0))/0.18,vec3(con));
      col*=mix(lo,hi,smoothstep(0.02,0.5,l0));
      if(crt>0.5){
        col*=0.88+0.12*pow(abs(sin(vUv.y*res.y*1.5707963)),1.5);
        float m=mod(gl_FragCoord.x,3.0);
        col*=vec3(m<1.0?1.12:0.93,(m>=1.0&&m<2.0)?1.12:0.93,m>=2.0?1.12:0.93)*1.1;
      } else col*=0.965+0.035*sin(uv.y*res.y*1.4);
      col*=mix(0.72,1.0,smoothstep(0.85,0.2,d));
      col=mix(col,vec3(0.7,0.03,0.03),hurt*smoothstep(0.25,0.75,d));
      col=mix(col,vec3(1.0),flash*0.45);
      gl_FragColor=vec4(col,1.0);
    }`,
});
composer.addPass(grade);
composer.addPass(new OutputPass());

/** Graphics presets: resolution scale, anti-aliasing, sun shadows and bloom. */
export const QUALITY = {
  low: { pr: 0.75, samples: 0, shadow: 0, bloom: false },
  medium: { pr: 1, samples: 2, shadow: 1024, bloom: true },
  high: { pr: 1.5, samples: 4, shadow: 2048, bloom: true },
};
export function applyQuality(name) {
  const q = QUALITY[name] || QUALITY.high;
  const pr = Math.min(devicePixelRatio, q.pr);
  renderer.setPixelRatio(pr); composer.setPixelRatio(pr);
  renderer.setSize(innerWidth, innerHeight); composer.setSize(innerWidth, innerHeight);
  for (const rt of [composer.renderTarget1, composer.renderTarget2]) {
    if (rt.samples !== q.samples) { rt.samples = q.samples; rt.dispose(); } // rebuilt at the new sample count on next use
  }
  bloom.enabled = q.bloom;
  sun.castShadow = q.shadow > 0;
  if (q.shadow && sun.shadow.mapSize.x !== q.shadow) {
    sun.shadow.mapSize.set(q.shadow, q.shadow);
    if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null; }
  }
}

addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight); composer.setSize(innerWidth, innerHeight);
  grade.uniforms.res.value.set(innerWidth, innerHeight);
});
