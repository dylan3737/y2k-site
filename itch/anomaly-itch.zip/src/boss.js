// The Juggernaut: armour to strip, four telegraphed attacks, and windows where he's open.
// He is built and killed like any soldier (soldiers.js); this is his AI.
import { scene } from './engine.js';
import { V3, rand, clamp, damp, lerpAngle, tmpA, MOTION } from './util.js';
import { SM } from './materials.js';
import { moveBody, groundBelow, rayWorld } from './physics.js';
import { settings } from './settings.js';
import { sparks, embers, addFx, shockRing } from './fx.js';
import { callout, popup } from './ui.js';
import { rumble } from './rumble.js';
import { sfx } from './audio.js';
import { T } from './config.js';
import { G, P, world } from './state.js';
import { damageSoldier } from './combat.js';
import { hurtPlayer } from './player.js';
import { addScore } from './game.js';
import { spawnBullet } from './bullets.js';
import { isLive, hasLineOfSight, shoot, animateSoldierBody, poseRifle } from './soldiers.js';

const BOSS = { walk: 3.4, charge: 17, chargeTime: 1.3, slamReach: 15, slamSpeed: 22 };
const windups = new Set(['windCharge', 'windSlam', 'windSpray']);
function bossState(s, state) { Object.assign(s.bs, { state, t: 0, n: 0 }); }

// ---- the entrance: he drops in from above with the camera on him, lands with a shockwave and roars
const UP = new V3(0, 1, 0), INTRO_DROP = 9, INTRO_HOLD = 1.1;
/** Called the moment he appears. The landing is all show: it can't hurt you, and you can't be hit while the camera is away. */
export function bossIntro(s) {
  bossState(s, 'intro'); s.bs.landed = false; s.bs.cd = 99;
  // fall from as high as the space allows (indoor stages have ceilings); no room, and he just roars where he stands
  const room = rayWorld(tmpA.set(s.pos.x, s.pos.y + 1, s.pos.z), UP, INTRO_DROP + 4) - 1 - 3.4;
  const h = clamp(room, 0, INTRO_DROP);
  if (h > 1.5) { s.pos.y += h; s.model.position.copy(s.pos); s.vel.set(0, -2, 0); }
  const dur = Math.sqrt(2 * h / T.gravity) + INTRO_HOLD + 0.3;
  P.invT = Math.max(P.invT, dur + 0.4);
  if (MOTION > 0.5 && settings.killcam === 'on') {
    // low and in front of him, looking up, drifting a little round
    G.killCam = { s, t: 0, dur, a0: Math.atan2(P.pos.x - s.pos.x, P.pos.z - s.pos.z) + 0.5, spin: 0.12, aim: 1, lift: 0.08, rad: 2.6 };
    document.body.classList.add('cinema');
  }
  sfx.whoosh(0.5);
}
function landIntro(s) {
  s.bs.landed = true; s.bs.t = 0;
  shockRing(s.pos, [3, 0.5, 0.2], 9, 0.5); // the same ring as his slam, smaller, and harmless
  embers(tmpA.set(s.pos.x, s.pos.y + 0.3, s.pos.z), 50, 7, 0.5, 5);
  sfx.stomp(); sfx.impact(); sfx.roar();
  G.shake = Math.max(G.shake, 0.8); G.parryT = 0.35; rumble(0.3, 0.35, 180);
  callout('JUGGERNAUT');
}

/** Damage the Juggernaut actually takes: armour soaks most of it until it's gone; stuns and staggers open him up. */
export function bossDamage(s, dmg) {
  const b = s.bs, mult = b.state === 'stun' ? 2 : b.state === 'stagger' ? 1.5 : 1;
  const plate = s.armor.find(p => p.hp > 0);
  if (!plate) return dmg * mult;
  plate.hp -= dmg;
  plate.mesh.getWorldPosition(tmpA);
  sparks.emit(tmpA, 10, 5, 3, 1.5, 0.5, 0.2, 10); sfx.ricochet();
  if (plate.hp <= 0) breakPlate(s, plate);
  return dmg * 0.12 * mult;
}
function breakPlate(s, p) {
  const m = p.mesh;
  scene.attach(m);
  const v = new V3(rand(-4, 4), rand(5, 8), rand(-4, 4)), spin = new V3(rand(-9, 9), rand(-9, 9), rand(-9, 9));
  let last = 0;
  addFx(m, 1.8, (o, k) => {
    const d = (k - last) * 1.8; last = k;
    v.y -= T.gravity * d; o.position.addScaledVector(v, d);
    o.rotation.x += spin.x * d; o.rotation.y += spin.y * d; o.rotation.z += spin.z * d;
  });
  sfx.clang(); G.shake = Math.max(G.shake, 0.35); rumble(0.3, 0.2, 90);
  embers(m.position, 16, 4, 0.4, 2);
  const left = s.armor.filter(a => a.hp > 0).length;
  if (left) popup(tmpA.set(s.pos.x, s.pos.y + 3.4, s.pos.z), `ARMOR ${left}`, 'cyan');
  else {
    // fully stripped: he staggers, and the world slows for a beat
    callout('ARMOR BROKEN'); bossState(s, 'stagger'); G.parryT = 0.45; addScore(1000);
  }
}
/** A katana cut that lands mid-charge knocks him into a stun. */
export function counterBoss(s) {
  if (!s.boss || s.dead || s.bs.state !== 'charge') return false;
  bossState(s, 'stun'); s.vel.set(0, 0, 0);
  popup(tmpA.set(s.pos.x, s.pos.y + 3.4, s.pos.z), 'COUNTER', 'gold'); callout('COUNTER'); addScore(750);
  G.hitStop = Math.max(G.hitStop, 0.1); G.shake = Math.max(G.shake, 0.6); rumble(0.5, 0.5, 160);
  return true;
}
function pickAttack(s, dist) {
  const r = Math.random(), los = s.los;
  if (dist < 7) bossState(s, r < 0.65 ? 'windSlam' : los ? 'burst' : 'windSlam');
  else if (dist < 22) bossState(s, r < 0.45 ? 'windCharge' : !los ? 'walk' : r < 0.75 ? 'windSpray' : 'burst');
  else bossState(s, los ? (r < 0.5 ? 'windSpray' : 'burst') : 'walk');
  const b = s.bs;
  if (b.state === 'windCharge') sfx.roar();
  if (b.state === 'windSlam') sfx.roar();
  if (b.state === 'windSpray') sfx.lockOn();
}
/** One frame of the Juggernaut: pick and run his attacks, move him, pose him. */
export function updateBoss(s, dt, dx, dz, dist) {
  const b = s.bs, play = G.mode === 'play';
  b.t += dt; b.cd -= dt;
  s.losT -= dt; if (s.losT <= 0) { s.losT = 0.25; s.los = hasLineOfSight(s); }
  const tx = dx / dist, tz = dz / dist, dy = (P.pos.y + 1.2) - (s.pos.y + 1.45 * s.scale);
  let mx = 0, mz = 0, face = Math.atan2(dx, dz), aim = s.los && dist < 55, crouch = 0, lean = 0, charging = false;
  switch (b.state) {
    case 'intro':
      aim = false;
      if (!b.landed) crouch = -0.2; // legs out under him on the way down
      else {
        crouch = b.t < 0.25 ? 1 : 0.15; lean = b.t < 0.25 ? 0.3 : -0.15; // soak the landing, then rear back into the roar
        if (b.t > INTRO_HOLD) { bossState(s, 'walk'); b.cd = 1.5; }
      }
      break;
    case 'walk':
      s.strafeT -= dt; if (s.strafeT <= 0) { s.strafeT = rand(1.5, 3); s.strafeDir = -(s.strafeDir || 1); }
      if (dist > 11 || !s.los) { mx = tx; mz = tz; } else { mx = -tz * s.strafeDir; mz = tx * s.strafeDir; }
      if (!groundBelow(s.pos.x + mx * 2, s.pos.z + mz * 2, s.pos.y)) { mx = 0; mz = 0; s.strafeDir = -s.strafeDir; } // don't walk off edges (a charge still can)
      if (play && b.cd <= 0) pickAttack(s, dist);
      break;
    case 'burst':
      if (b.t > 0.25 + b.n * 0.11 && play) { shoot(s, Math.hypot(dist, dy)); b.n++; }
      if (b.n >= 6) { bossState(s, 'walk'); b.cd = rand(1.2, 2); }
      break;
    case 'windSpray': crouch = 0.3; if (b.t > 0.45) { bossState(s, 'spray'); b.sweep = Math.random() < 0.5 ? -1 : 1; } break;
    case 'spray': {
      // a fan of rounds swept across the player: stand your ground and parry, or get low and move
      const N = 14, gap = 1.1 / N, base = face;
      if (b.n < N && b.t > b.n * gap && play) {
        const a = base + b.sweep * (-0.6 + 1.2 * (b.n / (N - 1)));
        s.model.updateMatrixWorld(true);
        const m = s.muzzle.getWorldPosition(new V3());
        const v = new V3(Math.sin(a), 0, Math.cos(a)).multiplyScalar(T.enemyBulletSpeed);
        v.y = (P.pos.y + 1.1 - m.y) / Math.max(dist, 1) * T.enemyBulletSpeed;
        spawnBullet(m, v, 0.8); s.kick = 1; b.n++;
        sfx.enemyShot(clamp(9 / (dist + 4), 0.1, 0.8), 0.9);
      }
      if (b.n >= N && b.t > 1.3) { bossState(s, 'walk'); b.cd = rand(1.4, 2.2); }
      break;
    }
    case 'windCharge':
      // head down, visor flaring: then he commits to a line
      crouch = 0.8; lean = 0.35; aim = false;
      if (b.t > 0.85) { bossState(s, 'charge'); b.dir.set(tx, 0, tz); }
      break;
    case 'charge': {
      charging = true; aim = false; lean = 0.45; face = Math.atan2(b.dir.x, b.dir.z);
      s.vel.x = b.dir.x * BOSS.charge; s.vel.z = b.dir.z * BOSS.charge;
      if (play && dist < 2 * s.scale && Math.abs(dy) < 2.2 && P.invT <= 0) {
        hurtPlayer(30);
        P.vel.set(b.dir.x * 16, 8, b.dir.z * 16); G.shake = Math.max(G.shake, 0.9); rumble(0.6, 0.7, 220);
        bossState(s, 'recover');
      }
      // anyone else in the way gets flattened
      for (const o of world.soldiers) {
        if (o === s || !isLive(o) || Math.hypot(o.pos.x - s.pos.x, o.pos.z - s.pos.z) > 1.6) continue;
        o.knock.set(b.dir.x * 14, 7, b.dir.z * 14); damageSoldier(o, 999, false, b.dir, ['TRAMPLED']);
      }
      if (b.t > BOSS.chargeTime) bossState(s, 'recover');
      break;
    }
    case 'stun': crouch = 1; lean = 0.5; aim = false; s.flinch = Math.max(s.flinch, 0.4); if (b.t > 1.7) { bossState(s, 'walk'); b.cd = 1; } break;
    case 'stagger': crouch = 0.9; lean = -0.2; aim = false; s.flinch = Math.max(s.flinch, 0.5); if (b.t > 1.8) { bossState(s, 'walk'); b.cd = 1.2; } break;
    case 'recover': crouch = 0.3; if (b.t > 0.7) { bossState(s, 'walk'); b.cd = rand(1.3, 2.2); } break;
    case 'windSlam': crouch = 1; aim = false; if (b.t > 0.55) { s.vel.y = 10.5; bossState(s, 'air'); } break;
    case 'air':
      aim = false; crouch = -0.2;
      { const k = clamp((dist - 5) / 5, 0, 1); mx = tx * k; mz = tz * k; } // drift in, but land ~5 m short so the wave can be jumped
      break;
  }
  // the visor burns brighter through every wind-up
  SM.bossVisor.emissiveIntensity = windups.has(b.state) || charging || b.state === 'intro' ? 6 + Math.sin(G.clock * 40) * 2 : 3;
  s.bossCrouch = damp(s.bossCrouch || 0, crouch, 10, dt);
  s.bossLean = damp(s.bossLean || 0, lean, 8, dt);

  if (!charging) {
    const sp = b.state === 'air' ? 5 : b.state === 'walk' ? BOSS.walk : 0;
    s.vel.x = damp(s.vel.x, mx * sp, 6, dt); s.vel.z = damp(s.vel.z, mz * sp, 6, dt);
  }
  if (s.knock.lengthSq() > 0) { s.vel.add(s.knock.multiplyScalar(0.3)); s.knock.set(0, 0, 0); }
  s.vel.y -= T.gravity * dt;
  const bx = s.pos.x, bz = s.pos.z;
  let grounded = false;
  const steps = Math.ceil(dt * Math.hypot(s.vel.x, s.vel.z) / 0.2) || 1;
  for (let i = 0; i < steps; i++) grounded = moveBody(s, dt / steps) || grounded;
  if (charging && b.t > 0.15 && Math.hypot(s.pos.x - bx, s.pos.z - bz) < BOSS.charge * dt * 0.35) {
    // ran into a wall: dazed and open
    bossState(s, 'stun'); s.vel.set(0, 0, 0);
    sfx.stomp(); G.shake = Math.max(G.shake, 0.7); embers(tmpA.set(s.pos.x, s.pos.y + 2.5, s.pos.z), 20, 4, 0.4, 3);
    popup(tmpA.set(s.pos.x, s.pos.y + 3.4, s.pos.z), 'STUNNED', 'gold');
  }
  if (b.state === 'intro' && !b.landed && grounded) landIntro(s);
  if (b.state === 'air' && b.t > 0.25 && grounded) {
    // the slam: a shockwave rolls out along the ground; jump it
    b.wave = { x: s.pos.x, y: s.pos.y, z: s.pos.z, r: 0, hit: false };
    shockRing(s.pos, [3, 0.5, 0.2], BOSS.slamReach, BOSS.slamReach / BOSS.slamSpeed);
    embers(tmpA.set(s.pos.x, s.pos.y + 0.3, s.pos.z), 40, 7, 0.5, 5);
    sfx.stomp(); sfx.impact(); G.shake = Math.max(G.shake, 0.8); rumble(0.4, 0.6, 200);
    bossState(s, 'recover');
  }
  if (b.wave) {
    const w = b.wave;
    w.r += BOSS.slamSpeed * dt;
    const d = Math.hypot(P.pos.x - w.x, P.pos.z - w.z);
    if (play && !w.hit && Math.abs(d - w.r) < 1 && P.pos.y - w.y < 0.6 && P.invT <= 0) {
      w.hit = true; hurtPlayer(25);
      P.vel.set((P.pos.x - w.x) / (d || 1) * 8, 9, (P.pos.z - w.z) / (d || 1) * 8);
    }
    if (w.r > BOSS.slamReach) b.wave = null;
  }

  // pose
  s.model.position.copy(s.pos);
  s.model.rotation.y = lerpAngle(s.model.rotation.y, face, 1 - Math.exp(-(charging ? 14 : 6) * dt));
  animateSoldierBody(s, dt, aim, dist, dy);
  poseRifle(s, -(Math.PI / 2 + Math.atan2(dy, dist)), aim || b.state === 'spray', dt, 0);
}
