// Remappable controls: one keyboard/mouse binding and one controller button per action, saved in this browser.
// Moving and looking with the sticks, and Esc / Start for pause, stay fixed.
import { store } from './util.js';

export const ACTIONS = [
  { id: 'forward', label: 'Move forward', key: 'KeyW' },
  { id: 'back', label: 'Move back', key: 'KeyS' },
  { id: 'left', label: 'Move left', key: 'KeyA' },
  { id: 'right', label: 'Move right', key: 'KeyD' },
  { id: 'jump', label: 'Jump', key: 'Space', pad: 0, desc: 'Double jump in the air, kick off walls' },
  { id: 'dive', label: 'Shootdodge', key: 'ShiftLeft', pad: 1, desc: 'Slow-motion dive; flips if airborne, lands in a slide' },
  { id: 'fire', label: 'Fire', key: 'Mouse0', pad: 7 },
  { id: 'focus', label: 'Bullet time (hold)', key: 'Mouse2', pad: 6 },
  { id: 'focusToggle', label: 'Bullet time (toggle)', key: 'KeyE', pad: 4 },
  { id: 'slash', label: 'Katana', key: 'KeyF', pad: 2, desc: 'Tap three times for a finisher; hold, then release to dash-cut' },
  { id: 'reload', label: 'Reload', key: 'KeyR', pad: 3 },
  { id: 'throw', label: 'Throw katana', key: 'KeyG', pad: 11, desc: 'Pins the first enemy it hits to the wall behind; press again to recall it' },
  { id: 'hellfire', label: 'Hellfire', key: 'KeyQ', pad: 5, desc: 'Burns every bullet out of the air and blasts nearby enemies' },
];
const RESERVED_KEYS = new Set(['Escape', 'KeyM', 'KeyV', 'KeyN']); // pause and the quick toggles
const RESERVED_PAD = new Set([9, 12, 13, 14, 15]);             // Start/Options and the d-pad (menus)

function defaults() {
  return {
    key: Object.fromEntries(ACTIONS.map(a => [a.id, a.key])),
    pad: Object.fromEntries(ACTIONS.filter(a => a.pad != null).map(a => [a.id, a.pad])),
  };
}
function load() {
  const b = defaults();
  try {
    const saved = JSON.parse(store.get('bindings', '{}')) || {};
    for (const a of ACTIONS) {
      if (typeof saved.key?.[a.id] === 'string' && !RESERVED_KEYS.has(saved.key[a.id])) b.key[a.id] = saved.key[a.id];
      if (a.pad != null && Number.isInteger(saved.pad?.[a.id]) && !RESERVED_PAD.has(saved.pad[a.id])) b.pad[a.id] = saved.pad[a.id];
    }
  } catch { /* defaults */ }
  return b;
}
export const bindings = load();
const listeners = [];
export const onBindingsChange = fn => { listeners.push(fn); };
function changed() { store.set('bindings', JSON.stringify(bindings)); for (const fn of listeners) fn(); }

/** The action bound to a key code ('KeyW', 'Space', 'Mouse0'...), or null. */
export const keyAction = code => ACTIONS.find(a => bindings.key[a.id] === code)?.id || null;

/** Bind an action; whatever held that key or button before takes this action's old one (a swap). */
export function setKey(id, code) {
  if (RESERVED_KEYS.has(code)) return false;
  const other = keyAction(code);
  if (other && other !== id) bindings.key[other] = bindings.key[id];
  bindings.key[id] = code; changed(); return true;
}
export function setPad(id, btn) {
  if (RESERVED_PAD.has(btn) || !(id in bindings.pad)) return false;
  const other = Object.keys(bindings.pad).find(k => bindings.pad[k] === btn);
  if (other && other !== id) bindings.pad[other] = bindings.pad[id];
  bindings.pad[id] = btn; changed(); return true;
}
export function resetBindings() { Object.assign(bindings, defaults()); changed(); }

// ---- names for keys and buttons
const KEY_NAMES = {
  Space: 'Space', ShiftLeft: 'Left Shift', ShiftRight: 'Right Shift', ControlLeft: 'Left Ctrl', ControlRight: 'Right Ctrl',
  AltLeft: 'Left Alt', AltRight: 'Right Alt', Tab: 'Tab', CapsLock: 'Caps Lock', Enter: 'Enter', Backspace: 'Backspace',
  ArrowUp: '↑', ArrowDown: '↓', ArrowLeft: '←', ArrowRight: '→', Mouse0: 'Left mouse', Mouse1: 'Middle mouse', Mouse2: 'Right mouse',
  Mouse3: 'Mouse 4', Mouse4: 'Mouse 5', Backquote: '`', Minus: '-', Equal: '=', BracketLeft: '[', BracketRight: ']',
  Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/', Backslash: '\\',
};
export function keyName(code) {
  if (!code) return '—';
  if (KEY_NAMES[code]) return KEY_NAMES[code];
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  if (code.startsWith('Numpad')) return 'Num ' + code.slice(6);
  return code;
}
const XBOX = ['A', 'B', 'X', 'Y', 'LB', 'RB', 'LT', 'RT', 'View', 'Menu', 'L3', 'R3', 'D-pad ↑', 'D-pad ↓', 'D-pad ←', 'D-pad →', 'Home'];
const SONY = ['Cross', 'Circle', 'Square', 'Triangle', 'L1', 'R1', 'L2', 'R2', 'Create', 'Options', 'L3', 'R3', 'D-pad ↑', 'D-pad ↓', 'D-pad ←', 'D-pad →', 'PS'];
let sony = false;
/** Called with the connected pad's id so button names match it (PlayStation pads report Sony's vendor id). */
export function setPadStyle(id) {
  const s = /054c|dualsense|dualshock|wireless controller|playstation/i.test(id || '');
  if (s !== sony) { sony = s; for (const fn of listeners) fn(); }
}
export const padName = btn => (btn == null ? '—' : (sony ? SONY : XBOX)[btn] || `Button ${btn}`);
export const actionKey = id => keyName(bindings.key[id]);
export const actionPad = id => padName(bindings.pad[id]);
