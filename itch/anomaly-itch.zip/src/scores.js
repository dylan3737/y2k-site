// Top-five high score table, kept in this browser.
import { store, pad } from './util.js';
import { DEFAULT_SCORES } from './config.js';

function load() {
  try {
    const v = JSON.parse(store.get('scores', 'null'));
    if (Array.isArray(v) && v.length) return v.slice(0, 5);
  } catch { /* corrupt entry: fall back to the defaults */ }
  return DEFAULT_SCORES.map(e => ({ ...e }));
}
let table = load();
let pending = null;

export const topScore = () => (table[0] ? table[0].s : 0);
export const qualifies = score => score > 0 && (table.length < 5 || score > table[table.length - 1].s);
export const hasPending = () => pending !== null;

/** Hold a score until the player has typed their initials. */
export function holdScore(score) { pending = { s: score }; }

/** Save the held score under these initials; returns its table position (or -1 if nothing was held). */
export function commitPending(initials) {
  if (!pending) return -1;
  pending.n = (initials || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 3).padEnd(3, '-');
  table.push(pending); table.sort((a, b) => b.s - a.s); table = table.slice(0, 5);
  const idx = table.indexOf(pending);
  pending = null;
  store.set('scores', JSON.stringify(table));
  return idx;
}

export function renderScores(ol, mark = -1) {
  ol.textContent = '';
  table.forEach((e, i) => {
    const li = document.createElement('li'); if (i === mark) li.className = 'me';
    const rank = document.createElement('span'); rank.textContent = (i + 1) + '.';
    const name = document.createElement('span'); name.textContent = e.n;
    const score = document.createElement('b'); score.textContent = pad(e.s, 7);
    li.append(rank, name, score); ol.append(li);
  });
}
