// Drones: quadcopters that circle above you, fire short bursts, and now and then dive-bomb where you
// stand after a warning beep. Shoot them, cut them, stomp them, or catch them in a blast.
import * as THREE from 'three';
import { scene } from './engine.js';
import { V3, rand, clamp, damp, tmpA, tmpB } from './util.js';
import { SM, gunMat, outlineMat, addOutline } from './materials.js';
import { moveBody, rayWorld } from './physics.js';
import { sparks, embers, shockRing, EMBER } from './fx.js';
import { sfx } from './audio.js';
import { T } from './config.js';
import { G, P, world } from './state.js';
import { isLive } from './soldiers.js';
import { spawnBullet } from './bullets.js';
import { awardKill, damageSoldier, checkLastKill } from './combat.js';
import { hurtPlayer } from './player.js';
import { rumble } from './rumble.js';
import { surfaceY } from './events.js';
import { mergeRigidParts } from './merge.js';

const std = o => new THREE.MeshStandardMaterial(o);
const DM = {
  body: std({ color: 0x1c1f24, roughness: 0.35, metalness: 0.7 }),
  arm: std({ color: 0x2c3036, roughness: 0.5, metalness: 0.6 }),
  blade: new THREE.MeshBasicMaterial({ color: 0x9aa0a8, transparent: true, opacity: 0.45, depthWrite: false }),
};
const RADIUS = 0.5, DIVE_SPEED = 20;

function buildDrone() {
  const g = new THREE.Group();
  const add = (geo, mat, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; g.add(m); return m; };
  add(new THREE.BoxGeometry(0.6, 0.18, 0.6), DM.body, 0, 0, 0);
  add(new THREE.BoxGeometry(0.34, 0.12, 0.34), DM.arm, 0, 0.13, 0);
  const rotors = [];
  for (const [x, z] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
    const arm = add(new THREE.BoxGeometry(0.62, 0.05, 0.07), DM.arm, x * 0.28, 0.02, z * 0.28); arm.rotation.y = Math.atan2(-z, x);
    add(new THREE.CylinderGeometry(0.05, 0.05, 0.1, 8), DM.arm, x * 0.5, 0.07, z * 0.5);
    const rotor = new THREE.Group(); rotor.position.set(x * 0.5, 0.13, z * 0.5); g.add(rotor);
    for (const r of [0, Math.PI / 2]) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.01, 0.05), DM.blade); b.rotation.y = r; b.userData.noOutline = true; rotor.add(b); }
    rotors.push(rotor);
  }
  const eye = add(new THREE.SphereGeometry(0.08, 12, 8), SM.visor, 0, -0.02, 0.31); eye.userData.noOutline = true;
  const gun = add(new THREE.BoxGeometry(0.06, 0.06, 0.34), gunMat, 0, -0.14, 0.12);
  eye.userData.keep = true; gun.userData.keep = true; // blinks; muzzle point
  mergeRigidParts(g);
  addOutline(g, outlineMat.soldier, 0.015);
  return { g, rotors, eye, gun };
}

/** A drone that appears at (x, y, z) after its spawn flare. */
export function makeDrone(x, y, z, spawnT = 1) {
  const m = buildDrone();
  m.g.position.set(x, y, z); m.g.visible = spawnT <= 0; scene.add(m.g);
  const d = {
    ...m, pos: new V3(x, y, z), vel: new V3(), r: RADIUS, h: 0.4, spawnT,
    hp: G.daily && G.daily.mod === 'glass' ? 1 : 60 + Math.min(G.wave, 20) * 2, dead: false, falling: false, spin: 0,
    state: 'orbit', t: 0, fireCd: rand(1.5, 2.5), burst: 0, burstT: 0, diveCd: rand(7, 12), los: false, losT: 0,
    angle: Math.atan2(x - P.pos.x, z - P.pos.z), radius: rand(9, 12), alt: rand(5, 7), dir: Math.random() < 0.5 ? -1 : 1, target: new V3(),
    hurt(dmg, tags = []) { hurtDrone(d, dmg, tags); },
  };
  world.drones.push(d);
  return d;
}

function hurtDrone(d, dmg, tags) {
  if (d.dead) return;
  d.hp -= dmg;
  sparks.emit(d.pos, 8, 4, 2.6, 2.4, 2.8, 0.25, 6);
  if (d.hp > 0) { sfx.hit(); return; }
  d.dead = true; d.falling = true;
  d.vel.set(rand(-2, 2), 3, rand(-2, 2)); d.spin = rand(-12, 12);
  awardKill(d.pos, 175, false, tags, 0.6, 0, true);
  sfx.kill(); rumble(0.25, 0.15, 80);
  checkLastKill(null);
}

/** Small blast: a dive-bomb landing, or a wreck hitting the ground. hurtful = a dive-bomb (hurts you, kills soldiers). */
function boom(d, hurtful) {
  const c = d.pos.clone();
  shockRing(tmpA.set(c.x, c.y - 0.3, c.z), [3, 0.8, 0.2], hurtful ? 3.2 : 1.6, 0.3);
  sparks.emit(c, hurtful ? 60 : 30, hurtful ? 9 : 6, EMBER[0], EMBER[1], EMBER[2], 0.6, 2);
  embers(c, 16, 4, 0.5, 3);
  sfx.explosion();
  G.shake = Math.max(G.shake, hurtful ? 0.6 : 0.3);
  if (hurtful) {
    const pd = c.distanceTo(tmpB.set(P.pos.x, P.pos.y + 0.9, P.pos.z));
    if (G.mode === 'play' && pd < 3.2 && P.invT <= 0) {
      hurtPlayer(Math.round(12 + 18 * (1 - pd / 3.2)));
      P.vel.set((P.pos.x - c.x) / (pd || 1) * 9, 7, (P.pos.z - c.z) / (pd || 1) * 9); rumble(0.5, 0.5, 180);
    }
    for (const s of world.soldiers) {
      if (!isLive(s) || s.pos.distanceTo(c) > 2.6) continue;
      damageSoldier(s, s.boss ? 150 : 999, false, new V3(s.pos.x - c.x, 0, s.pos.z - c.z).normalize(), ['KAMIKAZE']);
    }
  }
  remove(d);
}
function remove(d) { scene.remove(d.g); d.gone = true; }
export function clearDrones() { for (const d of world.drones) scene.remove(d.g); world.drones = []; }

/** Nearest drone a ray passes through before tMax: { d, t } or null. */
export function droneAlong(origin, dir, tMax) {
  let best = null, bt = tMax;
  for (const d of world.drones) {
    if (d.dead || d.spawnT > 0) continue;
    tmpA.copy(d.pos).sub(origin);
    const t = tmpA.dot(dir);
    if (t < 0 || t > bt) continue;
    if (tmpA.addScaledVector(dir, -t).lengthSq() < 0.55 * 0.55) { bt = t; best = d; }
  }
  return best ? { d: best, t: bt } : null;
}
/** A live drone within r of p, or null. */
export function droneNear(p, r) { return world.drones.find(d => !d.dead && d.spawnT <= 0 && d.pos.distanceTo(p) < r) || null; }

function shootAt(d) {
  const m = d.gun.getWorldPosition(new V3());
  const aim = new V3(P.pos.x, P.pos.y + 1.1, P.pos.z).addScaledVector(P.vel, m.distanceTo(P.pos) / T.enemyBulletSpeed * 0.5);
  const spread = 0.35 + m.distanceTo(aim) * 0.02;
  aim.x += rand(-1, 1) * spread; aim.y += rand(-0.5, 0.5) * spread; aim.z += rand(-1, 1) * spread;
  spawnBullet(m, aim.sub(m).normalize().multiplyScalar(T.enemyBulletSpeed), 0.7);
  sfx.enemyShot(clamp(9 / (d.pos.distanceTo(P.pos) + 4), 0.08, 0.7), 1.4);
}

export function updateDrones(dt) {
  for (const d of world.drones) if (!d.gone) updateDrone(d, dt);
  world.drones = world.drones.filter(d => !d.gone);
}
function updateDrone(d, dt) {
  if (d.spawnT > 0) { d.spawnT -= dt; if (d.spawnT <= 0) { d.g.visible = true; embers(d.pos, 20, 3, 0.4, 2); } return; }
  for (const r of d.rotors) r.rotation.y += (d.falling ? 20 : 55) * dt;
  if (d.falling) {
    // a downed drone spins into the ground and bursts
    d.vel.y -= T.gravity * dt; d.g.rotation.y += d.spin * dt; d.g.rotation.z += d.spin * 0.3 * dt;
    if (Math.random() < 0.6) embers(d.pos, 1, 0.8, 0.4, 1);
    if (moveBody(d, dt)) boom(d, false);
    else if (d.pos.y < -60) remove(d);
    d.g.position.copy(d.pos);
    return;
  }
  d.t += dt;
  const dist = Math.hypot(P.pos.x - d.pos.x, P.pos.z - d.pos.z);
  d.losT -= dt;
  if (d.losT <= 0) {
    d.losT = 0.3;
    tmpA.copy(d.pos); tmpB.set(P.pos.x, P.pos.y + 1.1, P.pos.z).sub(tmpA);
    const len = tmpB.length(); tmpB.divideScalar(len || 1);
    d.los = rayWorld(tmpA, tmpB, len) >= len - 0.3;
  }
  let steer = true;
  if (d.state === 'orbit') {
    d.angle += d.dir * 0.45 * dt;
    d.target.set(P.pos.x + Math.sin(d.angle) * d.radius, Math.max(P.pos.y, surfaceY(d.pos.x, d.pos.z, d.pos.y)) + d.alt, P.pos.z + Math.cos(d.angle) * d.radius);
    if (G.mode === 'play') {
      d.fireCd -= dt;
      if (d.burst > 0) { d.burstT -= dt; if (d.burstT <= 0) { shootAt(d); d.burst--; d.burstT = 0.14; } }
      else if (d.fireCd <= 0 && d.los && dist < 40) { d.burst = 2; d.burstT = 0; d.fireCd = rand(1.6, 2.6) * Math.max(0.4, 1 - G.wave * 0.03); }
      d.diveCd -= dt;
      if (d.diveCd <= 0 && d.los && dist < 22) { d.state = 'warn'; d.t = 0; sfx.lockOn(); }
    }
  } else if (d.state === 'warn') {
    // hover and beep, eye flashing: then it commits
    d.target.copy(d.pos); d.vel.multiplyScalar(0.9);
    d.eye.visible = Math.sin(d.t * 30) > -0.2;
    if (d.t > 0.35 && d.t < 0.4) sfx.lockOn();
    if (d.t > 0.8) {
      d.state = 'dive'; d.t = 0; d.eye.visible = true;
      d.vel.set(P.pos.x - d.pos.x, P.pos.y + 0.8 - d.pos.y, P.pos.z - d.pos.z).normalize().multiplyScalar(DIVE_SPEED);
      sfx.whoosh(1.4);
    }
  } else if (d.state === 'dive') {
    steer = false;
    if (Math.random() < 0.8) embers(d.pos, 1, 0.5, 0.3, 0);
    if (d.pos.distanceTo(tmpA.set(P.pos.x, P.pos.y + 0.9, P.pos.z)) < 1.4) { boom(d, true); return; }
    const want = d.vel.clone();
    moveBody(d, dt);
    if (d.t > 1.6 || d.vel.lengthSq() < want.lengthSq() * 0.5 || Math.abs(d.vel.y - want.y) > 1) { boom(d, true); return; }
    d.vel.copy(want);
  }
  if (steer) {
    tmpA.copy(d.target).sub(d.pos);
    const want = tmpA.clampLength(0, 1).multiplyScalar(9);
    d.vel.x = damp(d.vel.x, want.x, 2.5, dt); d.vel.y = damp(d.vel.y, want.y, 2.5, dt); d.vel.z = damp(d.vel.z, want.z, 2.5, dt);
    const before = d.pos.clone();
    moveBody(d, dt);
    if (before.distanceTo(d.pos) < d.vel.length() * dt * 0.3) d.dir = -d.dir; // blocked: circle the other way
  }
  // face the player, bank with velocity
  d.g.position.copy(d.pos);
  d.g.rotation.order = 'YXZ';
  d.g.rotation.y = Math.atan2(P.pos.x - d.pos.x, P.pos.z - d.pos.z);
  d.g.rotation.x = clamp(d.vel.length() / 30, 0, 0.35) + (d.state === 'dive' ? 0.6 : 0);
  d.g.position.y += Math.sin(G.clock * 3 + d.angle) * 0.05;
}
