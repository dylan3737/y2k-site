// Small shared helpers: math, scratch vectors, DOM lookup and storage.
import * as THREE from 'three';

export const V3 = THREE.Vector3;
export const $ = id => document.getElementById(id);

export const rand = (a, b) => a + Math.random() * (b - a);
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
/** Frame-rate independent exponential approach from a toward b. */
export const damp = (a, b, rate, dt) => a + (b - a) * (1 - Math.exp(-rate * dt));
export const lerpAngle = (a, b, t) => {
  const d = ((b - a + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI;
  return a + d * t;
};
export const pad = (n, len) => String(n).padStart(len, '0');

/** Deterministic PRNG so generated maps come out the same every time. */
export function mulberry32(seed) {
  return () => {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

/** Scales screen shake and head bob for people who ask for reduced motion. */
export const MOTION = matchMedia('(prefers-reduced-motion: reduce)').matches ? 0.3 : 1;

// Scratch vectors. Only use them within a single function call: callees may reuse them.
export const tmpA = new V3(), tmpB = new V3(), tmpC = new V3();

// Per-browser settings and scores. Also reads keys saved while the game was briefly called Hellwick.
export const store = {
  get(key, fallback = null) {
    try {
      const v = localStorage.getItem('anomaly-' + key) ?? localStorage.getItem('hellwick-' + key);
      return v === null ? fallback : v;
    } catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem('anomaly-' + key, value); } catch { /* storage blocked: settings just won't persist */ }
  },
};
