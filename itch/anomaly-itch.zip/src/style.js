// Unlockable styles for the hero (coat and accent glow, blade, muzzle flash), earned from lifetime stats,
// plus the Style screen that shows them. Progress and the equipped look are saved in this browser.
import * as THREE from 'three';
import { $, store } from './util.js';
import { HM } from './materials.js';
import { hero } from './hero.js';
import { sfx } from './audio.js';
import { callout } from './ui.js';

// ---- what can be unlocked, and how
const need = (stat, n, text) => ({ stat, n, text });
export const STYLES = {
  coat: { label: 'Coat', items: [
    { id: 'ember', name: 'Ember', coat: 0x3a2c26, accent: 0xff5a14 },
    { id: 'crimson', name: 'Crimson', coat: 0x4a0e0c, accent: 0xff2a1a, req: need('kills', 150, 'Kill 150 enemies') },
    { id: 'midnight', name: 'Midnight', coat: 0x141a2e, accent: 0x39c6ff, req: need('bestWave', 10, 'Reach wave 10') },
    { id: 'bone', name: 'Bone', coat: 0xa89c86, accent: 0xffd9a0, req: need('bossKills', 1, 'Defeat a Juggernaut') },
    { id: 'venom', name: 'Venom', coat: 0x16261a, accent: 0x7aff3a, req: need('parries', 10, 'Land 10 perfect parries') },
    { id: 'gilded', name: 'Gilded', coat: 0x2a2012, accent: 0xffc440, req: need('bestScore', 250000, 'Score 250,000 in one run') },
  ] },
  blade: { label: 'Blade', items: [
    { id: 'steel', name: 'Steel', edge: [3.6, 1.5, 0.45] },
    { id: 'plasma', name: 'Plasma', edge: [0.6, 2.8, 4], req: need('katanaKills', 40, 'Get 40 katana kills') },
    { id: 'blood', name: 'Blood', edge: [4, 0.3, 0.25], req: need('maxChain', 9, 'Reach a ×9 chain') },
    { id: 'void', name: 'Void', edge: [2.2, 0.5, 4], req: need('bestWave', 20, 'Reach wave 20') },
    { id: 'ghost', name: 'Ghost', edge: [3.4, 3.5, 3.8], req: need('droneKills', 20, 'Shoot down 20 drones') },
  ] },
  flash: { label: 'Muzzle flash', items: [
    { id: 'ember', name: 'Ember', tracer: [3, 1.7, 0.55], flash: [4, 2.2, 0.7] },
    { id: 'ice', name: 'Ice', tracer: [0.8, 2.2, 3.2], flash: [1.2, 2.8, 4], req: need('headshots', 75, 'Land 75 headshots') },
    { id: 'venom', name: 'Venom', tracer: [1.4, 3.2, 0.6], flash: [1.8, 4, 0.8], req: need('barrelKills', 30, 'Kill 30 enemies with barrels') },
    { id: 'violet', name: 'Violet', tracer: [2.4, 0.9, 3.4], flash: [3, 1.2, 4], req: need('stages', 8, 'Fight on all 8 stages') },
  ] },
};

// ---- lifetime progress
const STATS = ['kills', 'headshots', 'katanaKills', 'barrelKills', 'droneKills', 'bossKills', 'parries', 'maxChain', 'bestWave', 'bestScore'];
function load() {
  let p = {};
  try { p = JSON.parse(store.get('progress', '{}')) || {}; } catch { /* start fresh */ }
  for (const k of STATS) p[k] = Number(p[k]) || 0;
  p.stagesSeen = Array.isArray(p.stagesSeen) ? p.stagesSeen : [];
  p.equipped = { coat: 'ember', blade: 'steel', flash: 'ember', ...(p.equipped || {}) };
  return p;
}
export const progress = load();
const statValue = stat => (stat === 'stages' ? progress.stagesSeen.length : progress[stat]);
export const isUnlocked = item => !item.req || statValue(item.req.stat) >= item.req.n;
function save() { store.set('progress', JSON.stringify(progress)); }
let saveTimer = 0;
function saveSoon() { clearTimeout(saveTimer); saveTimer = setTimeout(save, 800); }

/** Record something that happened; announces anything it unlocks. */
export function track(event, value = 1, extra) {
  const before = allUnlocked();
  switch (event) {
    case 'kill':
      progress.kills++;
      if (extra && extra.head) progress.headshots++;
      if (extra && extra.tags.includes('KATANA')) progress.katanaKills++;
      if (extra && extra.tags.includes('KABOOM')) progress.barrelKills++;
      if (extra && extra.drone) progress.droneKills++;
      break;
    case 'chain': progress.maxChain = Math.max(progress.maxChain, value); break;
    case 'boss': progress.bossKills++; break;
    case 'parry': progress.parries += value; break;
    case 'wave': progress.bestWave = Math.max(progress.bestWave, value); break;
    case 'score': if (value <= progress.bestScore) return; progress.bestScore = value; break;
    case 'stage': if (progress.stagesSeen.includes(value)) return; progress.stagesSeen.push(value); break;
  }
  const now = allUnlocked();
  const fresh = [...now].filter(k => !before.has(k));
  if (fresh.length) {
    save();
    const [slot, id] = fresh[0].split(':'), item = STYLES[slot].items.find(i => i.id === id);
    callout(`UNLOCKED: ${item.name.toUpperCase()} ${STYLES[slot].label.toUpperCase()}`); sfx.oneUp();
  } else saveSoon();
}
function allUnlocked() {
  const s = new Set();
  for (const [slot, def] of Object.entries(STYLES)) for (const it of def.items) if (it.req && isUnlocked(it)) s.add(slot + ':' + it.id);
  return s;
}

// ---- putting the look on the hero
const col = new THREE.Color();
export const look = { tracer: [3, 1.7, 0.55] };
export function applyStyle() {
  const pick = slot => STYLES[slot].items.find(i => i.id === progress.equipped[slot] && isUnlocked(i)) || STYLES[slot].items[0];
  const coat = pick('coat'), blade = pick('blade'), flash = pick('flash');
  HM.coat.color.setHex(coat.coat); HM.coatSolid.color.setHex(coat.coat);
  HM.trim.emissive.setHex(coat.accent);
  col.setHex(coat.accent); HM.eye.color.setRGB(col.r * 4, col.g * 4, col.b * 4); HM.rune.color.setRGB(col.r * 3, col.g * 3, col.b * 3);
  HM.bladeEdge.color.setRGB(...blade.edge);
  look.tracer = flash.tracer; look.slash = blade.edge;
  for (const a of hero.arms) a.flash.material.color.setRGB(...flash.flash);
}
export function equip(slot, id) {
  const item = STYLES[slot].items.find(i => i.id === id);
  if (!item || !isUnlocked(item)) { sfx.empty(); return; }
  progress.equipped[slot] = id; save(); applyStyle(); sfx.blip();
}

// ---- the Style screen (mouse, keyboard or controller: up/down picks a slot, left/right an item, A / Enter equips)
let rows = [], focus = 0, cursor = {}, returnTo = null;
const hex = c => '#' + new THREE.Color(...(Array.isArray(c) ? c.map(v => Math.min(1, v / 4)) : [0, 0, 0])).getHexString();
function swatch(slot, it) {
  if (slot === 'coat') return `linear-gradient(135deg, #${it.coat.toString(16).padStart(6, '0')} 60%, #${it.accent.toString(16).padStart(6, '0')} 60%)`;
  return hex(slot === 'blade' ? it.edge : it.flash);
}
function build() {
  const body = $('styleBody'); body.textContent = '';
  rows = [];
  for (const [slot, def] of Object.entries(STYLES)) {
    const sec = document.createElement('section'); sec.className = 'setgroup';
    const h = document.createElement('h3'); h.textContent = def.label; sec.append(h);
    const row = document.createElement('div'); row.className = 'stylerow';
    const cards = def.items.map(it => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'stylecard';
      const sw = document.createElement('i'); sw.style.background = swatch(slot, it);
      const name = document.createElement('b'); name.textContent = it.name;
      const note = document.createElement('small');
      b.append(sw, name, note);
      b.addEventListener('click', () => equip(slot, it.id));
      row.append(b);
      return { it, b, note };
    });
    sec.append(row); body.append(sec);
    rows.push({ slot, row, cards });
  }
  render();
}
function render() {
  rows.forEach((r, i) => {
    r.row.classList.toggle('focus', i === focus);
    r.cards.forEach((c, k) => {
      const open = isUnlocked(c.it);
      c.b.classList.toggle('locked', !open);
      c.b.setAttribute('aria-pressed', String(progress.equipped[r.slot] === c.it.id));
      c.b.classList.toggle('cursor', i === focus && (cursor[r.slot] ?? 0) === k);
      c.note.textContent = open ? (progress.equipped[r.slot] === c.it.id ? 'Equipped' : 'Unlocked')
        : `${c.it.req.text} · ${Math.min(statValue(c.it.req.stat), c.it.req.n).toLocaleString()}/${c.it.req.n.toLocaleString()}`;
    });
  });
}
export const isStyleOpen = () => !$('styleScreen').hidden;
export function openStyle(from) { returnTo = from; if (from) from.hidden = true; $('styleScreen').hidden = false; build(); }
export function closeStyle() { $('styleScreen').hidden = true; if (returnTo) returnTo.hidden = false; returnTo = null; }
export function styleMove(d) { focus = (focus + d + rows.length) % rows.length; sfx.tick(); render(); }
export function styleAdjust(d) {
  const r = rows[focus], n = r.cards.length;
  cursor[r.slot] = ((cursor[r.slot] ?? r.cards.findIndex(c => progress.equipped[r.slot] === c.it.id)) + d + n) % n;
  sfx.tick(); render();
}
export function styleActivate() { const r = rows[focus]; equip(r.slot, r.cards[cursor[r.slot] ?? 0].it.id); render(); }
export function initStyle() {
  applyStyle();
  $('styleBack').addEventListener('click', () => { closeStyle(); sfx.blip(); });
  $('styleScreen').addEventListener('click', e => { if (e.target.closest('.stylecard')) render(); });
}
