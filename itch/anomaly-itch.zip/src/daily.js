// The daily challenge: the same stage and one twist for everyone, picked from today's date (UTC).
import { STAGES } from './config.js';
import { G } from './state.js';

export const MODS = {
  katana: { name: 'Katana only', desc: 'Your guns are locked. Blade, stomps, barrels and Hellfire only.' },
  onehit: { name: 'One hit', desc: 'Any hit costs you a life.' },
  headhunter: { name: 'Headhunter', desc: 'Only headshots hurt them. The katana still cuts.' },
  glass: { name: 'Glass', desc: 'Every enemy dies to one hit, but their rounds hit you twice as hard.' },
  rush: { name: 'Rush', desc: 'Twice as many enemies, and more of them at once.' },
  slowmo: { name: 'Slow-mo', desc: 'The whole world runs at half speed. Your guns don\'t.' },
};
export const STAGE_NAMES = { lobby: 'Warehouse', rooftop: 'Rooftop', city: 'Downtown', docks: 'Docks', subway: 'Subway', site: 'Construction', market: 'Night market', club: 'Nightclub' };

/** Today's date in UTC, e.g. "2026-09-30": the same challenge everywhere in the world. */
export const todayKey = () => new Date().toISOString().slice(0, 10);
function hash(s) {
  let h = 2166136261;
  for (const c of s) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  // finish with a strong mix so neighbouring dates don't share bits
  h ^= h >>> 16; h = Math.imul(h, 0x85ebca6b); h ^= h >>> 13; h = Math.imul(h, 0xc2b2ae35); h ^= h >>> 16;
  return h >>> 0;
}
function pick(key) {
  const h = hash('anomaly-daily-' + key), mods = Object.keys(MODS);
  return { stage: h % STAGES.length, mod: (h >>> 8) % mods.length };
}
/** Today's challenge: { key, stage (index into STAGES), mod }. Never the same twist two days running. */
export function today() {
  const key = todayKey(), mods = Object.keys(MODS), t = pick(key);
  const y = pick(new Date(Date.parse(key + 'T00:00:00Z') - 864e5).toISOString().slice(0, 10));
  if (t.mod === y.mod) t.mod = (t.mod + 1) % mods.length;
  return { key, stage: t.stage, mod: mods[t.mod] };
}
/** Is this run a daily with twist m? */
export const dailyMod = m => !!G.daily && G.daily.mod === m;
