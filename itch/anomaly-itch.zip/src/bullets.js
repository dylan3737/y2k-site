// Enemy bullets: flight, near-miss whistles, hits on the player, and katana deflections back at the soldiers.
import * as THREE from 'three';
import { scene, camera } from './engine.js';
import { V3, clamp, tmpA, tmpB } from './util.js';
import { rayWorld } from './physics.js';
import { sparks, spawnRipple, bleed } from './fx.js';
import { popup } from './ui.js';
import { barrelAt, explodeBarrel } from './barrels.js';
import { droneNear } from './drones.js';
import { sfx } from './audio.js';
import { T, difficulty } from './config.js';
import { G, P, world } from './state.js';
import { damageSoldier, inSwingArc } from './combat.js';
import { hurtPlayer } from './player.js';
import { addScore } from './game.js';
import { isLive, shieldBlocks } from './soldiers.js';

const coreGeo = new THREE.CylinderGeometry(0.035, 0.035, 0.32, 6); coreGeo.rotateX(Math.PI / 2);
const trailGeo = new THREE.CylinderGeometry(0.02, 0.003, 3.2, 6, 1, true); trailGeo.rotateX(Math.PI / 2); trailGeo.translate(0, 0, -1.7);
const coreMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(5, 3.6, 1.8) });
const trailMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(1.6, 1.3, 0.7), transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending, depthWrite: false });
const deflectCoreMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(5, 2, 0.5) });
const deflectTrailMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(3, 0.9, 0.2), transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false });

export function spawnBullet(p, v, dmg = 1) {
  const mesh = new THREE.Group(); mesh.add(new THREE.Mesh(coreGeo, coreMat), new THREE.Mesh(trailGeo, trailMat));
  if (dmg > 1.5) mesh.scale.set(1.6, 1.6, 1.4); // sniper rounds read heavier
  mesh.position.copy(p); mesh.lookAt(tmpA.copy(p).add(v)); scene.add(mesh);
  world.bullets.push({ pos: p.clone(), vel: v.clone(), life: 4, mesh, rippleT: 0, whoosh: false, dmg });
}
/**
 * Bat a bullet back with the katana: it turns ember, speeds up and flies at the soldier nearest
 * the crosshair (or straight down it). quiet skips the per-bullet popup when a swing hits several.
 */
export function deflectBullet(b, quiet = false) {
  if (b.friendly) return;
  b.friendly = true; b.life = 3; b.whoosh = true;
  const aim = camera.getWorldDirection(new V3());
  let target = null, bestDot = Math.cos(0.45);
  for (const s of world.soldiers) {
    if (!isLive(s)) continue;
    tmpA.set(s.pos.x, s.pos.y + 1.2 * s.scale, s.pos.z).sub(b.pos);
    const dot = tmpA.dot(aim) / (tmpA.length() || 1);
    if (dot > bestDot) { bestDot = dot; target = s; }
  }
  const dir = target ? new V3(target.pos.x, target.pos.y + 1.2 * target.scale, target.pos.z).sub(b.pos).normalize() : aim;
  b.vel.copy(dir).multiplyScalar(T.deflectSpeed);
  b.target = target;
  b.mesh.children[0].material = deflectCoreMat; b.mesh.children[1].material = deflectTrailMat;
  b.mesh.lookAt(tmpA.copy(b.pos).add(b.vel));
  sparks.emit(b.pos, 16, 5, 3.4, 2.4, 0.9, 0.2, 0);
  sfx.clang(); addScore(50); P.focus = Math.min(100, P.focus + 4);
  if (!quiet) popup(tmpA.copy(b.pos), 'DEFLECT', 'cyan');
}
/** First live soldier a deflected bullet passes through on this step, or null. */
function soldierHitAlong(px, py, pz, b, n) {
  for (let k = 1; k <= n; k++) {
    const t = k / n, x = px + (b.pos.x - px) * t, y = py + (b.pos.y - py) * t, z = pz + (b.pos.z - pz) * t;
    for (const s of world.soldiers) {
      if (!isLive(s)) continue;
      const r = 0.36 * s.scale;
      if (Math.abs(x - s.pos.x) < r && Math.abs(z - s.pos.z) < r && y > s.pos.y && y < s.pos.y + 1.95 * s.scale) {
        return { s, head: y > s.pos.y + 1.58 * s.scale };
      }
    }
  }
  return null;
}

export function removeBullet(i) { scene.remove(world.bullets[i].mesh); world.bullets.splice(i, 1); }
export function clearBullets() { for (const b of world.bullets) scene.remove(b.mesh); world.bullets = []; }

/** Move bullets, hit the player or the level, and whistle past near misses. */
export function updateBullets(dtWorld, dtReal) {
  const list = world.bullets;
  for (let i = list.length - 1; i >= 0; i--) {
    const b = list[i];
    if (b.friendly && b.target && isLive(b.target)) {
      // deflected shots curve toward their target so a dodge doesn't waste them
      const t = b.target;
      tmpA.set(t.pos.x, t.pos.y + (b.perfect ? 1.72 : 1.2) * t.scale, t.pos.z).sub(b.pos).normalize().multiplyScalar(T.deflectSpeed);
      b.vel.lerp(tmpA, 1 - Math.exp(-10 * dtWorld));
      b.mesh.lookAt(tmpA.copy(b.pos).add(b.vel));
    }
    const px = b.pos.x, py = b.pos.y, pz = b.pos.z;
    b.pos.addScaledVector(b.vel, dtWorld); b.life -= dtWorld;
    const seg = Math.hypot(b.pos.x - px, b.pos.y - py, b.pos.z - pz);
    let dead = b.life <= 0;
    // a bullet reaching you mid-swing gets batted back
    if (!b.friendly && P.slashT > 0 && G.mode === 'play' && inSwingArc(b.pos, 2.6)) deflectBullet(b);
    if (b.friendly && !dead && seg > 0) {
      const n = Math.max(1, Math.ceil(seg / 0.2));
      const hit = soldierHitAlong(px, py, pz, b, n);
      const dr = droneNear(b.pos, 0.8);
      if (dr) { dr.hurt(T.deflectDamage, b.perfect ? ['DEFLECT', 'PERFECT PARRY'] : ['DEFLECT']); removeBullet(i); continue; }
      if (hit && b.perfect) hit.head = true; // perfect parries always find the head
      if (hit && shieldBlocks(hit.s, b.vel, hit.head)) {
        sparks.emit(b.pos, 14, 5, 3, 1.6, 0.5, 0.2, 10); sfx.ricochet(); dead = true;
      } else if (hit) {
        bleed(b.pos, hit.head ? 30 : 16, 4, 1);
        damageSoldier(hit.s, hit.head ? T.headDamage : T.deflectDamage, hit.head, tmpB.copy(b.vel).normalize(), b.perfect ? ['DEFLECT', 'PERFECT PARRY'] : ['DEFLECT']);
        dead = true;
      } else {
        tmpA.set(px, py, pz); tmpB.set(b.pos.x - px, b.pos.y - py, b.pos.z - pz).divideScalar(seg);
        const tw = rayWorld(tmpA, tmpB, seg);
        if (tw < seg) { b.pos.copy(tmpA).addScaledVector(tmpB, tw); sparks.emit(b.pos, 10, 4, 3, 1.4, 0.4, 0.3, 12); explodeBarrel(barrelAt(b.pos)); dead = true; }
      }
    } else if (!dead && seg > 0) {
      // sample along the step so fast bullets can't tunnel through the player
      const n = Math.max(1, Math.ceil(seg / 0.12));
      let minD = 99, hit = false;
      for (let k = 1; k <= n; k++) {
        const t = k / n, x = px + (b.pos.x - px) * t, y = py + (b.pos.y - py) * t, z = pz + (b.pos.z - pz) * t;
        const cy = clamp(y, P.pos.y + 0.25, P.pos.y + 1.65);
        const d = Math.hypot(x - P.pos.x, y - cy, z - P.pos.z);
        if (d < minD) minD = d;
        if (d < 0.34) { hit = true; break; }
      }
      if (hit && G.mode === 'play' && P.invT <= 0) {
        bleed(b.pos, 12, 3, 1);
        hurtPlayer(difficulty(G.wave).damage * (b.dmg || 1));
        if (world.bullets !== list) return; // losing a life cleared every bullet
        dead = true;
      } else {
        if (minD < 1.4 && !b.whoosh && G.mode === 'play') {
          b.whoosh = true; sfx.whoosh(0.5 + 0.5 * G.timeScale);
          if (G.focusActive) { P.focus = Math.min(100, P.focus + 3); addScore(10); }
        }
        tmpA.set(px, py, pz); tmpB.set(b.pos.x - px, b.pos.y - py, b.pos.z - pz).divideScalar(seg);
        const tw = rayWorld(tmpA, tmpB, seg);
        if (tw < seg) { b.pos.copy(tmpA).addScaledVector(tmpB, tw); sparks.emit(b.pos, 10, 4, 3, 2, 0.8, 0.3, 12); explodeBarrel(barrelAt(b.pos)); dead = true; } // strays can set barrels off
      }
    }
    if (dead) { removeBullet(i); continue; }
    b.mesh.position.copy(b.pos);
    b.rippleT -= dtReal;
    if (G.timeScale < 0.7 && b.rippleT <= 0) { spawnRipple(b.pos, b.vel); b.rippleT = 0.06; }
  }
}
