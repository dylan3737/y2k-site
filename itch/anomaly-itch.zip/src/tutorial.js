// A guided warm-up in the warehouse: one prompt at a time, each cleared the moment you do it,
// then the real waves start. Prompts name your own key or button bindings.
import { $ } from './util.js';
import { G, P, input } from './state.js';
import { T } from './config.js';
import { sfx } from './audio.js';
import { banner } from './ui.js';
import { actionKey, actionPad, onBindingsChange } from './bindings.js';
import { touchMode } from './touch.js';

const pad = () => input.pad.on;
const TOUCH = { jump: 'Jump', dive: 'Dive', fire: 'Fire', slash: 'Blade', focus: 'Slow', focusToggle: 'Slow' };
const k = id => (touchMode() ? `the ${TOUCH[id] || id} button` : pad() ? actionPad(id) : actionKey(id));
const move = () => (touchMode() ? 'your left thumb (anywhere on the left)' : pad() ? 'the left stick' : `${actionKey('forward')} ${actionKey('left')} ${actionKey('back')} ${actionKey('right')}`);

const STEPS = [
  { text: () => `Move with ${move()}`, done: s => s.moved > 6 },
  { text: () => `Jump with ${k('jump')}`, done: () => !P.grounded && P.vel.y > 3 },
  { text: () => `Press ${k('jump')} again in mid-air to double jump`, done: () => !P.grounded && P.airJumps === 0 },
  { text: () => 'Run straight at a wall or a crate to climb it', done: () => !!P.climb },
  { text: () => 'Run alongside a wall, then jump toward it to wall-run', done: () => !!P.wall },
  { text: () => `Fire with ${k('fire')}`, done: s => P.ammo < s.ammo || P.reloadT > 0 },
  { text: () => `Slash the katana with ${k('slash')}`, done: () => P.slashT > 0 },
  { text: () => `Hold ${k('slash')}, then let go to dash-cut`, done: () => P.dashT > 0 },
  { text: () => `Shootdodge with ${k('dive')}`, done: () => P.diveT > 0 },
  { text: () => (touchMode() ? `Tap ${k('focus')} for bullet time` : `Hold ${k('focus')} for bullet time`), done: () => G.focusActive },
];

let state = null;
const box = () => $('tutor');
function show() {
  const b = box(); if (!state) { b.hidden = true; return; }
  b.hidden = false;
  b.querySelector('small').textContent = `Training ${Math.min(state.step + 1, STEPS.length)} / ${STEPS.length}`;
  b.querySelector('b').textContent = STEPS[state.step].text();
  b.classList.toggle('done', state.cleared > 0);
}
onBindingsChange(() => { if (state) show(); });

/** Begin training (the run is already set up; waves are held until it ends). */
export function startTutorial() {
  state = { step: 0, cleared: 0, moved: 0, last: P.pos.clone(), ammo: P.ammo };
  G.waveGap = 1e9;
  show();
}
export function endTutorial(finished) {
  state = null; box().hidden = true;
  if (finished) { banner('training complete', 'here they come', 2400); sfx.oneUp(); G.waveGap = 2.5; }
}
/** Once a frame during play. */
export function updateTutorial(dt) {
  if (!state) return;
  if (G.mode !== 'play') return;
  state.moved += Math.hypot(P.pos.x - state.last.x, P.pos.z - state.last.z); state.last.copy(P.pos);
  if (state.cleared > 0) {
    // a beat on the tick before the next prompt
    state.cleared -= dt;
    if (state.cleared <= 0) {
      state.step++;
      if (state.step >= STEPS.length) { endTutorial(true); return; }
      state.ammo = P.ammo === 0 ? T.magSize : P.ammo; state.moved = 0;
      show();
    }
    return;
  }
  if (STEPS[state.step].done(state)) { state.cleared = 0.7; sfx.blip(); show(); }
}
