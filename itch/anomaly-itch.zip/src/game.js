// Game flow: waves, lives, score, and moving between the menu, play, pause and game over.
import { renderer, camera, grade, setFov } from './engine.js';
import { $, rand, clamp, damp, pad, tmpA } from './util.js';
import { level } from './physics.js';
import { loadLevel, stageFor } from './levels.js';
import { sparks, EMBER, bleed, clearGore, spawnFlare } from './fx.js';
import { sfx, initAudio, suspendAudio, resumeAudio } from './audio.js';
import { T, STAGES, difficulty } from './config.js';
import { G, P, input, world, firing, resetPlayer } from './state.js';
import { makeDrone, clearDrones, updateDrones } from './drones.js';
import { surfaceY } from './events.js';
import { makeSoldier, clearSoldiers, updateSoldier, separateSoldiers, removeSoldierModel } from './soldiers.js';
import { updateBullets, clearBullets } from './bullets.js';
import { hero, animateHero, poseHeroForMenu } from './hero.js';
import { updatePlayer, endSurf, playerDt } from './player.js';
import { fire, updateKatanaCharge } from './combat.js';
import { updateEvents } from './events.js';
import { track } from './style.js';
import { updateLook } from './look.js';
import { updateBlade, resetBlade } from './blade.js';
import { startTutorial, updateTutorial, endTutorial } from './tutorial.js';
import { updatePickups, clearPickups } from './pickups.js';
import { showScreen, banner, callout, hint, popup, updateHUD, clearHudEffects } from './ui.js';
import { qualifies, holdScore, commitPending, hasPending, renderScores } from './scores.js';
import { beatsWorldBest, submitWorld, renderWorld, worldReady, beatsDailyBest, submitDaily, renderDaily } from './leaderboard.js';
import { today, MODS, STAGE_NAMES, dailyMod } from './daily.js';
import { store } from './util.js';

// ---- score and lives
export function addScore(n) {
  G.score += n;
  track('score', G.score);
  if (G.score >= G.nextLifeAt) {
    G.nextLifeAt += T.extraLifeEvery;
    G.lives = Math.min(6, G.lives + 1);
    callout('EXTRA LIFE!'); sfx.oneUp();
  }
}

export function loseLife() {
  if (G.mode !== 'play') return;
  G.lives--;
  bleed(tmpA.set(P.pos.x, P.pos.y + 1, P.pos.z), 120, 7, 2);
  sparks.emit(tmpA, 120, 8, EMBER[0], EMBER[1], EMBER[2], 1.2, -1);
  sfx.death(); endSurf(false);
  G.flash = 1; G.hitStop = 0.4; G.combo = 0;
  if (G.lives <= 0) { gameOver(); return; }
  banner('life lost', `${G.lives} ${G.lives === 1 ? 'life' : 'lives'} left`, 2000);
  clearBullets();
  const keep = { yaw: P.yaw, pitch: P.pitch };
  resetPlayer(level.info.start);
  Object.assign(P, keep, { invT: 3 });
  G.hellfire = Math.max(G.hellfire, T.startHellfire);
}

// ---- waves
function nextWave() {
  G.wave++; G.waveStartT = G.clock; G.waveHurt = false;
  let intro = '';
  track('wave', G.wave - 1); // the wave just survived
  if (loadLevel(stageFor(G.wave))) {
    // new stage: clear the old one's leftovers and start at its spawn point
    clearBullets(); clearPickups(); clearGore(); endSurf(false);
    world.soldiers = world.soldiers.filter(s => { if (s.dead) removeSoldierModel(s); return !s.dead; });
    P.pos.copy(level.info.start); P.safe.copy(level.info.start); P.vel.set(0, 0, 0); P.wall = null; P.climb = null;
    G.flash = 1; intro = level.info.label; sfx.hellfire();
    resetBlade(); // it doesn't follow you to a new stage: it's back in your hand
    G.eventT = rand(22, 32);
  }
  track('stage', level.info.name);
  const boss = G.wave % 5 === 0;
  G.bossPending = boss;
  G.toSpawn = boss ? 2 + G.wave : 2 + G.wave * 2;
  G.maxAlive = difficulty(G.wave).maxAlive;
  if (dailyMod('rush')) { G.toSpawn *= 2; G.maxAlive = Math.min(14, G.maxAlive + 4); }
  G.spawnTimer = boss ? 2.5 : 1.2;
  const waveLabel = 'wave ' + pad(G.wave, 2);
  const unlock = NEW_THREAT[G.wave];
  G.introKind = unlock ? unlock.kind : null;
  if (unlock) setTimeout(() => { if (G.mode === 'play') { callout('NEW THREAT: ' + unlock.name); hint(unlock.hint, 7000); } }, 3000);
  if (boss) { banner('warning', 'juggernaut incoming', 2800); sfx.alarm(); }
  else if (intro) banner(intro.toLowerCase(), `${waveLabel}  ·  ${G.toSpawn} soldiers inbound`, 2800);
  else banner(waveLabel, G.wave === 1 ? 'get ready' : `${G.toSpawn} soldiers inbound`);

  if (level.info.name === 'city' && !G.hints.city) {
    G.hints.city = true;
    setTimeout(() => hint('Run straight at a building to run up it · jump off a roof onto soldiers to slam them', 7000), 3000);
  } else if (G.wave === 3 && !G.hints.combo) {
    G.hints.combo = true;
    setTimeout(() => hint('Katana: tap three times for a finisher · hold, then release to dash-cut through a line · slash just before a bullet hits for a perfect parry', 8000), 9000);
  } else if (G.wave === 2 && !G.hints.hellfire) {
    G.hints.hellfire = true;
    setTimeout(() => hint('Press Q for Hellfire: it burns every bullet out of the air and blasts nearby soldiers'), 2500);
  }
}

/** Waves where a soldier type first shows up, and how to deal with it. */
const NEW_THREAT = {
  3: { kind: 'rusher', name: 'RUSHERS', hint: 'Rushers charge in with shotguns (amber visors). Keep moving, or meet them with the katana' },
  4: { kind: 'sniper', name: 'SNIPERS', hint: 'Snipers paint you with a laser before they fire (blue visors). Break line of sight, or slash to bat the round back' },
  7: { kind: 'drone', name: 'DRONES', hint: 'Drones circle overhead and fire bursts. When one beeps and flashes it is about to dive at you, so move. Shoot them down or land on them' },
  6: { kind: 'shield', name: 'RIOT SHIELDS', hint: 'Riot shields stop body shots from the front. Go for the head, flank them, stomp them or cut them' },
};
/** Which type to send: the newly unlocked one first, then a mix that leans harder as the waves climb. */
function pickKind() {
  if (G.introKind) { const k = G.introKind; G.introKind = null; return k; }
  const w = G.wave, r = Math.random();
  const rusher = w >= 3 ? Math.min(0.3, 0.12 + 0.03 * (w - 3)) : 0;
  const sniper = w >= 4 ? Math.min(0.2, 0.08 + 0.02 * (w - 4)) : 0;
  const shield = w >= 6 ? Math.min(0.22, 0.1 + 0.03 * (w - 6)) : 0;
  if (w >= 7 && Math.random() < Math.min(0.2, 0.1 + 0.02 * (w - 7))) return 'drone';
  if (r < rusher) return 'rusher';
  if (r < rusher + sniper) return 'sniper';
  if (r < rusher + sniper + shield) return 'shield';
  return 'grunt';
}

/** Drop a soldier in at a spawn point 16–55 m away (so fights stay close on big maps). */
function spawnSoldier(boss = false) {
  const d = s => Math.hypot(s[0] - P.pos.x, s[1] - P.pos.z);
  const all = level.spawns;
  const band = all.filter(s => d(s) > 16 && d(s) < 55), far = all.filter(s => d(s) > 16);
  const pool = band.length ? band : far.length ? far : all;
  const [sx, sz, sy] = pool[(Math.random() * pool.length) | 0];
  const j = level.info.spawnJitter, x = sx + rand(-j, j), z = sz + rand(-j, j);
  const kind = boss ? 'grunt' : pickKind();
  if (kind === 'drone') makeDrone(x, Math.max(sy, surfaceY(x, z, sy + 1)) + 6, z, 1);
  else makeSoldier(x, z, { y: sy, spawnT: boss ? 2 : 1, boss, kind });
  spawnFlare(x, sy, z, boss ? 2 : 1);
  sfx.spawn(boss ? 1 : clamp(14 / (Math.hypot(x - P.pos.x, z - P.pos.z) + 4), 0.15, 1));
}

function updateWaves(dtWorld) {
  const alive = world.soldiers.filter(s => !s.dead && !s.idle).length + world.drones.filter(d => !d.dead).length;
  if (G.waveGap > 0) { G.waveGap -= dtWorld; if (G.waveGap <= 0) nextWave(); return; }
  G.spawnTimer -= dtWorld;
  if (G.bossPending) {
    if (G.spawnTimer <= 0) { G.bossPending = false; spawnSoldier(true); G.spawnTimer = 3; }
    return;
  }
  if (G.toSpawn > 0 && alive < G.maxAlive && G.spawnTimer <= 0) { spawnSoldier(); G.toSpawn--; G.spawnTimer = rand(0.5, 1.3); }
  if (G.toSpawn === 0 && alive === 0 && G.wave > 0) {
    const timeBonus = Math.max(0, Math.round(60 + G.wave * 6 - (G.clock - G.waveStartT))) * 25;
    const noDamage = G.waveHurt ? 0 : 1000 * G.wave;
    addScore(timeBonus + noDamage);
    P.hp = Math.min(100, P.hp + 35); P.focus = Math.min(100, P.focus + 30);
    banner('wave clear', `time bonus ${timeBonus}` + (noDamage ? `  ·  no damage ${noDamage}` : ''), 2600);
    sfx.oneUp();
    G.waveGap = 3.5;
  }
}

// ---- per-frame
function updateFocus(dtR) {
  const want = (input.focus || input.focusToggle || input.pad.focus) && G.mode === 'play';
  if (want && !G.focusActive && P.focus >= T.focusMin) { G.focusActive = true; sfx.focusIn(); G.beatT = 0; }
  if (G.focusActive && (!want || P.focus <= 0)) { G.focusActive = false; input.focusToggle = false; sfx.focusOut(); }
  if (G.focusActive) {
    P.focus = Math.max(0, P.focus - T.focusDrain * dtR);
    G.beatT -= dtR; if (G.beatT <= 0) { sfx.heartbeat(); G.beatT = 0.85; }
  } else P.focus = Math.min(100, P.focus + T.focusRegen * dtR);
  let target = G.mode === 'dead' ? T.slowDead : G.focusActive ? T.slowFocus : P.diveT > 0 ? T.slowDive : 1;
  if (dailyMod('slowmo')) target = Math.min(target, 0.5);
  // perfect parries and the last kill of a wave punch into slow motion, fast
  G.parryT = Math.max(0, G.parryT - dtR); G.finalT = Math.max(0, G.finalT - dtR);
  const punch = G.parryT > 0 ? 0.18 : G.finalT > 0 ? 0.22 : 0;
  if (punch) target = Math.min(target, punch);
  G.timeScale = damp(G.timeScale, target, punch ? 20 : 7, dtR);
}

function updateWeapons(dtR, dt) {
  P.invT = Math.max(0, P.invT - dtR);
  if (P.powerT > 0) {
    P.powerT -= dt;
    if (P.powerT <= 0) { P.power = null; popup(tmpA.set(P.pos.x, P.pos.y + 2.4, P.pos.z), 'POWER DOWN', 'red'); }
  }
  if (P.reloadT > 0) { P.reloadT -= dt; if (P.reloadT <= 0) { P.reloadT = 0; P.ammo = T.magSize; } }
  const slowed = G.focusActive || P.diveT > 0;
  P.fireCd -= dtR * (slowed ? 0.35 + 0.65 * G.timeScale : 1); // about half rate in bullet time, still quicker than the world
  if (firing() && P.fireCd <= 0) { fire(); P.fireCd = P.powerT > 0 && P.power === 'rapid' ? T.rapidEvery : T.fireEvery; }
  if (G.clock - P.lastHurt > 4) P.hp = Math.min(100, P.hp + 7 * dtR);
}

/** One frame of play (also runs while the game-over slow-mo plays out). */
export function updatePlay(dtR) {
  G.clock += dtR;
  updateFocus(dtR);
  const dtWorld = dtR * G.timeScale;
  if (level.info.update) level.info.update(dtWorld); // moving parts of the stage (the subway train, the club lights)
  updateEvents(dtWorld);
  // stage events: one every 40-55 s of a wave, on the stages that have one
  if (level.info.event && G.mode === 'play' && G.wave > 0 && G.waveGap <= 0) {
    G.eventT -= dtWorld;
    if (G.eventT <= 0) { G.eventT = rand(40, 55); level.info.event(); }
  }
  if (G.mode === 'play') {
    updatePlayer(dtR);
    updateWeapons(dtR, playerDt(dtR));
    updateKatanaCharge(dtR);
    animateHero(dtR);
    updateLook(dtR, dtWorld);
    updateTutorial(dtR);
    updateWaves(dtWorld);
    if (!G.hints.basics && G.wave === 1 && G.clock - G.waveStartT > 11) {
      G.hints.basics = true;
      hint('Shift to shootdodge in slow motion · land on soldiers to stomp them · slide into a body to surf it', 7000);
    }
  }
  for (const s of world.soldiers) updateSoldier(s, dtWorld);
  updateDrones(dtWorld);
  updateBlade(dtWorld);
  world.soldiers = world.soldiers.filter(s => !s.remove);
  separateSoldiers();
  updateBullets(dtWorld, dtR);
  updatePickups(dtWorld, dtR);
  G.hurtFlash = Math.max(0, G.hurtFlash - dtR * 1.6);
  const lowHp = G.mode === 'play' ? clamp((35 - P.hp) / 35, 0, 1) * 0.35 : 0;
  grade.uniforms.hurt.value = Math.max(G.hurtFlash * 0.55, lowHp);
  if (G.mode === 'play') updateHUD();
}

let orbit = 0;
/** Title screen: slow orbit around the hero and a few display soldiers. */
export function updateMenu(dtR) {
  G.clock += dtR; orbit += dtR * 0.07;
  G.timeScale = damp(G.timeScale, 1, 3, dtR);
  const c = level.info.start;
  const r = level.info.orbitR || 17;
  camera.position.set(c.x + Math.sin(orbit) * r, c.y + level.info.orbitY + Math.sin(orbit * 2) * 0.8, c.z + Math.cos(orbit) * r);
  if (level.info.update) level.info.update(dtR);
  camera.lookAt(c.x, c.y + 0.6, c.z);
  setFov(60);
  for (const s of world.soldiers) updateSoldier(s, dtR);
  poseHeroForMenu(c, dtR);
}

// ---- screens and transitions
export function makeDisplaySoldiers() {
  clearSoldiers();
  const s = level.info.start;
  makeSoldier(s.x - 1.6, s.z + 1.2, { y: s.y, idle: true }).model.rotation.y = 0.5;
  makeSoldier(s.x + 1.8, s.z - 0.4, { y: s.y, idle: true }).model.rotation.y = 2.4;
  makeSoldier(s.x + 0.2, s.z - 2.2, { y: s.y, idle: true }).model.rotation.y = 3.6;
}
export function selectStartStage(index) {
  G.startStage = index;
  loadLevel(STAGES[index]);
  makeDisplaySoldiers();
}

/** Wipe the run and load the stage for wave w. */
function resetWorld(w = 1) {
  G.daily = null;
  resetBlade();
  endSurf(false);
  endTutorial(false);
  loadLevel(stageFor(w));
  clearSoldiers(); clearDrones(); clearBullets(); clearPickups(); clearGore(); clearHudEffects();
  resetPlayer(level.info.start);
  Object.assign(G, {
    killCam: null, parryT: 0, finalT: 0, eventT: 25, blackout: false,
    wave: 0, toSpawn: 0, waveGap: 0, bossPending: false, score: 0, kills: 0, combo: 0, lastKill: -99,
    lives: T.startLives, hellfire: T.startHellfire, nextLifeAt: T.firstExtraLife, hitStop: 0, hurtFlash: 0, focusActive: false,
  });
  Object.assign(input, { fire: false, focus: false, focusToggle: false, jump: false, dive: false });
}

export function lockPointer(retry = true) {
  try {
    const p = renderer.domElement.requestPointerLock();
    // Chrome refuses a re-lock for about a second after Esc releases it (resuming straight from pause), and
    // a controller button doesn't count as a click; try once more, then the "click to aim" prompt takes over
    if (p && p.catch) p.catch(() => { if (retry) setTimeout(() => { if (G.mode === 'play' && !document.pointerLockElement) lockPointer(false); }, 1200); });
  } catch { /* not supported: mouse look still works while held */ }
}
function releasePointer() { if (document.pointerLockElement) document.exitPointerLock(); }

let runId = 0;
function enterPlay() {
  G.mode = 'play'; G.camDist = 3.4; setFov(78);
  showScreen('play');
  lockPointer();
  const run = ++runId;
  setTimeout(() => { if (run === runId && G.mode === 'play') nextWave(); }, 600);
}
export function startGame() {
  commitInitialsIfPending(); stopContinue();
  G.continuesLeft = T.maxContinues;
  initAudio(); resetWorld(1); enterPlay();
}
/** Training: a run in the warehouse with the waves held until every prompt is cleared. */
export function startTraining() {
  const keep = G.startStage;
  G.startStage = 0; startGame(); G.startStage = keep; // the real waves then begin on the chosen stage
  startTutorial();
}
/** Today's challenge: its stage and twist, one run, no continues. */
export function startDaily() {
  const d = today(), keep = G.startStage;
  G.startStage = d.stage; startGame(); G.startStage = keep;
  G.daily = d; G.continuesLeft = 0;
  setTimeout(() => { if (G.mode === 'play' && G.daily) hint(`Daily challenge · ${MODS[d.mod].name}: ${MODS[d.mod].desc}`, 6000); }, 600);
}
/** The line under the Daily button: today's stage and twist. */
export function renderDailyNote() {
  const d = today(), best = Number(store.get('daily-' + d.key, '0')) || 0;
  $('dailyNote').innerHTML = '';
  const b = document.createElement('b'); b.textContent = `TODAY: ${STAGE_NAMES[STAGES[d.stage]].toUpperCase()} · ${MODS[d.mod].name.toUpperCase()}`;
  $('dailyNote').append(b, document.createTextNode(` ${MODS[d.mod].desc}${best ? ` Your best today: ${best.toLocaleString()}.` : ''}`));
}
export function continueGame() {
  if (G.mode !== 'dead' || G.continuesLeft <= 0) return;
  commitInitialsIfPending(); stopContinue();
  G.continuesLeft--;
  initAudio();
  const w = G.wave; resetWorld(w); G.wave = w - 1; // nextWave() brings it back to w
  enterPlay();
}
export function pauseGame() {
  if (G.mode !== 'play') return;
  G.mode = 'paused';
  Object.assign(input, { fire: false, focus: false });
  Object.assign(input.pad, { x: 0, y: 0, fire: false, focus: false });
  showScreen('pause');
  suspendAudio();
}
export function resumeGame() {
  if (G.mode !== 'paused') return;
  G.mode = 'play'; showScreen('play'); resumeAudio(); lockPointer();
}
/** Back to the title screen from pause or game over. */
export function quitToMenu() {
  commitInitialsIfPending(); stopContinue();
  releasePointer(); resumeAudio();
  G.mode = 'menu'; runId++;
  resetWorld(1);
  makeDisplaySoldiers();
  hero.root.visible = true;
  renderScores($('menuScores'));
  showScreen('menu');
}

// ---- game over, initials and the continue countdown
let contTimer = 0;
function stopContinue() { clearInterval(contTimer); }
const continuesNote = () => `${G.continuesLeft} ${G.continuesLeft === 1 ? 'continue' : 'continues'} left.`;
function startContinue() {
  stopContinue();
  if (G.continuesLeft <= 0) {
    $('contBtn').hidden = true;
    $('contNote').textContent = 'No continues left. Start a new game or head back to the main menu.';
    return;
  }
  let left = 9;
  $('contBtn').hidden = false; $('contT').textContent = left;
  $('contNote').textContent = `Continue keeps your wave but resets your score to zero. ${continuesNote()}`;
  contTimer = setInterval(() => {
    left--; $('contT').textContent = left; sfx.tick();
    if (left <= 0) {
      stopContinue(); $('contBtn').hidden = true;
      $('contNote').textContent = "Time's up. Start a new game or head back to the main menu.";
    }
  }, 1000);
}
let worldRun = null; // the run waiting on initials for the world board
let dailyRun = null; // a daily run waiting on initials for today's board
function commitInitialsIfPending() {
  if (dailyRun) {
    submitDaily({ ...dailyRun, n: $('initials').value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 3).padEnd(3, '-') });
    dailyRun = null; $('initForm').hidden = true; return;
  }
  if (!hasPending()) return;
  const initials = $('initials').value;
  const idx = commitPending(initials);
  if (worldRun) {
    submitWorld({ ...worldRun, n: initials.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 3).padEnd(3, '-') });
    worldRun = null;
  }
  $('initForm').hidden = true;
  renderScores($('overScores'), idx); renderScores($('menuScores'), idx);
}
/** Redraw the world top ten on the menu and game-over screens (shown only when the board is reachable). */
export function renderWorldBoards() {
  for (const id of ['menuWorld', 'overWorld', 'menuDaily', 'overDaily']) {
    const ol = $(id), on = worldReady();
    ol.hidden = !on; ol.previousElementSibling.hidden = !on;
    if (on) (id.endsWith('Daily') ? renderDaily : renderWorld)(ol);
  }
}
/** Save initials from the form (or the controller) and unlock Continue. */
export function submitInitials() {
  if (!hasPending() && !dailyRun) return;
  commitInitialsIfPending(); sfx.blip(); startContinue();
}
export const awaitingInitials = () => hasPending() || !!dailyRun;
export const canContinue = () => !$('contBtn').hidden;

function gameOver() {
  G.mode = 'dead'; G.focusActive = false;
  Object.assign(input, { fire: false, focus: false });
  banner('game over', '', 1600);
  setTimeout(() => {
    if (G.mode !== 'dead') return; // the player already left
    releasePointer();
    $('oScore').textContent = pad(G.score, 7); $('oWave').textContent = G.wave; $('oKills').textContent = G.kills;
    if (G.daily) {
      // a daily run: its own local best and world board, never the normal high-score tables, no continues
      const d = G.daily, best = Number(store.get('daily-' + d.key, '0')) || 0;
      if (G.score > best) store.set('daily-' + d.key, String(G.score));
      const world = beatsDailyBest(G.score, d.key);
      dailyRun = world ? { s: G.score, key: d.key, mod: d.mod } : null;
      $('initLabel').innerHTML = 'Daily best!<br>Enter initials';
      $('initForm').hidden = !world;
      $('contBtn').hidden = true;
      $('contNote').textContent = (G.score > best ? 'New best for today. ' : '') + 'Daily runs have no continues. A new challenge arrives tomorrow.';
      renderScores($('overScores')); renderWorldBoards(); renderDailyNote();
      showScreen('over');
      if (world) { const inp = $('initials'); inp.focus(); inp.select(); }
      return;
    }
    const local = qualifies(G.score), world = beatsWorldBest(G.score), isHigh = local || world;
    worldRun = world ? { s: G.score, wave: G.wave, stage: level.info.label } : null;
    if (isHigh) holdScore(G.score);
    $('initLabel').innerHTML = world && !local ? 'New personal best!<br>Enter initials' : 'New high score!<br>Enter initials';
    $('initForm').hidden = !isHigh;
    renderScores($('overScores'));
    showScreen('over');
    if (isHigh) {
      $('contBtn').hidden = true;
      $('contNote').textContent = G.continuesLeft > 0 ? `Save your initials to unlock Continue. ${continuesNote()}` : 'No continues left.';
      const inp = $('initials'); inp.focus(); inp.select();
    } else startContinue();
  }, 1700);
}
