// The hooded gunslinger: a jointed model in a long split duster, and its procedural animation.
import * as THREE from 'three';
import { scene } from './engine.js';
import { V3, clamp, damp, lerpAngle, tmpA, tmpC } from './util.js';
import { HM, gunMat, bootMat } from './materials.js';
import { dotTex } from './textures.js';
import { embers, addFx } from './fx.js';
import { level } from './physics.js';
import { T } from './config.js';
import { G, P, firing } from './state.js';
import { bladeInHand, bladeState, bladeAnim, WINDUP } from './blade.js';
import { mergeRigidParts } from './merge.js';

// Proportions (metres, feet at y = 0, facing +z)
const HIP_Y = 0.98, THIGH = 0.45, SHIN = 0.44, SHOULDER_Y = 1.46, UPPER_ARM = 0.31, FOREARM = 0.29;

function buildHero() {
  const root = new THREE.Group(), body = new THREE.Group(); root.add(body);
  const add = (geo, mat, x, y, z, parent = body) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; parent.add(m); return m; };
  const joint = (parent, x, y, z = 0) => { const g = new THREE.Group(); g.position.set(x, y, z); parent.add(g); return g; };
  const trimRing = (r, tube, y, parent, sz = 1) => { const t = add(new THREE.TorusGeometry(r, tube, 6, 32), HM.trim, 0, y, 0, parent); t.rotation.x = Math.PI / 2; t.scale.y = sz; return t; };

  // Shapes are lathe-turned from profiles ([radius, height] from the top of a segment down), so limbs swell and
  // taper like muscle instead of being plain capsules. A segment is closed at both ends and can be squashed.
  const lathe = (pts, seg = 20) => new THREE.LatheGeometry(pts.map(([r, y]) => new THREE.Vector2(r, y)), seg);
  const limb = (prof, sz = 1, sx = 1) => {
    const pts = [[0, prof[0][1] + 0.004], ...prof, [0, prof[prof.length - 1][1] - 0.004]].reverse(); // bottom to top: outward normals
    const g = lathe(pts); g.scale(sx, 1, sz); return g;
  };
  const ellipsoid = (r, sx, sy, sz, seg = 14) => new THREE.SphereGeometry(r, seg, Math.max(8, seg - 4)).scale(sx, sy, sz);

  // ---- legs: hip → knee → ankle; trousers over shaped thighs and calves, sculpted boots
  const bootShape = new THREE.Shape();
  [[-0.068, -0.09], [0.165, -0.09], [0.196, -0.072], [0.19, -0.04], [0.15, -0.022], [0.075, 0.0], [0.04, 0.05], [-0.05, 0.05], [-0.078, -0.02]]
    .forEach(([f, u], i) => (i ? bootShape.lineTo(f, u) : bootShape.moveTo(f, u)));
  bootShape.closePath();
  const footGeo = new THREE.ExtrudeGeometry(bootShape, { depth: 0.094, bevelEnabled: true, bevelSize: 0.012, bevelThickness: 0.012, bevelSegments: 2, curveSegments: 4 });
  footGeo.translate(0, 0, -0.047); footGeo.rotateY(-Math.PI / 2); // profile runs forward (+z), width across x
  const legs = [-1, 1].map(side => {
    const hip = joint(body, side * 0.1, HIP_Y);
    add(limb([[0.088, 0], [0.095, -0.05], [0.09, -0.15], [0.077, -0.29], [0.063, -0.41], [0.058, -0.45]], 1.06), HM.trousers, 0, 0, 0, hip);
    if (side > 0) { // a holster strapped to the right thigh
      add(new THREE.TorusGeometry(0.09, 0.008, 6, 20).rotateX(Math.PI / 2), HM.leather, 0, -0.2, 0, hip);
      add(new THREE.BoxGeometry(0.035, 0.16, 0.07), HM.leather, 0.085, -0.18, 0.0, hip);
    }
    const knee = joint(hip, 0, -THIGH);
    add(ellipsoid(0.045, 1, 1.15, 0.7), HM.trousers, 0, 0.012, 0.038, knee); // kneecap
    add(limb([[0.058, 0], [0.064, -0.06], [0.066, -0.13], [0.056, -0.25], [0.047, -0.36], [0.045, -0.44]]), HM.trousers, 0, 0, 0, knee);
    add(ellipsoid(0.048, 1, 1.9, 0.85), HM.trousers, 0, -0.13, -0.022, knee); // calf
    const ankle = joint(knee, 0, -SHIN);
    add(limb([[0.067, 0.17], [0.066, 0.1], [0.064, 0.02], [0.06, -0.03]]), bootMat, 0, 0, 0, ankle); // boot shaft over the shin
    add(footGeo, bootMat, 0, 0, 0, ankle);
    add(new THREE.BoxGeometry(0.12, 0.022, 0.285), HM.sole, 0, -0.092, 0.058, ankle);
    add(new THREE.TorusGeometry(0.068, 0.007, 6, 20).rotateX(Math.PI / 2), HM.leather, 0, 0.11, 0, ankle); // strap
    add(new THREE.BoxGeometry(0.022, 0.026, 0.01), HM.buckle, side * 0.062, 0.11, 0.02, ankle);
    return { hip, knee, ankle };
  });

  // ---- torso: hips and waist, a shirt-and-vest chest under the duster, sloped shoulders
  add(lathe([[0, 0.88], [0.13, 0.885], [0.148, 0.94], [0.14, 1.0], [0.128, 1.06], [0, 1.065]], 22).scale(1, 1, 0.68), HM.trousers, 0, 0, 0);
  add(lathe([[0, 1.02], [0.13, 1.025], [0.13, 1.1], [0.146, 1.2], [0.166, 1.3], [0.17, 1.37], [0.152, 1.44], [0.11, 1.49], [0.062, 1.53], [0, 1.535]], 24).scale(1, 1, 0.66), HM.coatSolid, 0, 0, 0);
  // lapels open over a dark shirt
  add(new THREE.BoxGeometry(0.075, 0.24, 0.01), HM.shirt, 0, 1.36, 0.107);
  for (const sd of [-1, 1]) { const l = add(new THREE.BoxGeometry(0.06, 0.3, 0.016), HM.coat, sd * 0.05, 1.33, 0.11); l.rotation.z = sd * 0.32; l.rotation.x = -0.12; }
  // belt with a buckle and pouches, a bandolier across the chest
  add(new THREE.TorusGeometry(0.135, 0.016, 6, 28).rotateX(Math.PI / 2).scale(1, 1, 0.7), HM.leather, 0, 1.04, 0);
  add(new THREE.BoxGeometry(0.055, 0.045, 0.014), HM.buckle, 0, 1.04, 0.098);
  for (const sd of [-1, 1]) add(new THREE.BoxGeometry(0.06, 0.07, 0.04), HM.leather, sd * 0.11, 1.02, 0.06);
  for (const zf of [1, -1]) { const st = add(new THREE.BoxGeometry(0.034, 0.56, 0.012), HM.leather, 0.01, 1.26, zf * 0.112); st.rotation.z = -0.62 * zf; }
  for (let i = 0; i < 3; i++) add(new THREE.BoxGeometry(0.03, 0.04, 0.02), HM.buckle, -0.07 + i * 0.065, 1.38 - i * 0.09, 0.116);
  // a high collar, open at the front
  add(new THREE.CylinderGeometry(0.088, 0.1, 0.1, 22, 1, true, 0.5, Math.PI * 2 - 1.0), HM.coat, 0, 1.53, -0.005);

  // ---- duster skirt: four panels hinged at the waist, open at the front, with folds that deepen toward the hem
  const panel = (start, len) => {
    const pivot = joint(body, 0, 1.04);
    const geo = new THREE.CylinderGeometry(0.168, 0.33, 0.78, 18, 5, true, start, len);
    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i), t = (0.39 - y) / 0.78, th = Math.atan2(x, z);
      const k = 1 + Math.sin(th * 9 + 0.6) * 0.04 * t;
      pos.setXYZ(i, x * k, y, z * k);
    }
    geo.computeVertexNormals(); geo.translate(0, -0.39, 0);
    const mesh = add(geo, HM.coat, 0, 0, 0, pivot);
    pivot.userData.rest = Float32Array.from(geo.attributes.position.array); // the unbent panel
    pivot.userData.mesh = mesh; pivot.userData.bend = 0; mesh.userData.keep = true;
    return pivot;
  };
  const coat = {
    frontPos: panel(0.24, 1.33),                    // front, +x side
    backPos: panel(Math.PI / 2, Math.PI / 2),        // back, +x side
    backNeg: panel(Math.PI, Math.PI / 2),            // back, -x side
    frontNeg: panel(Math.PI * 1.5, 1.33),            // front, -x side
  };

  // ---- head and hood: a skull-shaped shadow, a cloth wrap over the lower face, burning eyes, a deep hood
  add(limb([[0.05, 1.62], [0.052, 1.57], [0.06, 1.52]]), HM.wrap, 0, 0, 0);
  const hood = joint(body, 0, 1.6);
  add(ellipsoid(0.1, 0.9, 1.05, 1, 18), HM.void, 0, 0.11, 0, hood);        // cranium
  add(ellipsoid(0.078, 0.95, 0.85, 1.05, 16), HM.void, 0, 0.045, 0.022, hood); // jaw
  add(new THREE.CylinderGeometry(0.097, 0.088, 0.075, 22, 1, true), HM.wrap, 0, 0.05, 0.012, hood); // face wrap up to the eyes
  for (const x of [-0.036, 0.036]) add(new THREE.SphereGeometry(0.013, 8, 6), HM.eye, x, 0.112, 0.094, hood).scale.set(1.9, 0.65, 0.5);
  const gap = 1.25;
  const hoodProfile = [[0.122, -0.06], [0.142, 0.02], [0.152, 0.11], [0.142, 0.19], [0.11, 0.25], [0.05, 0.285], [0, 0.29]].map(([r, y]) => new THREE.Vector2(r, y));
  const cowl = add(new THREE.LatheGeometry(hoodProfile, 28, gap / 2, Math.PI * 2 - gap), HM.coat, 0, 0, -0.012, hood); // open at the front
  cowl.scale.set(1, 1, 1.14); cowl.rotation.x = 0.12;
  // mantle over the shoulders, open at the front, with an ember-trimmed hem
  add(lathe([[0.27, 1.32], [0.262, 1.38], [0.22, 1.45], [0.14, 1.52], [0.1, 1.57]], 28).scale(1, 1, 0.78), HM.coat, 0, 0, -0.01);
  trimRing(0.27, 0.006, 1.32, body, 0.78);

  // ---- arms: shoulder → elbow → hand; deltoids, shaped sleeves, gloved fists round a pistol each
  const arms = [-1, 1].map(side => {
    const shoulder = joint(body, side * 0.23, SHOULDER_Y);
    add(ellipsoid(0.062, 1.08, 0.9, 1.0, 16), HM.coatSolid, side * 0.008, -0.03, 0, shoulder); // deltoid, sunk into the sleeve
    add(limb([[0.064, 0.01], [0.067, -0.05], [0.061, -0.15], [0.051, -0.26], [0.046, -0.31]], 0.95), HM.coatSolid, 0, 0, 0, shoulder);
    const elbow = joint(shoulder, 0, -UPPER_ARM);
    add(limb([[0.047, 0], [0.053, -0.06], [0.05, -0.14], [0.041, -0.23], [0.037, -0.29]], 0.9), HM.coatSolid, 0, 0, 0, elbow);
    add(new THREE.CylinderGeometry(0.052, 0.047, 0.055, 16, 1, true), HM.coat, 0, -FOREARM + 0.045, 0, elbow); // cuff
    trimRing(0.052, 0.005, -FOREARM + 0.02, elbow);
    const hand = joint(elbow, 0, -FOREARM);
    add(ellipsoid(0.04, 0.9, 1.25, 0.6), HM.glove, 0, -0.035, -0.005, hand);              // palm
    add(ellipsoid(0.034, 1.05, 0.95, 1.15), HM.glove, 0, -0.062, 0.022, hand);           // curled fingers
    add(ellipsoid(0.016, 1, 2.1, 1), HM.glove, -side * 0.032, -0.04, 0.024, hand).rotation.z = side * 0.5; // thumb
    const gun = joint(hand, 0, -0.02, 0.02);
    add(new THREE.BoxGeometry(0.036, 0.26, 0.052), gunMat, 0, -0.13, 0, gun);              // slide
    add(new THREE.CylinderGeometry(0.012, 0.012, 0.05, 10), gunMat, 0, -0.27, 0.006, gun); // muzzle
    add(new THREE.BoxGeometry(0.03, 0.05, 0.11).translate(0, 0, -0.06), gunMat, 0, -0.005, 0, gun).rotation.x = 0.25; // grip
    add(new THREE.TorusGeometry(0.018, 0.004, 4, 10, Math.PI).rotateY(Math.PI / 2), gunMat, 0, -0.035, -0.035, gun); // trigger guard
    add(new THREE.BoxGeometry(0.008, 0.24, 0.006), HM.trim, 0, -0.13, 0.028, gun);
    const muzzle = joint(gun, 0, -0.29);
    const flash = new THREE.Sprite(new THREE.SpriteMaterial({ map: dotTex, color: new THREE.Color(4, 2.2, 0.7), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true }));
    flash.scale.setScalar(0.6); flash.visible = false; muzzle.add(flash);
    return { shoulder, elbow, hand, gun, muzzle, flash, flashT: 0, aimT: 0, kick: 0, kickX: 0, kickE: 0 };
  });
  // ---- the katana's scabbard across the back, hilt over the right shoulder (hidden while the blade is out)
  const saya = joint(body, -0.02, 1.16, -0.225); saya.rotation.z = 0.5; saya.rotation.x = 0.06;
  add(new THREE.CylinderGeometry(0.024, 0.02, 0.86, 10).scale(1, 1, 0.65), HM.leather, 0, -0.06, 0, saya);
  add(new THREE.CylinderGeometry(0.027, 0.027, 0.04, 10).scale(1, 1, 0.65), HM.buckle, 0, 0.36, 0, saya);   // throat
  add(new THREE.CylinderGeometry(0.022, 0.016, 0.05, 10).scale(1, 1, 0.65), HM.buckle, 0, -0.5, 0, saya);  // tip
  const hilt = joint(saya, 0, 0.38);
  add(new THREE.BoxGeometry(0.075, 0.012, 0.06), gunMat, 0, 0.005, 0, hilt);                              // guard
  add(new THREE.CylinderGeometry(0.017, 0.016, 0.22, 8), bootMat, 0, 0.12, 0, hilt);                       // wrapped handle
  for (let i = 0; i < 5; i++) add(new THREE.TorusGeometry(0.017, 0.003, 4, 10).rotateX(Math.PI / 2), HM.trim, 0, 0.03 + i * 0.042, 0, hilt);
  add(new THREE.CylinderGeometry(0.019, 0.019, 0.016, 8), gunMat, 0, 0.235, 0, hilt);                      // pommel
  // a strap holds it: over the right shoulder, under the left arm
  for (const [x, y, z, rz] of [[0.13, 1.43, -0.14, -0.9], [-0.13, 1.08, -0.15, -0.9]]) add(new THREE.BoxGeometry(0.03, 0.12, 0.012), HM.leather, x, y, z).rotation.z = rz;
  // lapel buttons and shoulder seams
  for (const sd of [-1, 1]) for (let i = 0; i < 3; i++) add(new THREE.SphereGeometry(0.011, 8, 6), HM.buckle, sd * (0.075 - i * 0.012), 1.4 - i * 0.075, 0.117);
  for (const sd of [-1, 1]) { const seam = add(new THREE.BoxGeometry(0.006, 0.006, 0.17), HM.leather, sd * 0.2, 1.46, 0); seam.rotation.z = sd * 0.5; }
  // the eyes light the inside of the hood a little
  const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: dotTex, color: new THREE.Color(0.32, 0.1, 0.025), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true }));
  glow.position.set(0, 0.11, 0.09); glow.scale.setScalar(0.22); hood.add(glow);
  arms[1].shoulder.rotation.order = 'YXZ'; // the katana swing yaws this arm

  const katana = joint(arms[1].hand, 0, -0.03);
  katana.visible = false;
  add(new THREE.BoxGeometry(0.032, 0.23, 0.036), bootMat, 0, 0.03, 0, katana);           // handle, pommel end toward +y
  add(new THREE.BoxGeometry(0.036, 0.02, 0.04), gunMat, 0, 0.15, 0, katana);             // pommel cap
  add(new THREE.BoxGeometry(0.09, 0.014, 0.075), gunMat, 0, -0.09, 0, katana);           // guard
  add(new THREE.BoxGeometry(0.014, 0.98, 0.048), HM.blade, 0, -0.59, 0, katana);         // blade, edge toward +z
  add(new THREE.BoxGeometry(0.006, 0.96, 0.01), HM.bladeEdge, 0, -0.59, 0.027, katana);

  // no ink outline on the hero: his rim light and the rim glow on his coat carry the silhouette
  mergeRigidParts(body);

  // ember ring at the feet during bullet time and power-ups
  const ring = new THREE.Group(); ring.position.y = 0.3; ring.rotation.z = 0.12; root.add(ring);
  const band = new THREE.Mesh(new THREE.TorusGeometry(0.72, 0.004, 4, 64), HM.rune); band.rotation.x = Math.PI / 2; ring.add(band);
  for (let i = 0; i < 9; i++) {
    const r = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.07, 0.008), HM.rune);
    const a = i / 9 * Math.PI * 2; r.position.set(Math.cos(a) * 0.72, 0, Math.sin(a) * 0.72); r.rotation.y = -a; ring.add(r);
  }
  // rim and fill lights ride along so the coat's shape reads in the dark
  const rim = new THREE.PointLight(0xffa060, 6, 3.6, 1.3); rim.position.set(0, 2.4, -0.9); root.add(rim);
  const fill = new THREE.PointLight(0xffc090, 2, 3, 1.5); fill.position.set(0.4, 1.5, 1.1); root.add(fill);
  scene.add(root);

  return {
    root, body, hood, coat, katana, ring, sheathHilt: hilt, breathT: 1,
    legL: legs[0], legR: legs[1], arms, hands: arms,
    face: 0, phase: 0, amp: 0, off: new V3(), lastVel: new V3(), accF: 0, accR: 0,
    wallSide: 1, wallHit: 0, hadWall: false, kick: 0, kickSide: 1, step: 0, reach: 0,
    land: 0, airVy: 0, wasGrounded: true, lastSwordT: 0, sword: { dir: new V3(0, 0.5, 1).normalize(), grip: new V3(0, 1.05, 0.34), edge: new V3(0, -1, 0), twist: 0 },
    swordFrom: { dir: new V3(), grip: new V3(), edge: new V3(), twist: 0 }, coatBN: { x: 0, v: 0 }, coatBP: { x: 0, v: 0 },
  };
}

export const hero = buildHero();
export const muzzleLight = new THREE.PointLight(0xffb070, 0, 10, 2);
scene.add(muzzleLight);

const approach = (obj, prop, target, rate, dt) => { obj[prop] = damp(obj[prop], target, rate, dt); };
const wrapAngle = a => Math.atan2(Math.sin(a), Math.cos(a));
/** A damped spring toward target (state {x, v}); underdamped, so cloth overshoots and settles. */
const spring = (s, target, k, c, dt) => { s.v += ((target - s.x) * k - s.v * c) * dt; s.x += s.v * dt; return s.x; };
const smooth = t => t * t * (3 - 2 * t);

/**
 * One leg of the gait cycle. Phase p: heel strike at π/2, stance through π, toe-off at 3π/2, swing back round.
 * Returns hip flexion (negative = thigh forward), knee bend and the ankle's extra toe point.
 */
function gaitLeg(p, amp, run) {
  const s = Math.sin(p);
  const hip = (-(0.36 + 0.42 * run) * s - 0.1 * run) * amp;
  const knee = 0.06 + amp * ((0.1 + 0.28 * run) * Math.max(0, -Math.cos(p))            // give under load at mid-stance
    + (0.5 + 1.15 * run) * Math.max(0, Math.cos(p + 0.35)) ** 1.5);                     // fold up through the swing
  const toe = amp * ((0.25 + 0.5 * run) * Math.max(0, -s) ** 3 - 0.22 * Math.max(0, s) ** 4); // push off, heel first
  return { hip, knee, toe };
}

// ---- katana: a two-handed diagonal cut
// Timeline from the moment of the slash (seconds): chamber the blade over one shoulder, cut through the
// arc the slash effect draws, follow through low on the far side, then come back to a centre guard.
const CHAMBER = 0.045, CUT = 0.13, SETTLE = 0.2, RECOVER = 0.22;
const SWORD_CHEST = new V3(0, 1.22, 0.16), GUARD_DIR = new V3(0, 0.55, 1).normalize(), GUARD_GRIP = new V3(0, 1.05, 0.34);
const _sv = [new V3(), new V3(), new V3(), new V3()], _q = new THREE.Quaternion(), _q2 = new THREE.Quaternion(), _mat = new THREE.Matrix4();

/** Blade pose at angle th in the cut plane (th = 0 points straight ahead). Writes into out. */
function cutPose(th, sigma, tilt, out) {
  const S = _sv[0].set(Math.cos(tilt), -Math.sin(tilt), 0); // the plane's sideways axis, tilted like the slash arc
  const raise = 0.55 * Math.max(0, sigma * th / 2) ** 1.5;   // chambered blades sit high over the shoulder
  out.dir.set(0, raise, 0).addScaledVector(S, Math.sin(th)).add(_sv[1].set(0, 0, Math.cos(th))).normalize();
  out.grip.copy(SWORD_CHEST).addScaledVector(out.dir, 0.2 + 0.1 * Math.max(0, Math.cos(th)));
  out.edge.set(0, 0, -Math.sin(th)).addScaledVector(S, Math.cos(th)).multiplyScalar(-sigma); // the edge leads the swing
  out.twist = th * 0.24; // the torso winds up with the chamber and unwinds through the cut
  return out;
}
function lerpPose(a, b, k, out) {
  out.dir.copy(a.dir).lerp(b.dir, k).normalize(); out.grip.copy(a.grip).lerp(b.grip, k);
  out.edge.copy(a.edge).lerp(b.edge, k); out.twist = a.twist + (b.twist - a.twist) * k;
  return out;
}
const _pa = { dir: new V3(), grip: new V3(), edge: new V3(), twist: 0 }, _pb = { dir: new V3(), grip: new V3(), edge: new V3(), twist: 0 };
const GUARD = { dir: GUARD_DIR, grip: GUARD_GRIP, edge: new V3(0, -1, 0), twist: 0 };
function swordPose(m, age, out) {
  const sigma = P.slashDir, tilt = P.slashTilt, th0 = 2.0 * sigma, th1 = -1.35 * sigma;
  if (age < CHAMBER) return lerpPose(m.swordFrom, cutPose(th0, sigma, tilt, _pa), smooth(age / CHAMBER), out);
  age -= CHAMBER;
  if (age < CUT) return cutPose(th0 + (th1 - th0) * smooth(age / CUT), sigma, tilt, out);
  age -= CUT;
  if (age < SETTLE) return cutPose(th1 + 0.15 * sigma * smooth(age / SETTLE), sigma, tilt, out);
  age -= SETTLE;
  return lerpPose(cutPose(th1 + 0.15 * sigma, sigma, tilt, _pb), GUARD, smooth(Math.min(1, age / RECOVER)), out);
}

/** Two-bone IK: aim an arm's shoulder and bend its elbow so the hand lands on target (body space). */
function reachFor(arm, target, side) {
  const t = _sv[0].copy(target).sub(arm.shoulder.position);
  const L1 = UPPER_ARM, L2 = FOREARM + 0.03;
  const d = clamp(t.length(), 0.12, L1 + L2 - 0.004);
  const bend = Math.PI - Math.acos(clamp((L1 * L1 + L2 * L2 - d * d) / (2 * L1 * L2), -1, 1));
  arm.elbow.rotation.set(-bend, 0, 0);
  const h = _sv[1].set(0, -L1 - L2 * Math.cos(bend), L2 * Math.sin(bend)).normalize();
  t.normalize();
  _q.setFromUnitVectors(h, t);
  // roll the arm about the shoulder→hand line so the elbow hangs down and out
  const e = _sv[2].set(0, -1, 0).applyQuaternion(_q), pole = _sv[3].set(side * 0.6, -1, -0.35);
  e.addScaledVector(t, -e.dot(t)); pole.addScaledVector(t, -pole.dot(t));
  if (e.lengthSq() > 1e-6 && pole.lengthSq() > 1e-6) {
    e.normalize(); pole.normalize();
    let ang = Math.acos(clamp(e.dot(pole), -1, 1));
    if (_sv[1].crossVectors(e, pole).dot(t) < 0) ang = -ang;
    _q.premultiply(_q2.setFromAxisAngle(t, ang));
  }
  arm.shoulder.quaternion.copy(_q);
}

/** reachFor, eased in from the arm's current pose so a switch into IK doesn't snap. */
const _qa = new THREE.Quaternion();
function reachToward(arm, target, side, rate, dt) {
  _qa.copy(arm.shoulder.quaternion); const e = arm.elbow.rotation.x;
  reachFor(arm, target, side);
  const k = 1 - Math.exp(-rate * dt);
  arm.shoulder.quaternion.copy(_qa.slerp(arm.shoulder.quaternion, k));
  arm.elbow.rotation.x = e + (arm.elbow.rotation.x - e) * k;
  arm.kickX = arm.kickE = 0;
}

/** Both hands on the hilt, the blade along the pose's direction with its edge leading. */
function poseSword(m) {
  const sw = m.sword;
  reachFor(m.arms[1], sw.grip, 1);
  reachFor(m.arms[0], _pa.grip.copy(sw.grip).addScaledVector(sw.dir, -0.12), -1); // left hand at the pommel
  for (const a of m.arms) { a.hand.rotation.set(0, 0, 0); a.kickX = a.kickE = 0; }
  orientKatana(m, sw.dir, sw.edge);
}
/** Turn the katana in the sword hand so the blade runs along dir with its edge toward edge (both body space). */
function orientKatana(m, dir, edge) {
  const y = _sv[0].copy(dir).negate();
  const z = _sv[1].copy(edge).addScaledVector(y, -edge.dot(y));
  if (z.lengthSq() < 1e-6) z.set(0, -1, 0).addScaledVector(y, y.y);
  z.normalize();
  const x = _sv[2].crossVectors(y, z);
  _q.setFromRotationMatrix(_mat.makeBasis(x, y, z));
  m.body.getWorldQuaternion(_q2); _q.premultiply(_q2);                     // blade orientation in the world
  m.arms[1].hand.getWorldQuaternion(_q2); m.katana.quaternion.copy(_q2.invert().multiply(_q));
}

// ---- katana throw: a backhand, like skimming a stone. Seconds from the press: the blade is drawn across the
// body and the shoulder winds in (release at WINDUP, blade.js), the arm whips out along the aim, follows through
// wide and open-handed, then comes back. The catch: the hand meets the blade, gives with it, and slides it home.
const WHIP = 0.08, FOLLOW = 0.2, THROW_END = WINDUP + WHIP + FOLLOW + 0.2;
const CATCH_GIVE = 0.1, CATCH_END = 0.5;
const THROW_KEYS = [ // [hand, blade dir, twist], body space; hand y is raised by the aim pitch
  [new V3(-0.26, 1.28, 0.16), new V3(-0.95, 0.05, -0.3), -0.8],  // cocked across the chest, tip trailing back
  [new V3(0.2, 1.4, 0.58), new V3(0.15, 0.05, 1), 0.15],         // release: arm long, pointing down the aim
  [new V3(0.52, 1.28, 0.24), new V3(0.9, -0.2, 0.2), 0.55],      // follow through: wide, shoulder open
];
const _tk = { hand: new V3(), dir: new V3(), twist: 0 };
function throwKey(age) {
  const [a, b, c] = THROW_KEYS;
  const mix = (p, q, k) => { _tk.hand.copy(p[0]).lerp(q[0], k); _tk.dir.copy(p[1]).lerp(q[1], k).normalize(); _tk.twist = p[2] + (q[2] - p[2]) * k; };
  if (age < WINDUP) mix(a, a, 0);
  else if (age < WINDUP + WHIP) mix(a, b, smooth((age - WINDUP) / WHIP));
  else mix(b, c, smooth(clamp((age - WINDUP - WHIP) / FOLLOW, 0, 1)));
  return _tk;
}
const CATCH_HOME = new V3(-0.12, 1.62, -0.12); // the scabbard's throat, over the right shoulder

/**
 * Bend a coat panel below the hip line by `target` radians (outward), easing toward it slowly so the hem trails
 * the body like heavy cloth. Rewrites the panel's vertices from its rest shape.
 */
const HINGE = 0.3; // fraction of the panel's length that stays stiff
function bendHem(pivot, target, dt) {
  const u = pivot.userData;
  const next = damp(u.bend, target, 5, dt);
  if (Math.abs(next - u.bend) < 1e-4 && u.bent) return;
  u.bend = next; u.bent = true;
  const pos = u.mesh.geometry.attributes.position, rest = u.rest, L = 0.78;
  for (let i = 0; i < pos.count; i++) {
    const x = rest[i * 3], y = rest[i * 3 + 1], z = rest[i * 3 + 2];
    const t = -y / L;
    if (t <= HINGE) { pos.setXYZ(i, x, y, z); continue; }
    const below = (t - HINGE) * L, phi = next * (t - HINGE) / (1 - HINGE), r = Math.hypot(x, z) || 1;
    const out = Math.sin(phi) * below, up = (1 - Math.cos(phi)) * below;
    pos.setXYZ(i, x + x / r * out, y + up, z + z / r * out);
  }
  pos.needsUpdate = true; u.mesh.geometry.computeVertexNormals();
}

/** On cold stages, his breath fogs from the face wrap every couple of seconds. */
const COLD = new Set(['docks', 'rooftop']);
const puffTex = dotTex;
function breathe(m, dt) {
  m.breathT -= dt;
  if (m.breathT > 0) return;
  m.breathT = 2.2 + Math.random() * 0.8;
  if (!COLD.has(level.info && level.info.name)) return;
  const p = m.hood.localToWorld(new V3(0, 0.05, 0.14)), dir = new V3(Math.sin(m.face), -0.15, Math.cos(m.face));
  for (let i = 0; i < 3; i++) {
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: puffTex, color: 0xc8d4e0, transparent: true, opacity: 0, depthWrite: false }));
    s.material.userData.own = true;
    s.position.copy(p); s.scale.setScalar(0.06);
    const v = dir.clone().multiplyScalar(0.25 + i * 0.06).add(new V3(0, 0.05, 0));
    addFx(s, 1.4, (o, k) => { o.position.addScaledVector(v, 0.016); o.scale.setScalar(0.06 + k * 0.32); o.material.opacity = 0.16 * Math.sin(k * Math.PI) * (1 - i * 0.25); });
  }
}

/** Pose the hero for the current movement state. Called once per frame during play. */
export function animateHero(dtR) {
  const m = hero;
  if (dtR <= 0) return;
  const hv = Math.hypot(P.vel.x, P.vel.z);
  const swordOut = P.swordT > 0;
  if (P.swordT > m.lastSwordT + 1e-3) {
    // a new cut starts from wherever the blade is now (or from guard as it's drawn)
    const from = m.lastSwordT > 0 ? m.sword : GUARD;
    m.swordFrom.dir.copy(from.dir); m.swordFrom.grip.copy(from.grip); m.swordFrom.edge.copy(from.edge); m.swordFrom.twist = from.twist;
    m.swordStart = P.swordT;
  }
  m.lastSwordT = P.swordT;
  const swordAge = swordOut ? m.swordStart - P.swordT : 9;
  if (swordOut) swordPose(m, swordAge, m.sword);
  // throwing and catching (the cut wins if one starts)
  const throwAge = G.clock - bladeAnim.thrownAt, catchAge = G.clock - bladeAnim.caughtAt;
  const throwing = !swordOut && throwAge >= 0 && throwAge < THROW_END && catchAge > throwAge; // a quick recall cuts it short
  const catching = !swordOut && !throwing && catchAge >= 0 && catchAge < CATCH_END;
  const flying = !swordOut && !throwing && !catching ? bladeState() : null;
  const incoming = flying && flying.state === 'recall' && !firing() ? flying.pos : null; // on its way back to the hand
  // weight drives forward through the cut and comes back as the blade returns to guard
  const lunge = swordAge < CHAMBER ? smooth(swordAge / CHAMBER) : swordAge < 0.3 ? 1 : 1 - smooth(clamp((swordAge - 0.3) / 0.25, 0, 1));
  const aiming = firing() || m.arms[0].aimT > 0 || m.arms[1].aimT > 0 || swordOut || throwing || G.focusActive || P.diveT > 0;
  const reloading = P.reloadT > 0 && !aiming;

  // facing: where you're going, or the crosshair while fighting
  let face = P.yaw + Math.PI;
  if (P.climb) face = Math.atan2(-P.climb.nx, -P.climb.nz);
  else if (P.wall) face = Math.atan2(P.vel.x + P.wall.nx * 1.5, P.vel.z + P.wall.nz * 1.5);
  else if (P.surf && !aiming) face = Math.atan2(P.vel.x, P.vel.z) + Math.PI / 2;
  else if (!aiming && hv > 1.5) face = Math.atan2(P.vel.x, P.vel.z);
  m.face = lerpAngle(m.face, face, 1 - Math.exp(-(P.wall ? 20 : aiming ? 18 : 10) * dtR));
  m.root.rotation.y = m.face;
  const sf = Math.sin(m.face), cf = Math.cos(m.face);
  const vf = P.vel.x * sf + P.vel.z * cf, vr = P.vel.x * cf - P.vel.z * sf; // velocity in model space

  // acceleration in model space: lean forward to speed up, back to brake, bank into turns
  const inv = 1 / Math.max(dtR, 1e-3), ax = (P.vel.x - m.lastVel.x) * inv, az = (P.vel.z - m.lastVel.z) * inv;
  m.lastVel.copy(P.vel);
  m.accF = damp(m.accF, clamp(ax * sf + az * cf, -40, 40), 7, dtR);
  m.accR = damp(m.accR, clamp(ax * cf - az * sf, -40, 40), 7, dtR);

  // landings: absorb the drop through the knees, harder the faster we came down
  const inAir = !P.grounded && !P.wall && !P.climb && !P.surf;
  if (!P.grounded) m.airVy = P.vel.y;
  if (P.grounded && !m.wasGrounded && P.slideT <= 0 && P.diveT <= 0) {
    m.land = Math.max(m.land, clamp(-m.airVy / 16, 0.2, 1));
    m.coatBN.v -= 5 * m.land; m.coatBP.v -= 5 * m.land; // the coat keeps falling for a moment
  }
  m.wasGrounded = P.grounded;
  // wall contact: the body sinks into the first footfall; jumping away throws a push-off pose
  if (P.wall) {
    m.wallSide = -(P.wall.nx * cf - P.wall.nz * sf) > 0 ? 1 : -1; // +1: wall on the model's +x side
    if (!m.hadWall) { m.wallHit = 1; embers(tmpA.set(P.pos.x - P.wall.nx * 0.36, P.pos.y + 0.2, P.pos.z - P.wall.nz * 0.36), 8, 2, 0.35, 4); }
  } else if (m.hadWall && P.vel.y > 6) { m.kick = 1; m.kickSide = m.wallSide; }
  m.hadWall = !!P.wall;
  m.wallHit = Math.max(0, m.wallHit - dtR * 4.5);
  m.kick = P.grounded || P.wall || P.climb ? 0 : Math.max(0, m.kick - dtR * 2.6);
  const push = smooth(m.kick), wallSide = m.wallSide;
  m.land = Math.max(0, m.land - dtR * 2.4);
  const crouch = P.grounded && P.slideT <= 0 ? smooth(Math.min(1, m.land * 1.4)) * Math.min(1, m.land * 3) : 0;

  // gait: cadence rises with speed, stride length does the rest
  const striding = (P.grounded && P.slideT <= 0 && P.diveT <= 0 && !P.surf) || P.wall;
  const run = clamp((hv - 3) / 6, 0, 1);
  m.amp = damp(m.amp, striding ? clamp(hv / 2.5, 0, 1) : 0, 10, dtR);
  if (striding && hv > 0.3) m.phase += dtR * (4.2 + hv * 0.68) * (P.wall ? 1.2 : 1);
  if (P.climb) m.phase += dtR * 14;
  const A = m.amp, ph = m.phase;
  const gl = gaitLeg(ph, A, run), gr = gaitLeg(ph + Math.PI, A, run);
  const idle = P.grounded && P.slideT <= 0 ? 1 - A : 0;
  const breath = Math.sin(G.clock * 1.7), shift = Math.sin(G.clock * 0.45);

  // body lean and offset
  let lx = clamp(vf / 10, -1, 1) * 0.12 + clamp(m.accF / 35, -1, 1) * 0.16 * (P.grounded ? 1 : 0.3);
  let lz = -clamp(vr / 10, -1, 1) * 0.09 - clamp(m.accR / 35, -1, 1) * 0.14 * (P.grounded ? 1 : 0.3);
  let ox = 0, oz = 0;
  let drop = -A * (0.02 + 0.045 * run) * (1 + Math.cos(2 * ph)) / 2 - 0.03 * run * A; // lowest over the planted foot
  lz += -0.035 * A * Math.cos(ph) * (1 - run * 0.6) + 0.025 * idle * shift;             // weight over the stance leg
  drop += 0.006 * breath * idle - 0.3 * crouch;
  lx += 0.42 * crouch;
  if (P.wall) {
    // lean out from the wall with the feet on it, driving forward; bob on each footfall, sink on the plant
    lz = (0.38 + 0.04 * Math.cos(2 * ph)) * wallSide; lx = 0.26 + 0.14 * m.wallHit;
    drop = -0.045 * (1 + Math.cos(2 * ph)) / 2 - 0.12 * m.wallHit;
    ox = -P.wall.nx * 0.27; oz = -P.wall.nz * 0.27;
  }
  if (inAir) lx += P.vel.y > 0 ? -0.06 : 0.08;
  if (push > 0) { lz += 0.45 * m.kickSide * push; lx -= 0.2 * push; } // still tipped out from the push
  // the throw: weight rocks back on the wind-up and drives through onto the lead foot
  const thrW = throwing ? Math.min(1, throwAge / WINDUP) * (1 - smooth(clamp((throwAge - THROW_END + 0.2) / 0.2, 0, 1))) : 0;
  const thrF = throwing ? smooth(clamp((throwAge - WINDUP) / WHIP, 0, 1)) : 0;
  if (throwing) { lx += (-0.08 + 0.24 * thrF) * thrW; drop -= 0.07 * thrW; }
  // the catch knocks the shoulders back a touch
  const caught = catching ? Math.sin(Math.PI * clamp(catchAge / 0.3, 0, 1)) : 0;
  lx -= 0.12 * caught; drop -= 0.04 * caught;
  if (P.slideT > 0) { lx = -0.5; drop = -0.32; }
  if (P.surf) { lx = 0.08; lz = -clamp(vr / 12, -1, 1) * 0.25; drop = -0.12; }
  if (P.climb) { lx = 0.12; lz = 0; ox = -P.climb.nx * 0.12; oz = -P.climb.nz * 0.12; }
  if (swordOut) { lx += 0.2 * lunge + 0.06; drop -= 0.09 * lunge + 0.03; } // lunge into the cut, then a low guard
  let kick = 0; for (const a of m.arms) kick += a.kick;
  lx -= 0.05 * Math.min(1, kick);                  // recoil rocks the shoulders back
  m.off.x = damp(m.off.x, ox, 14, dtR); m.off.z = damp(m.off.z, oz, 14, dtR);
  m.root.position.set(P.pos.x + m.off.x, P.pos.y + (P.surf ? 0.3 : 0), P.pos.z + m.off.z);
  if (P.diveT > 0) {
    // lay out along the dive; a full flip if it started in the air
    const n = Math.hypot(vf, vr) || 1;
    let bx = 1.3 * vf / n;
    if (P.flip) bx += (Math.min(1, P.diveAge / 0.55) * Math.PI * 2) % (Math.PI * 2);
    m.body.rotation.x = bx; m.body.rotation.z = -1.3 * vr / n;
    approach(m.body.position, 'y', 0.55, 16, dtR);
  } else {
    approach(m.body.rotation, 'x', lx, 10, dtR);
    approach(m.body.rotation, 'z', lz, 12, dtR);
    approach(m.body.position, 'y', drop, crouch > 0 ? 22 : 12, dtR);
  }

  // legs
  let hipL = gl.hip, hipR = gr.hip, kneeL = gl.knee, kneeR = gr.knee, toeL = gl.toe, toeR = gr.toe, spread = 0, flat = 1;
  hipR -= 0.05 * idle * (1 + shift); kneeR += 0.1 * idle * (1 + shift);        // resting on one leg, the other relaxed
  hipL -= 0.05 * idle * (1 - shift); kneeL += 0.1 * idle * (1 - shift);
  let zL = 0, zR = 0; // hips rolled toward a wall (positive: foot toward +x)
  if (P.climb) { const sw = Math.sin(ph) * 0.9; hipL = sw - 0.4; hipR = -sw - 0.4; kneeL = 0.9 + 0.5 * Math.sin(ph + 1.6); kneeR = 0.9 - 0.5 * Math.sin(ph + 1.6); }
  if (P.wall) {
    // a sprinter's high knees, each foot pressed flat into the wall through its stance
    const swL = Math.max(0, Math.cos(ph)), swR = Math.max(0, -Math.cos(ph));
    hipL -= 0.35 * swL + 0.1 + 0.3 * m.wallHit; kneeL += 0.35 * swL + 0.15 + 0.5 * m.wallHit;
    hipR -= 0.35 * swR + 0.1 + 0.3 * m.wallHit; kneeR += 0.35 * swR + 0.15 + 0.5 * m.wallHit;
    // the stance leg is the one not swinging; the far leg crosses further to reach the wall
    const reachL = wallSide < 0 ? [0.02, 0.1] : [0.08, 0.28], reachR = wallSide > 0 ? [0.02, 0.1] : [0.08, 0.28];
    zL = wallSide * (reachL[0] + reachL[1] * swR); zR = wallSide * (reachR[0] + reachR[1] * swL);
    flat = 0.4;
  }
  // each footfall kicks up embers where the foot lands: a puff off a wall, a low spray off the ground that grows
  // with speed and falls straight back (kept at the feet so it never reads as him burning)
  const step = Math.floor(ph / Math.PI);
  if (step !== m.step && (P.wall || (striding && P.grounded && hv > 3))) {
    const foot = (step & 1 ? m.legL : m.legR).ankle.getWorldPosition(tmpC);
    if (P.wall) embers(foot, 4, 1.6, 0.3, 3);
    else embers(foot.setY(P.pos.y + 0.05), 1 + Math.round(3 * run), 1.4, 0.28, 6);
  }
  m.step = step;
  if (inAir && P.diveT <= 0) {
    // tuck on the way up, reach for the ground on the way down
    const f = smooth(clamp(0.5 - P.vel.y / 12, 0, 1));
    hipL = -1.05 + 0.6 * f; kneeL = 1.45 - 1.1 * f; hipR = 0.25 - 0.4 * f; kneeR = 0.95 - 0.7 * f;
    toeL = toeR = 0.4 - 0.45 * f; flat = 0;
  }
  if (push > 0 && inAir) {
    // the wall leg still long from the push, the other tucked high
    const pushL = m.kickSide < 0, k = push;
    const mixL = (h, n) => { hipL += (h - hipL) * k; kneeL += (n - kneeL) * k; };
    const mixR = (h, n) => { hipR += (h - hipR) * k; kneeR += (n - kneeR) * k; };
    if (pushL) { mixL(0.4, 0.08); mixR(-1.35, 1.8); zL = -0.35 * k; } else { mixR(0.4, 0.08); mixL(-1.35, 1.8); zR = 0.35 * k; }
  }
  if (crouch > 0) { hipL -= 0.8 * crouch; hipR -= 0.7 * crouch; kneeL += 1.45 * crouch; kneeR += 1.3 * crouch; spread = 0.12 * crouch; }
  if (P.slideT > 0) { hipL = -1.25; hipR = -0.3; kneeL = 0.1; kneeR = 1.4; toeL = 0.3; toeR = 0; flat = 0.5; }
  if (swordOut && P.grounded && A < 0.5) {
    // lead foot steps in, rear leg drives; a settled stance in guard
    hipL = -0.15 - 0.4 * lunge; hipR = 0.12 + 0.28 * lunge; kneeL = 0.3 + 0.3 * lunge; kneeR = 0.25 + 0.15 * lunge; spread = 0.08;
  }
  if (throwing && P.grounded && A < 0.5) {
    // rock onto the rear leg, then step the lead (throwing-side) foot in
    hipR += (-0.15 - 0.4 * thrF - hipR) * thrW; kneeR += (0.2 + 0.3 * thrF - kneeR) * thrW;
    hipL += (0.12 + 0.2 * thrF - hipL) * thrW; kneeL += (0.4 - 0.15 * thrF - kneeL) * thrW; spread = 0.08 * thrW;
  }
  if (P.diveT > 0) { hipL = 0.25; hipR = -0.35; kneeL = 0.5; kneeR = 0.9; toeL = toeR = 0.5; flat = 0; }
  if (P.surf) { hipL = -0.25; hipR = -0.25; kneeL = 0.55; kneeR = 0.55; spread = 0.35; toeL = toeR = 0; }
  const legRate = crouch > 0 ? 24 : 18;
  approach(m.legL.hip.rotation, 'x', hipL, legRate, dtR); approach(m.legR.hip.rotation, 'x', hipR, legRate, dtR);
  approach(m.legL.knee.rotation, 'x', kneeL, legRate, dtR); approach(m.legR.knee.rotation, 'x', kneeR, legRate, dtR);
  approach(m.legL.hip.rotation, 'z', zL - spread, P.wall ? 18 : 12, dtR); approach(m.legR.hip.rotation, 'z', zR + spread, P.wall ? 18 : 12, dtR);
  // ankles keep the sole level with the ground in stance, then point or flex on top of that
  const bodyX = P.diveT > 0 ? 0 : m.body.rotation.x;
  for (const [leg, toe] of [[m.legL, toeL], [m.legR, toeR]]) {
    const level = -(leg.hip.rotation.x + leg.knee.rotation.x + bodyX) * flat;
    approach(leg.ankle.rotation, 'x', clamp(level + toe, -0.7, 1.1), 20, dtR);
  }

  // duster: springs, so it swings, trails on acceleration and lifts as we fall
  const flow = clamp(hv / 12, 0, 1) + (P.grounded ? 0 : 0.3) + (P.wall ? 0.25 : 0) + (P.climb ? 0.5 : 0) + (P.diveT > 0 ? 0.4 : 0);
  const flutter = Math.sin(G.clock * 11) * 0.05 * (0.3 + flow);
  const lift = clamp(-P.vel.y / 30, 0, 0.4) + clamp(m.accF / 60, -0.2, 0.3);
  const lhip = m.legL.hip.rotation.x, rhip = m.legR.hip.rotation.x;
  approach(m.coat.frontNeg.rotation, 'x', Math.min(0, lhip) * 0.9 - 0.04, 14, dtR);
  approach(m.coat.frontPos.rotation, 'x', Math.min(0, rhip) * 0.9 - 0.04, 14, dtR);
  m.coat.backNeg.rotation.x = clamp(spring(m.coatBN, flow * 0.7 + Math.max(0, lhip) * 0.5 + lift + flutter, 70, 6, dtR), -0.3, 1.25);
  m.coat.backPos.rotation.x = clamp(spring(m.coatBP, flow * 0.7 + Math.max(0, rhip) * 0.5 + lift - flutter, 64, 6, dtR), -0.3, 1.25);
  for (const k of ['backNeg', 'backPos']) approach(m.coat[k].rotation, 'z', P.wall ? -wallSide * 0.35 : clamp(m.accR / 80, -0.25, 0.25), 8, dtR);
  // the lower coat lags the upper: hems flare and trail with speed, kick out on the stride, drop as he lands
  bendHem(m.coat.backNeg, clamp(flow * 0.35 + m.coatBN.v * 0.05 + lift * 0.6, -0.15, 0.85), dtR);
  bendHem(m.coat.backPos, clamp(flow * 0.35 + m.coatBP.v * 0.05 + lift * 0.6, -0.15, 0.85), dtR);
  bendHem(m.coat.frontNeg, clamp(-Math.min(0, lhip) * 0.5 + flow * 0.1, 0, 0.6), dtR);
  bendHem(m.coat.frontPos, clamp(-Math.min(0, rhip) * 0.5 + flow * 0.1, 0, 0.6), dtR);

  // arms: swing against the legs, reach when climbing, out for balance in the air, straight when shooting
  const rk = P.reloadT > 0 ? 1 - P.reloadT / T.reloadTime : 0;
  const S = A * (0.32 + 0.48 * run), swing = Math.sin(ph);
  for (let i = 0; i < 2; i++) {
    const a = m.arms[i], side = i ? 1 : -1, fwd = (i ? 1 : -1) * swing; // +1 when this arm is forward
    a.aimT -= dtR; a.flashT -= dtR; a.flash.visible = a.flashT > 0;
    a.kick = Math.max(0, a.kick - dtR * 8);
    let tx = -S * fwd - 0.06 * A, tz = side * (0.1 + 0.05 * run), elbow = -(0.12 + 1.2 * run * A) - 0.35 * A * Math.max(0, fwd);
    let handX = 0, handZ = 0;
    tz += side * 0.015 * breath * idle; elbow -= 0.12 * idle;
    if (inAir) {
      const f = smooth(clamp(0.5 - P.vel.y / 12, 0, 1));
      tx = -0.55 + 0.25 * f; tz = side * (0.35 + 0.6 * f); elbow = -0.9 + 0.45 * f;
    }
    if (crouch > 0) { tx -= 0.35 * crouch; tz += side * 0.35 * crouch; }
    if (P.surf) { tx = -0.2; tz = side * 1.2; elbow = -0.35; }
    if (P.climb) { tx = -2.5 + fwd * 0.7; tz = side * 0.15; elbow = -0.5; }
    if (P.wall && side !== wallSide) { tx = -0.25 - 1.0 * fwd; tz = side * 0.2; elbow = -1.45 + 0.25 * fwd; } // pumping; the wall hand is posed below
    if (push > 0 && inAir) {
      // flung out from the push: the far arm reaches up and on, the wall arm sweeps wide
      const far = side !== m.kickSide, kx = far ? -2.3 : -0.5, kz = side * (far ? 0.45 : 1.5), ke = far ? -0.35 : -0.2;
      tx += (kx - tx) * push; tz += (kz - tz) * push; elbow += (ke - elbow) * push;
    }
    if (throwing && i === 0) {
      // the free hand points the throw in, then pulls back to open the chest
      tx += (-1.25 + 1.6 * thrF - tx) * thrW; tz += (-side * 0.25 + side * 0.75 * thrF - tz) * thrW; elbow += (-0.35 - 0.3 * thrF - elbow) * thrW;
    }
    if (reloading) {
      // bring both guns in front of the chest, tip them open, and fetch rounds from the belt with the left hand
      tx = -0.8; tz = -side * 0.4; elbow = -1.55;
      handZ = side * 1.1 * Math.sin(Math.min(1, rk * 1.25) * Math.PI);
      if (i === 0 && rk > 0.3 && rk < 0.62) { const f = Math.sin((rk - 0.3) / 0.32 * Math.PI); tx = -0.8 + 0.9 * f; tz = -side * 0.4 + side * 0.55 * f; elbow = -1.55 + 1.1 * f; }
    }
    if (a.aimT > 0 || firing()) { tx = -(Math.PI / 2 + P.pitch); tz = 0; elbow = 0; }
    if (swordOut) continue; // both hands are on the sword; posed below
    const aimed = a.aimT > 0 || firing();
    if (i === 1 && (throwing || catching || incoming) || P.wall && side === wallSide && !aimed) continue; // IK, below
    // recoil: the muzzle climbs and the elbow gives, then settles back onto the aim
    const aimRate = a.aimT > 0 ? 30 : 12;
    a.shoulder.rotation.x -= a.kickX || 0; a.elbow.rotation.x -= a.kickE || 0;
    approach(a.shoulder.rotation, 'x', tx, aimRate, dtR);
    approach(a.shoulder.rotation, 'z', tz, 12, dtR);
    approach(a.shoulder.rotation, 'y', 0, 14, dtR);
    approach(a.elbow.rotation, 'x', elbow, aimRate, dtR);
    const kk = a.kick * a.kick;
    a.kickX = -0.32 * kk; a.kickE = -0.4 * kk;
    a.shoulder.rotation.x += a.kickX; a.elbow.rotation.x += a.kickE;
    approach(a.hand.rotation, 'x', handX - 0.55 * kk, 30, dtR);
    approach(a.hand.rotation, 'z', handZ, 14, dtR);
  }
  // torso: shoulders counter-rotate with the arm swing; the cut and the throw twist the whole body through
  let twist = swordOut ? m.sword.twist : -(P.wall ? 0.16 : 0.08) * A * swing * (1 - (aiming ? 1 : 0));
  const tk = throwing ? throwKey(throwAge) : null;
  if (tk) twist = tk.twist * thrW;
  else if (catching) twist = -0.25 * caught; // turning the blade toward its scabbard
  twist -= 0.35 * m.kickSide * push; // turned away from the wall we just left
  if (swordOut || throwing || catching) m.body.rotation.y = damp(m.body.rotation.y, twist, 40, dtR);
  else approach(m.body.rotation, 'y', twist, 20, dtR);
  const SHEATHE = 0.36, drawn = (throwing && throwAge < WINDUP) || (catching && catchAge < SHEATHE);
  m.katana.visible = (swordOut && bladeInHand()) || drawn;
  m.sheathHilt.visible = bladeInHand() && !swordOut && !drawn; // the hilt leaves the scabbard when drawn (or thrown)
  breathe(m, dtR);
  for (let i = 0; i < 2; i++) m.arms[i].gun.visible = !swordOut && !(i === 1 && (throwing || catching));
  if (swordOut) poseSword(m);
  else {
    const arm = m.arms[1];
    if (tk) {
      // the throwing hand follows the throw's keys, raised or lowered with the aim
      const sp = Math.sin(P.pitch);
      tk.hand.y += 0.35 * sp; tk.dir.y += sp; tk.dir.normalize();
      reachToward(arm, tk.hand, 1, throwAge < WINDUP ? 60 : 32, dtR);
      arm.hand.rotation.set(0, 0, throwAge < WINDUP ? 0 : -0.5 * thrF);
      if (throwAge < WINDUP) orientKatana(m, tk.dir, _sv[3].set(tk.dir.z, 0, -tk.dir.x)); // flat, edge leading
    } else if (catching) {
      // meet it out front, give with it, then slide it home over the shoulder
      const c = _pa.grip, k = smooth(clamp((catchAge - CATCH_GIVE) / (SHEATHE - CATCH_GIVE), 0, 1));
      if (catchAge < CATCH_GIVE) c.set(0.22, 1.42, 0.5).lerp(_pb.grip.set(0.2, 1.3, 0.3), smooth(catchAge / CATCH_GIVE));
      else c.set(0.2, 1.3, 0.3).lerp(CATCH_HOME, k);
      if (catchAge < SHEATHE) {
        reachToward(arm, c, 1, 45, dtR); arm.hand.rotation.set(0, 0, 0);
        const d = _pa.dir.set(0.05, 1, 0.35).lerp(_pb.dir.set(0.48, -0.88, -0.05), k).normalize();
        orientKatana(m, d, _pa.edge.set(0, 0, 1).lerp(_pb.edge.set(-0.2, 0, -1), k));
      } else reachToward(arm, _pb.grip.set(0.26, 0.95, 0.06), 1, 14, dtR); // the hand drops back to the side
    } else if (incoming) {
      // the open hand comes up to meet the blade as it nears
      m.root.updateMatrixWorld();
      const t = m.body.worldToLocal(_pa.grip.copy(incoming)), d = t.distanceTo(arm.shoulder.position);
      const w = smooth(clamp((7 - d) / 5, 0, 1));
      t.lerp(_pb.grip.set(0.3, 1.0, 0.2), 1 - w);
      reachToward(arm, t, 1, 22, dtR); arm.hand.rotation.set(-0.4 * w, 0, 0);
    }
    if (P.wall) {
      // the wall hand trails along the wall at hip height, fingers brushing it
      const wa = m.arms[wallSide > 0 ? 1 : 0];
      if (!(wa.aimT > 0 || firing()) && !(wallSide > 0 && (tk || catching || incoming))) {
        m.root.updateMatrixWorld();
        const hv1 = hv || 1, at = 0.12 * Math.sin(ph) - 0.12;
        const t = m.body.worldToLocal(_pa.grip.set(P.pos.x - P.wall.nx * P.r + P.vel.x / hv1 * at, P.pos.y + 1.0 + 0.04 * Math.sin(2 * ph), P.pos.z - P.wall.nz * P.r + P.vel.z / hv1 * at));
        reachToward(wa, t, wallSide, 16, dtR);
        approach(wa.hand.rotation, 'x', -0.3, 14, dtR); approach(wa.hand.rotation, 'z', -wallSide * 0.7, 14, dtR); // palm flat to it
        if (Math.random() < 0.3) embers(wa.hand.getWorldPosition(tmpC), 1, 0.6, 0.2, 2);
      }
    }
  }

  // head: steadied against the body's pitch and roll, glancing toward where the camera looks
  const look = aiming ? 0 : clamp(wrapAngle(P.yaw + Math.PI - m.face), -1, 1) * 0.55;
  approach(m.hood.rotation, 'y', look - m.body.rotation.y * 0.8, 8, dtR);
  approach(m.hood.rotation, 'x', (aiming ? -P.pitch * 0.5 : 0) - clamp(bodyX, -0.8, 0.8) * 0.55 + (reloading ? 0.35 : 0) + 0.015 * breath * idle, 10, dtR);
  approach(m.hood.rotation, 'z', -clamp(m.body.rotation.z, -0.8, 0.8) * (P.wall ? 0.75 : 0.55), 10, dtR);

  // power ring (nothing is emitted from the head: from the chase camera any trail there reads as his hood burning)
  m.ring.visible = G.focusActive || P.powerT > 0;
  m.ring.rotation.y += dtR * (G.focusActive ? 0.6 : 1.6) * (P.powerT > 0 ? 3 : 1);
  HM.rune.opacity = damp(HM.rune.opacity, G.focusActive || P.powerT > 0 ? 1 : 0.45, 6, dtR);
  m.ring.scale.setScalar(damp(m.ring.scale.x, G.focusActive ? 1.35 : 1, 6, dtR));
  // hide when the camera is jammed against us; flicker while invulnerable
  m.root.visible = G.camDist > 0.9 && !(P.invT > 0 && ((G.clock * 18) | 0) % 2 === 0);
  muzzleLight.intensity = damp(muzzleLight.intensity, 0, 30, dtR);
}

/** Standing pose for the title screen: one pistol raised, breathing, the coat stirring. */
export function poseHeroForMenu(pos, dtR) {
  const m = hero, breath = Math.sin(G.clock * 1.5);
  m.root.visible = true; m.root.position.copy(pos); m.root.rotation.y = 0; m.face = 0;
  m.body.rotation.set(0, 0, 0.012 * Math.sin(G.clock * 0.4)); m.body.position.y = 0.005 * breath; m.off.set(0, 0, 0);
  m.katana.visible = false; m.arms[1].gun.visible = true; m.ring.visible = false;
  m.arms[0].shoulder.rotation.set(0.1, 0, -0.12 - 0.015 * breath); m.arms[0].elbow.rotation.x = -0.35;
  m.arms[1].shoulder.rotation.set(-1.25 + Math.sin(G.clock * 1.5) * 0.06, 0, 0.05); m.arms[1].elbow.rotation.x = -0.25;
  for (const a of m.arms) { a.hand.rotation.set(0, 0, 0); a.kick = 0; a.kickX = a.kickE = 0; }
  for (const leg of [m.legL, m.legR]) { leg.hip.rotation.set(0, 0, 0); leg.knee.rotation.x = 0.06; leg.ankle.rotation.x = -0.06; }
  m.legR.hip.rotation.x = -0.05; m.legR.knee.rotation.x = 0.16; m.legR.ankle.rotation.x = -0.11;
  m.legL.hip.rotation.z = -0.06; m.legR.hip.rotation.z = 0.06;
  for (const k of ['frontNeg', 'frontPos']) m.coat[k].rotation.set(-0.04, 0, 0);
  const sway = 0.08 + Math.sin(G.clock * 1.3) * 0.04;
  approach(m.coat.backNeg.rotation, 'x', sway, 4, dtR); approach(m.coat.backPos.rotation, 'x', sway * 0.9, 4, dtR);
  m.coatBN.x = m.coat.backNeg.rotation.x; m.coatBP.x = m.coat.backPos.rotation.x; m.coatBN.v = m.coatBP.v = 0;
  m.hood.rotation.set(0.02 * breath, -0.15 + 0.1 * Math.sin(G.clock * 0.3), 0);
}
