// Props: street lamps, rooftop machinery, plaza furniture and crates. Each builder returns
// [{ geo, mat }] in prop space (ground at y = 0) for the level to place, merge and give collision.
import * as THREE from 'three';
import { M, PM, WM } from './materials.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);
const box = (sx, sy, sz, x, y, z) => new THREE.BoxGeometry(sx, sy, sz).translate(x, y, z);
const cyl = (rt, rb, h, seg, x, y, z) => new THREE.CylinderGeometry(rt, rb, h, seg).translate(x, y, z);

/** Cobra-head street lamp. The arm reaches along +x; LAMP_HEAD is where its light hangs. */
export const LAMP_HEAD = V(1.95, 7.8, 0);
export function streetLamp() {
  const arm = new THREE.QuadraticBezierCurve3(V(0, 7.3, 0), V(0, 8.15, 0), V(1.6, 8.0, 0));
  return [
    { geo: cyl(0.2, 0.25, 0.5, 12, 0, 0.25, 0), mat: PM.pole },
    { geo: cyl(0.06, 0.1, 7.2, 10, 0, 3.85, 0), mat: PM.pole },
    { geo: new THREE.TubeGeometry(arm, 12, 0.05, 6), mat: PM.pole },
    { geo: box(0.95, 0.18, 0.38, 1.95, 7.97, 0), mat: PM.pole },
    { geo: box(0.72, 0.03, 0.26, 1.95, 7.87, 0), mat: PM.lens },
    // warm pool of light on the pavement
    { geo: new THREE.PlaneGeometry(10, 10).rotateX(-Math.PI / 2).translate(1.95, 0.07, 0), mat: PM.pool },
  ];
}

/** Rooftop air-conditioning unit filling a sx × sy × sz footprint. */
export function acUnit(sx, sy, sz) {
  const r = Math.min(sx, sz) * 0.3;
  return [
    { geo: box(sx, sy, sz, 0, sy / 2, 0), mat: PM.steel },
    { geo: box(sx - 0.1, 0.06, sz - 0.1, 0, 0.03, 0), mat: PM.grille },                       // plinth shadow line
    { geo: cyl(r, r, 0.08, 18, 0, sy + 0.03, 0), mat: PM.grille },                             // fan grille
    { geo: new THREE.TorusGeometry(r, 0.03, 6, 24).rotateX(Math.PI / 2).translate(0, sy + 0.07, 0), mat: PM.steel },
    { geo: box(0.03, sy * 0.6, sz * 0.7, sx / 2 + 0.015, sy * 0.45, 0), mat: PM.grille },       // side vent
    { geo: cyl(0.06, 0.06, 0.9, 8, -sx / 2 + 0.2, sy + 0.3, sz / 2 - 0.2), mat: PM.pole },     // pipe stub
  ];
}

/** Octagonal stone fountain basin, 6 m across, rim at 1.2 m, full of dark water. */
export function fountain() {
  return [
    { geo: new THREE.CylinderGeometry(3.05, 3.2, 1.2, 8).rotateY(Math.PI / 8).translate(0, 0.6, 0), mat: PM.stone },
    { geo: new THREE.CylinderGeometry(3.12, 3.12, 0.12, 8).rotateY(Math.PI / 8).translate(0, 1.2, 0), mat: M.cornice }, // coping
    { geo: new THREE.CylinderGeometry(2.75, 2.75, 0.04, 24).translate(0, 1.14, 0), mat: PM.water },
  ];
}

/** Green newsstand, 3 m cube: lit windows all round, a glowing sign band and an overhanging roof. */
export function kiosk() {
  return [
    { geo: box(3, 2.4, 3, 0, 1.2, 0), mat: PM.kiosk },
    { geo: box(3.02, 0.85, 3.02, 0, 1.25, 0), mat: PM.kioskLit },
    { geo: box(3.04, 0.3, 3.04, 0, 2.15, 0), mat: PM.kioskSign },
    { geo: box(3.6, 0.18, 3.6, 0, 2.5, 0), mat: PM.kiosk },
    { geo: new THREE.ConeGeometry(2.4, 0.5, 4).rotateY(Math.PI / 4).translate(0, 2.84, 0), mat: PM.kiosk },
    { geo: box(3.3, 0.08, 3.3, 0, 0.8, 0), mat: PM.kiosk },                                    // counter ledge
    // window frames: mullions on every face
    ...[-1, 0, 1].flatMap(t => [
      { geo: box(0.07, 0.9, 0.07, t, 1.25, 1.52), mat: PM.kiosk }, { geo: box(0.07, 0.9, 0.07, t, 1.25, -1.52), mat: PM.kiosk },
      { geo: box(0.07, 0.9, 0.07, 1.52, 1.25, t), mat: PM.kiosk }, { geo: box(0.07, 0.9, 0.07, -1.52, 1.25, t), mat: PM.kiosk },
    ]),
  ];
}

/** Stone planter with soil and a row of shrubs; length along x. */
export function planter(len, wid = 0.8, h = 1.2) {
  const parts = [
    { geo: box(len, h, wid, 0, h / 2, 0), mat: PM.stone },
    { geo: box(len - 0.2, 0.05, wid - 0.2, 0, h + 0.01, 0), mat: PM.soil },
  ];
  for (let x = -len / 2 + 0.7; x < len / 2 - 0.5; x += 1.3) {
    const r = 0.38 + Math.random() * 0.15;
    parts.push({ geo: new THREE.IcosahedronGeometry(r, 1).scale(1, 0.8, 1).translate(x, h + r * 0.6, 0), mat: PM.bush });
  }
  return parts;
}

/** Concrete stair bulkhead with a steel door on the +z face and a vent pipe. */
export function bulkhead(sx, sy, sz) {
  return [
    { geo: box(sx, sy, sz, 0, sy / 2, 0), mat: PM.concrete },
    { geo: box(sx + 0.2, 0.15, sz + 0.2, 0, sy + 0.07, 0), mat: M.cornice },
    { geo: box(1.0, 2.1, 0.06, 0, 1.05, sz / 2 + 0.03), mat: PM.door },
    { geo: box(0.3, 0.06, 0.08, 0, 2.3, sz / 2 + 0.05), mat: PM.lens },          // lamp over the door
    { geo: cyl(0.1, 0.1, 1.2, 8, sx / 2 - 0.4, sy + 0.6, -sz / 2 + 0.4), mat: PM.pole },
  ];
}

/** Wooden water tower on four steel legs; the tank fills the top of an s × h × s footprint. */
export function waterTower(s, h) {
  const legH = h * 0.45, tankH = h * 0.4, r = s / 2 - 0.1, parts = [];
  for (const [x, z] of [[-r * 0.7, -r * 0.7], [r * 0.7, -r * 0.7], [-r * 0.7, r * 0.7], [r * 0.7, r * 0.7]]) parts.push({ geo: box(0.14, legH, 0.14, x, legH / 2, z), mat: M.iron });
  parts.push({ geo: box(s * 0.9, 0.12, s * 0.9, 0, legH, 0), mat: M.iron });
  parts.push({ geo: cyl(r, r, tankH, 18, 0, legH + tankH / 2, 0), mat: M.tank });
  for (const y of [0.2, 0.5, 0.8]) parts.push({ geo: new THREE.TorusGeometry(r + 0.02, 0.025, 4, 24).rotateX(Math.PI / 2).translate(0, legH + tankH * y, 0), mat: M.iron });
  parts.push({ geo: new THREE.ConeGeometry(r + 0.15, h - legH - tankH, 18).translate(0, legH + tankH + (h - legH - tankH) / 2, 0), mat: M.iron });
  return parts;
}

/** Lattice radio mast with a couple of dishes, h tall. */
export function antennaMast(h) {
  const parts = [], w = 0.35;
  for (const [x, z] of [[-w, -w], [w, -w], [-w, w], [w, w]]) parts.push({ geo: box(0.06, h, 0.06, x * (1 - 0.3), h / 2, z * (1 - 0.3)), mat: PM.pole });
  for (let y = 1; y < h; y += 1.2) {
    parts.push({ geo: box(w * 1.5, 0.04, 0.04, 0, y, -w * 0.7), mat: PM.pole }, { geo: box(w * 1.5, 0.04, 0.04, 0, y, w * 0.7), mat: PM.pole });
    parts.push({ geo: box(0.04, 0.04, w * 1.5, -w * 0.7, y, 0), mat: PM.pole }, { geo: box(0.04, 0.04, w * 1.5, w * 0.7, y, 0), mat: PM.pole });
  }
  for (const [y, rot] of [[h * 0.55, 0.4], [h * 0.75, -1.8]]) {
    parts.push({ geo: new THREE.CylinderGeometry(0.45, 0.1, 0.18, 16).rotateZ(Math.PI / 2).rotateY(rot).translate(Math.cos(rot) * 0.5, y, -Math.sin(rot) * 0.5), mat: PM.steel });
  }
  return parts;
}

// ---- warehouse -----------------------------------------------------------------

/** Steel pallet racking along x: orange uprights, blue beams, three levels of pallets and goods, a mesh back panel. */
export function palletRack(len, h, depth, rnd = Math.random) {
  const parts = [], bays = Math.max(1, Math.round(len / 2.7)), bay = len / bays, d = depth / 2 - 0.05;
  for (let i = 0; i <= bays; i++) {
    const x = -len / 2 + i * bay;
    for (const z of [-d, d]) parts.push({ geo: box(0.1, h, 0.1, x, h / 2, z), mat: WM.upright });
    for (const y of [1.2, 3.4, 5.6]) parts.push({ geo: box(0.05, 0.05, depth - 0.1, x, y, 0), mat: WM.upright });
  }
  parts.push({ geo: box(len, h - 0.4, 0.02, 0, (h - 0.4) / 2 + 0.2, 0), mat: WM.deck });
  const levels = [0.15, 2.35, 4.55], goods = [WM.cardboard, WM.cardboard, WM.wrap, WM.wrapBlue];
  for (const y of levels) {
    for (const z of [-d, d]) parts.push({ geo: box(len, 0.12, 0.08, 0, y, z), mat: WM.beam });
    for (let i = 0; i < bays; i++) for (const k of [-0.62, 0.62]) {
      if (rnd() > 0.72) continue;
      const px = -len / 2 + (i + 0.5) * bay + k, ch = 0.5 + rnd() * 1.3;
      parts.push({ geo: box(1.1, 0.14, depth - 0.15, px, y + 0.13, 0), mat: WM.pallet });
      parts.push({ geo: box(1.0, ch, depth - 0.2, px, y + 0.2 + ch / 2, 0), mat: goods[(rnd() * goods.length) | 0] });
    }
  }
  return parts;
}

/** High-bay lamp hanging from the roof trusses: cable, open shade, glowing lens and a light pool on the floor. */
export const HIGH_BAY_Y = 15.5;
export function highBayLamp() {
  return [
    { geo: box(0.02, 3.4, 0.02, 0, 17.3, 0), mat: WM.steel },
    { geo: new THREE.ConeGeometry(0.55, 0.45, 20, 1, true).translate(0, HIGH_BAY_Y + 0.22, 0), mat: WM.shade },
    { geo: new THREE.CircleGeometry(0.42, 20).rotateX(Math.PI / 2).translate(0, HIGH_BAY_Y, 0), mat: WM.lens },
    { geo: new THREE.PlaneGeometry(14, 14).rotateX(-Math.PI / 2).translate(0, 0.03, 0), mat: PM.pool },
  ];
}

/** Steel roof truss spanning len along z: chords at 19 m and 21.5 m with zig-zag web members. */
export function roofTruss(len) {
  const parts = [{ geo: box(0.18, 0.18, len, 0, 19, 0), mat: WM.steel }, { geo: box(0.18, 0.18, len, 0, 21.5, 0), mat: WM.steel }];
  const step = 3, rise = 2.5, diag = Math.hypot(step, rise), ang = Math.atan2(step, rise);
  for (let z = -len / 2, i = 0; z < len / 2 - 0.1; z += step, i++) {
    parts.push({ geo: box(0.1, rise, 0.1, 0, 19 + rise / 2, z), mat: WM.steel });
    parts.push({ geo: new THREE.BoxGeometry(0.08, diag, 0.08).rotateX(i % 2 ? -ang : ang).translate(0, 19 + rise / 2, z + step / 2), mat: WM.steel });
  }
  return parts;
}

/** Concrete column with a hazard-striped foot, base plate and a steel bracket under the trusses. */
export function column(size, h) {
  return [
    { geo: box(size, h, size, 0, h / 2, 0), mat: PM.concrete },
    { geo: box(size + 0.04, 1.2, size + 0.04, 0, 0.6, 0), mat: WM.hazard },
    { geo: box(size + 0.3, 0.08, size + 0.3, 0, 0.04, 0), mat: WM.steel },
    { geo: box(size + 0.2, 0.4, size + 0.2, 0, 18.7, 0), mat: WM.steel },
  ];
}

/** Raised loading dock: concrete block with hazard-striped edges and rubber bumpers. */
export function loadingDock(sx, sy, sz) {
  const parts = [{ geo: box(sx, sy, sz, 0, sy / 2, 0), mat: PM.concrete }];
  const t = 0.14;
  parts.push({ geo: box(sx + 0.02, t, 0.3, 0, sy - t / 2, sz / 2 - 0.14), mat: WM.hazard }, { geo: box(sx + 0.02, t, 0.3, 0, sy - t / 2, -sz / 2 + 0.14), mat: WM.hazard });
  parts.push({ geo: box(0.3, t, sz + 0.02, sx / 2 - 0.14, sy - t / 2, 0), mat: WM.hazard }, { geo: box(0.3, t, sz + 0.02, -sx / 2 + 0.14, sy - t / 2, 0), mat: WM.hazard });
  for (const x of [-sx / 3, sx / 3]) for (const z of [sz / 2 + 0.1, -sz / 2 - 0.1]) parts.push({ geo: box(0.5, 0.6, 0.2, x, sy - 0.8, z), mat: WM.rubber });
  return parts;
}

/** Concrete step block with a painted nosing. */
export function stepBlock(sx, sy, sz) {
  return [
    { geo: box(sx, sy, sz, 0, sy / 2, 0), mat: PM.concrete },
    { geo: box(sx + 0.02, 0.1, 0.25, 0, sy - 0.05, sz / 2 - 0.12), mat: WM.safety },
    { geo: box(sx + 0.02, 0.1, 0.25, 0, sy - 0.05, -sz / 2 + 0.12), mat: WM.safety },
  ];
}

/** Prefab site office: panel walls, a lit ribbon of windows with mullions, a door on +z and a steel roof edge. */
export function siteOffice(sx, sy, sz) {
  const parts = [
    { geo: box(sx, 1.1, sz, 0, 0.55, 0), mat: WM.office },
    { geo: box(sx + 0.02, 2.2, sz + 0.02, 0, 2.2, 0), mat: WM.officeLit },
    { geo: box(sx, sy - 3.3, sz, 0, 3.3 + (sy - 3.3) / 2, 0), mat: WM.office },
    { geo: box(sx + 0.3, 0.16, sz + 0.3, 0, sy + 0.08, 0), mat: WM.steel },
    { geo: box(1.1, 2.3, 0.06, sx * 0.3, 1.15, sz / 2 + 0.04), mat: WM.steel },
  ];
  for (let t = -sx / 2 + 1.25; t < sx / 2; t += 1.25) {
    parts.push({ geo: box(0.08, 2.2, 0.08, t, 2.2, sz / 2 + 0.03), mat: WM.steel }, { geo: box(0.08, 2.2, 0.08, t, 2.2, -sz / 2 - 0.03), mat: WM.steel });
    parts.push({ geo: box(0.08, 2.2, 0.08, sx / 2 + 0.03, 2.2, t), mat: WM.steel }, { geo: box(0.08, 2.2, 0.08, -sx / 2 - 0.03, 2.2, t), mat: WM.steel });
  }
  return parts;
}

/** A wooden crate on a pallet, filling a 2.2 × 1.3 × 2.2 footprint. */
export function palletCrate() {
  return [
    { geo: box(2.1, 0.14, 2.1, 0, 0.07, 0), mat: WM.pallet },
    { geo: box(2.0, 1.16, 2.0, 0, 0.72, 0), mat: PM.crate },
  ];
}

/** A cluster of steel oil drums in a cols × rows grid (0.62 m spacing). */
export function drumCluster(cols, rows, rnd = Math.random) {
  const parts = [];
  for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
    const x = (i - (cols - 1) / 2) * 0.62, z = (j - (rows - 1) / 2) * 0.62, mat = WM.drums[(rnd() * WM.drums.length) | 0];
    parts.push({ geo: cyl(0.29, 0.29, 0.88, 16, x, 0.44, z), mat });
    for (const y of [0.3, 0.6]) parts.push({ geo: new THREE.TorusGeometry(0.295, 0.015, 4, 16).rotateX(Math.PI / 2).translate(x, y, z), mat: WM.steel });
  }
  return parts;
}

// ---- rooftops -------------------------------------------------------------------

/**
 * Billboard structure around a w × h sign whose face is at z = 0 (bottom edge at y = 0):
 * steel frame, a catwalk with railing on the +z side, lamp arms lighting the face, and two
 * support columns running `drop` metres down behind it.
 */
export function billboardFrame(w, h, depth, drop) {
  const f = 0.12, back = -depth / 2 - 0.15, parts = [
    { geo: box(w + f * 2, f, depth + 0.1, 0, h + f / 2, 0), mat: M.iron },
    { geo: box(w + f * 2, f, depth + 0.1, 0, -f / 2, 0), mat: M.iron },
    { geo: box(f, h, depth + 0.1, -w / 2 - f / 2, h / 2, 0), mat: M.iron },
    { geo: box(f, h, depth + 0.1, w / 2 + f / 2, h / 2, 0), mat: M.iron },
    // catwalk and railing
    { geo: box(w, 0.06, 0.8, 0, -0.18, depth / 2 + 0.45), mat: PM.grille },
    { geo: box(w, 0.04, 0.04, 0, 0.8, depth / 2 + 0.83), mat: M.iron },
  ];
  for (let x = -w / 2; x <= w / 2 + 0.01; x += w / 4) parts.push({ geo: box(0.04, 1, 0.04, x, 0.32, depth / 2 + 0.83), mat: M.iron });
  // lamp arms reaching out and angled back at the sign
  for (const x of [-w / 3, 0, w / 3]) {
    parts.push({ geo: box(0.05, 0.05, 1.3, x, -0.1, depth / 2 + 0.95), mat: M.iron });
    parts.push({ geo: box(0.35, 0.2, 0.25, x, -0.02, depth / 2 + 1.55), mat: PM.pole });
    parts.push({ geo: box(0.3, 0.02, 0.2, x, 0.09, depth / 2 + 1.55), mat: PM.lens });
  }
  // support columns and cross braces down into the gap
  for (const x of [-w / 3, w / 3]) {
    parts.push({ geo: box(0.35, drop, 0.35, x, -drop / 2, back), mat: M.iron });
    for (let y = -3; y > -drop; y -= 4) parts.push({ geo: box(w * 2 / 3, 0.1, 0.1, 0, y, back), mat: M.iron });
  }
  return parts;
}

/** Rusted steel I-beam along x, with a walkway grating on top as wide as its footprint. */
export function girder(len, h, wid) {
  return [
    { geo: box(len, 0.05, 0.34, 0, h - 0.025, 0), mat: M.iron },
    { geo: box(len, 0.05, 0.34, 0, 0.025, 0), mat: M.iron },
    { geo: box(len, h - 0.1, 0.05, 0, h / 2, 0), mat: M.iron },
    { geo: box(len, 0.03, wid, 0, h + 0.015, 0), mat: PM.grille },
  ];
}

/** A short roof light: pole, head and a lens pointing down, with a pool of light at its foot. */
export const ROOF_LIGHT_Y = 3.1;
export function roofLight() {
  return [
    { geo: box(0.4, 0.2, 0.4, 0, 0.1, 0), mat: M.iron },
    { geo: cyl(0.05, 0.07, 3.2, 8, 0, 1.6, 0), mat: PM.pole },
    { geo: box(0.5, 0.18, 0.5, 0, 3.25, 0), mat: PM.pole },
    { geo: box(0.4, 0.02, 0.4, 0, 3.15, 0), mat: PM.lens },
    { geo: new THREE.PlaneGeometry(9, 9).rotateX(-Math.PI / 2).translate(0, 0.05, 0), mat: PM.pool },
  ];
}

/** Scenery for a flat roof of w × d: vent stacks, a skylight and a duct run. Decor only, so it never blocks movement. */
export function roofClutter(w, d, rnd = Math.random) {
  const parts = [], sx = w / 2 - 1.2, sz = d / 2 - 1.2;
  const spot = () => [(rnd() * 2 - 1) * sx, (rnd() * 2 - 1) * sz];
  for (let i = 0, n = 2 + ((rnd() * 3) | 0); i < n; i++) {
    const [x, z] = spot(), r = 0.1 + rnd() * 0.15, h = 0.6 + rnd() * 0.8;
    parts.push({ geo: cyl(r, r, h, 10, x, h / 2, z), mat: PM.steel });
    parts.push({ geo: new THREE.ConeGeometry(r * 1.7, 0.2, 10).translate(x, h + 0.14, z), mat: PM.steel });
  }
  if (w > 6 && d > 6 && rnd() < 0.7) {
    const [x, z] = spot();
    parts.push({ geo: box(2, 0.35, 1.3, x, 0.175, z), mat: M.iron });
    parts.push({ geo: new THREE.BoxGeometry(1.8, 0.1, 1.1).rotateX(0.12).translate(x, 0.42, z), mat: PM.water });
  }
  if (rnd() < 0.6) {
    const alongX = rnd() < 0.5, len = (alongX ? w : d) * (0.3 + rnd() * 0.4), [x, z] = spot();
    parts.push({ geo: box(alongX ? len : 0.5, 0.5, alongX ? 0.5 : len, x, 0.4, z), mat: PM.steel });
    parts.push({ geo: box(0.1, 0.2, 0.1, x, 0.1, z), mat: M.iron });
  }
  return parts;
}
