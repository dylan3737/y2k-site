// Stage events: shared pieces the maps use (timers, a ground warning marker, falling bodies, rain, lightning).
// Everything here runs on world time and is wiped whenever a stage loads.
import * as THREE from 'three';
import { camera } from './engine.js';
import { V3, rand } from './util.js';
import { addFx, ownMat, shockRing, embers } from './fx.js';
import { sfx, setRain } from './audio.js';
import { G, P, world } from './state.js';
import { level } from './physics.js';
import { isLive } from './soldiers.js';
import { damageSoldier } from './combat.js';
import { hurtPlayer } from './player.js';
import { rumble } from './rumble.js';

let timers = [], fallers = [], rain = null;

/** Run fn after t seconds of world time (cancelled if the stage changes). */
export function after(t, fn) { timers.push({ t, fn }); }

/** Drop a mesh under gravity until its bottom reaches y (mesh origin at its bottom), then call onLand. */
export function dropBody(mesh, y, onLand) { fallers.push({ mesh, y, v: 0, onLand }); }

export function updateEvents(dt) {
  for (let i = timers.length - 1; i >= 0; i--) {
    const tm = timers[i]; tm.t -= dt;
    if (tm.t <= 0) { timers.splice(i, 1); tm.fn(); }
  }
  for (let i = fallers.length - 1; i >= 0; i--) {
    const f = fallers[i];
    f.v += 30 * dt; f.mesh.position.y -= f.v * dt;
    if (f.mesh.position.y <= f.y) { f.mesh.position.y = f.y; fallers.splice(i, 1); if (f.onLand) f.onLand(); }
  }
  if (rain) rain.update(dt);
}
export function resetEvents() {
  timers = []; fallers = [];
  if (rain) { rain.stop(); rain = null; }
  setRain(0);
}

// ---- a pulsing ring on the ground where something is about to land
const ringGeo = new THREE.RingGeometry(0.86, 1, 40); ringGeo.rotateX(-Math.PI / 2);
const discGeo = new THREE.CircleGeometry(1, 40); discGeo.rotateX(-Math.PI / 2);
export function warnMarker(x, y, z, radius, dur, color = [3, 0.4, 0.1]) {
  const g = new THREE.Group(); g.position.set(x, y + 0.04, z); g.scale.setScalar(radius);
  const add = { transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, color: new THREE.Color(...color) };
  const ring = new THREE.Mesh(ringGeo, ownMat(THREE.MeshBasicMaterial, { ...add }));
  const disc = new THREE.Mesh(discGeo, ownMat(THREE.MeshBasicMaterial, { ...add, opacity: 0.15 }));
  g.add(ring, disc);
  addFx(g, dur, (o, k) => {
    const beat = 0.5 + 0.5 * Math.sin(k * dur * (6 + k * 18)); // pulses faster as it closes
    ring.material.opacity = 0.5 + 0.5 * beat;
    disc.material.opacity = 0.08 + 0.22 * k;
    disc.scale.setScalar(k);
  });
}
/** Height of the first surface below (x, z), looking down from `from`. */
export function surfaceY(x, z, from = 60) {
  let top = level.floorY > -1e8 ? level.floorY : -1e9;
  for (const b of level.boxes) if (x > b.min.x && x < b.max.x && z > b.min.z && z < b.max.z && b.max.y <= from && b.max.y > top) top = b.max.y;
  return top;
}

// ---- rain: streaks that fall around the camera
export function startRain(group, count = 1400) {
  if (rain) return rain;
  const pos = new Float32Array(count * 6), drops = [];
  for (let i = 0; i < count; i++) drops.push([rand(-30, 30), rand(-4, 26), rand(-30, 30), rand(0.6, 1.2)]);
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const mat = new THREE.LineBasicMaterial({ color: new THREE.Color(0.55, 0.62, 0.75), transparent: true, opacity: 0.35, depthWrite: false });
  const lines = new THREE.LineSegments(geo, mat); lines.frustumCulled = false; group.add(lines);
  let fade = 0, on = true;
  rain = {
    stop() { on = false; },
    update(dt) {
      fade = Math.min(1, Math.max(0, fade + (on ? dt : -dt) * 0.5));
      mat.opacity = 0.35 * fade; setRain(0.3 * fade);
      if (!on && fade <= 0) { group.remove(lines); geo.dispose(); mat.dispose(); rain = null; return; }
      const c = camera.position;
      for (let i = 0; i < count; i++) {
        const d = drops[i];
        d[1] -= 26 * d[3] * dt; d[0] += 3 * dt;
        if (d[1] < -4) { d[1] += 30; d[0] = rand(-30, 30); d[2] = rand(-30, 30); }
        const x = ((d[0] + 30) % 60) - 30 + c.x, y = d[1] + c.y, z = d[2] + c.z;
        pos.set([x, y, z, x - 0.15, y + 0.9 * d[3], z], i * 6);
      }
      geo.attributes.position.needsUpdate = true;
    },
  };
  return rain;
}
export const raining = () => !!rain;

// ---- lightning: marked, then a bolt that kills soldiers and hurts the player nearby
const boltGeo = new THREE.BoxGeometry(0.5, 70, 0.5); boltGeo.translate(0, 35, 0);
export function lightning(x, z, fromY = 0, warn = 1.1) {
  const y = surfaceY(x, z, fromY + 0.5); // the ground at the target's own level, not a roof above them
  warnMarker(x, y, z, 3.2, warn, [2.4, 2.2, 3]);
  sfx.crackle();
  after(warn, () => {
    const bolt = new THREE.Mesh(boltGeo, ownMat(THREE.MeshBasicMaterial, { color: new THREE.Color(4, 4, 5), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
    bolt.position.set(x, y, z);
    addFx(bolt, 0.28, (o, k) => { o.material.opacity = (1 - k) * (k < 0.3 && Math.random() < 0.5 ? 0.3 : 1); o.scale.x = o.scale.z = 1 + k * 2; });
    shockRing(new V3(x, y, z), [2.4, 2.4, 3], 3.2, 0.35);
    embers(new V3(x, y + 0.3, z), 30, 6, 0.4, 5);
    G.flash = Math.max(G.flash, 0.55); G.shake = Math.max(G.shake, 0.5);
    after(0.12, () => sfx.thunder());
    rumble(0.3, 0.5, 180);
    for (const s of world.soldiers) {
      if (!isLive(s) || Math.hypot(s.pos.x - x, s.pos.z - z) > 3.2 || Math.abs(s.pos.y - y) > 2) continue;
      s.knock.set((s.pos.x - x) * 2, 7, (s.pos.z - z) * 2);
      damageSoldier(s, s.boss ? 250 : 999, false, new V3(0, -1, 0), ['LIGHTNING']);
    }
    const d = Math.hypot(P.pos.x - x, P.pos.z - z);
    if (G.mode === 'play' && d < 3.2 && Math.abs(P.pos.y - y) < 2 && P.invT <= 0) {
      hurtPlayer(25); P.vel.set((P.pos.x - x) / (d || 1) * 7, 7, (P.pos.z - z) / (d || 1) * 7);
    }
  });
}
