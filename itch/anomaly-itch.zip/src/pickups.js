// Drops: health, focus, power-ups, Hellfire charges and extra lives.
import * as THREE from 'three';
import { scene } from './engine.js';
import { V3, rand, tmpA } from './util.js';
import { level, moveBody } from './physics.js';
import { sparks } from './fx.js';
import { sfx } from './audio.js';
import { T, PICKUPS, DROP_TABLE, DROP_CHANCE } from './config.js';
import { G, P, world } from './state.js';
import { popup } from './ui.js';
import { addScore } from './game.js';

const coreGeo = new THREE.OctahedronGeometry(0.24), shellGeo = new THREE.OctahedronGeometry(0.42);
const mats = {};
for (const [type, info] of Object.entries(PICKUPS)) {
  const c = new THREE.Color(...info.color);
  mats[type] = [new THREE.MeshBasicMaterial({ color: c }), new THREE.MeshBasicMaterial({ color: c.clone().multiplyScalar(0.5), wireframe: true, transparent: true, opacity: 0.8 })];
}

export function dropPickup(p, type) {
  const g = new THREE.Group();
  const core = new THREE.Mesh(coreGeo, mats[type][0]), shell = new THREE.Mesh(shellGeo, mats[type][1]);
  g.add(core, shell); scene.add(g);
  world.pickups.push({ g, core, shell, type, t: 0, pos: new V3(p.x, p.y + 1, p.z), vel: new V3(rand(-2.5, 2.5), 6, rand(-2.5, 2.5)), r: 0.2, h: 0.4 });
}
export function rollDrop(p) {
  if (Math.random() > DROP_CHANCE) return;
  let r = Math.random() * DROP_TABLE.reduce((sum, [, w]) => sum + w, 0);
  for (const [type, w] of DROP_TABLE) if ((r -= w) <= 0) { dropPickup(p, type); return; }
}
export function clearPickups() { for (const k of world.pickups) scene.remove(k.g); world.pickups = []; }

/** Bounce, get pulled toward the player when close, blink out after a while. */
export function updatePickups(dtWorld, dtReal) {
  const list = world.pickups;
  for (let i = list.length - 1; i >= 0; i--) {
    const k = list[i]; k.t += dtWorld;
    const cx = P.pos.x - k.pos.x, cy = (P.pos.y + 0.9) - (k.pos.y + 0.45), cz = P.pos.z - k.pos.z;
    const d = Math.hypot(cx, cy, cz) || 1;
    const remove = () => { scene.remove(k.g); list.splice(i, 1); };
    if (G.mode === 'play' && d < 1.3) { collect(k); remove(); continue; }
    if (G.mode === 'play' && d < 5 && k.t > 0.35) {
      const step = Math.min(d, 14 * dtReal);
      k.pos.x += cx / d * step; k.pos.y += cy / d * step; k.pos.z += cz / d * step;
    } else {
      k.vel.y -= 20 * dtWorld;
      if (moveBody(k, dtWorld)) { k.vel.x *= 0.85; k.vel.z *= 0.85; }
    }
    if (k.t > 15 || k.pos.y < level.info.killY) { remove(); continue; }
    k.g.visible = k.t < 11.5 || ((k.t * 10) | 0) % 2 === 0;
    k.g.position.set(k.pos.x, k.pos.y + 0.45 + Math.sin(k.t * 4) * 0.1, k.pos.z);
    k.core.rotation.y += dtReal * 3; k.shell.rotation.y -= dtReal * 1.5; k.shell.rotation.x += dtReal;
  }
}

function collect(k) {
  const info = PICKUPS[k.type];
  switch (k.type) {
    case 'health': P.hp = Math.min(100, P.hp + 40); break;
    case 'focus': P.focus = Math.min(100, P.focus + 50); break;
    case 'hellfire': G.hellfire = Math.min(5, G.hellfire + 1); break;
    case 'life': G.lives = Math.min(6, G.lives + 1); sfx.oneUp(); break;
    default: P.power = k.type; P.powerT = 12; P.reloadT = 0; P.ammo = T.magSize; // rapid / spread / pierce
  }
  popup(tmpA.set(k.pos.x, k.pos.y + 1.3, k.pos.z), info.label, info.cls);
  sparks.emit(k.g.position, 30, 4, info.color[0], info.color[1], info.color[2], 0.5, 0);
  addScore(50);
  sfx.pickup();
}
