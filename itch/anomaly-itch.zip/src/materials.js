// Every shared material, grouped by what uses it.
import * as THREE from 'three';
import { neonTexs, facades, storefront, roofTex, asphaltTex, sidewalkTex, crateTex, dotTex,
  corrugatedTex, concreteFloorTex, blockTex, hazardTex, normalFor, leatherNormal, weaveNormal, puddleRough } from './textures.js';

const std = opts => new THREE.MeshStandardMaterial(opts);
const glow = (r, g, b, opts = {}) => new THREE.MeshBasicMaterial({ color: new THREE.Color(r, g, b), ...opts });

// ---- world
export const M = {
  asphalt: std({ map: asphaltTex, roughness: 0.92 }),
  sidewalk: std({ map: sidewalkTex, roughness: 0.85 }),
  lane: std({ color: 0xb8a57a, roughness: 0.8 }),
  roof: std({ map: roofTex, roughness: 0.95 }),
  cornice: std({ color: 0x8c847a, roughness: 0.8 }),
  iron: std({ color: 0x2f2724, roughness: 0.6, metalness: 0.6 }),
  tank: std({ color: 0x5a4636, roughness: 0.9 }),
  awning: std({ color: 0x6e1a14, roughness: 0.8, side: THREE.DoubleSide }),
  edge: new THREE.LineBasicMaterial({ color: new THREE.Color(1.4, 0.45, 0.12), transparent: true, opacity: 0.18 }),
  beacon: glow(4, 0.25, 0.2),
};
/** Building box material arrays by facade style: facade on the four sides, gravel roof on top. */
export const FACADE = {};
for (const [style, tex] of Object.entries(facades)) {
  const glass = style === 'glass';
  const side = std({ map: tex.map, emissive: 0xffffff, emissiveMap: tex.emissiveMap, emissiveIntensity: 1.1, roughness: glass ? 0.35 : 0.85, metalness: glass ? 0.4 : 0.05 });
  FACADE[style] = [side, side, M.roof, M.roof, side, side];
}
export const FACADE_STYLES = Object.keys(FACADE);
// shop fronts: the texture is 24 m wide per tile but only spans the 3.6 m band vertically
for (const t of [storefront.map, storefront.emissiveMap]) t.repeat.set(1, 24 / 3.6);
M.storefront = std({ map: storefront.map, emissive: 0xffffff, emissiveMap: storefront.emissiveMap, emissiveIntensity: 1.2, roughness: 0.5 });
/** Cars: clear-coated paint in real-world colours, tinted glass, rubber, alloy, plastic and lights. */
export const CAR = {
  paints: [0x6e0f0c, 0x0e0f11, 0x8a8d90, 0xcfcac2, 0x1a2640, 0xc99a1a, 0x1f3a2c, 0x3a3d40]
    .map(c => new THREE.MeshPhysicalMaterial({ color: c, roughness: 0.32, metalness: 0.55, clearcoat: 1, clearcoatRoughness: 0.08 })),
  glass: std({ color: 0x0a0d10, roughness: 0.05, metalness: 0.9, side: THREE.DoubleSide }),
  tire: std({ color: 0x121212, roughness: 0.92 }),
  rim: std({ color: 0x9a9c9e, roughness: 0.3, metalness: 1 }),
  plastic: std({ color: 0x141414, roughness: 0.7 }),
  headOn: glow(3.2, 3, 2.4), headOff: std({ color: 0xb8bcc0, roughness: 0.15, metalness: 0.6 }),
  tailOn: glow(2.6, 0.12, 0.06), tailOff: std({ color: 0x4a0806, roughness: 0.3 }),
};
/** Neon billboards; their intensity flickers every frame. */
export const neonMats = neonTexs.map(t => std({ color: 0x0b0706, emissive: 0xffffff, emissiveMap: t, emissiveIntensity: 1.2, roughness: 0.6 }));

/** Props: street furniture, rooftop machinery, crates. */
export const PM = {
  pole: std({ color: 0x2b2d2e, roughness: 0.45, metalness: 0.7 }),
  lens: glow(2.1, 1.5, 0.85), // bright enough to bloom, not to white out the frame
  pool: new THREE.MeshBasicMaterial({ map: dotTex, color: new THREE.Color(0.55, 0.32, 0.14), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }),
  steel: std({ color: 0x8f9396, roughness: 0.5, metalness: 0.5 }),
  grille: std({ color: 0x1a1b1c, roughness: 0.8, metalness: 0.3 }),
  stone: std({ color: 0x8a847c, roughness: 0.9 }),
  water: std({ color: 0x0c1a1e, roughness: 0.04, metalness: 0.7 }),
  soil: std({ color: 0x2a1d14, roughness: 1 }),
  bush: std({ color: 0x24341c, roughness: 0.95 }),
  kiosk: std({ color: 0x2d4a36, roughness: 0.5, metalness: 0.3 }),
  kioskLit: glow(0.75, 0.52, 0.28),
  kioskSign: glow(1.2, 0.36, 0.12),
  concrete: std({ color: 0x7a746c, roughness: 0.9 }),
  door: std({ color: 0x3a3230, roughness: 0.5, metalness: 0.5 }),
  crate: std({ map: crateTex, roughness: 0.85 }),
};

/** Warehouse interior. */
export const WM = {
  cladding: std({ map: corrugatedTex, roughness: 0.55, metalness: 0.6 }),
  roofDeck: std({ map: corrugatedTex, color: 0x5a5a5a, roughness: 0.7, metalness: 0.5, side: THREE.DoubleSide }),
  floor: std({ map: concreteFloorTex, roughness: 0.38, metalness: 0.1 }),
  block: std({ map: blockTex, roughness: 0.9 }),
  hazard: std({ map: hazardTex, roughness: 0.7 }),
  safety: std({ color: 0xd9a91a, roughness: 0.6 }),
  clerestory: std({ color: 0x0d1216, roughness: 0.1, metalness: 0.6, emissive: 0x1a2a3c, emissiveIntensity: 0.6 }),
  steel: std({ color: 0x3a3c3e, roughness: 0.5, metalness: 0.7 }),
  upright: std({ color: 0xc2541a, roughness: 0.55, metalness: 0.4 }),
  beam: std({ color: 0x1f4f9a, roughness: 0.5, metalness: 0.4 }),
  deck: std({ color: 0x2c2c2c, roughness: 0.7, metalness: 0.5 }),
  cardboard: std({ color: 0x9c7a4f, roughness: 0.95 }),
  wrap: std({ color: 0xd4d2cc, roughness: 0.35 }),
  wrapBlue: std({ color: 0x2e5d8a, roughness: 0.4 }),
  pallet: std({ color: 0x8a6a45, roughness: 0.95 }),
  rubber: std({ color: 0x121212, roughness: 0.9 }),
  shade: std({ color: 0x2f3133, roughness: 0.4, metalness: 0.8, side: THREE.DoubleSide }),
  lens: glow(3.2, 2.5, 1.5),
  drums: [0x1f4f9a, 0x8a1c14, 0xd9a91a, 0x2f5a32].map(c => std({ color: c, roughness: 0.45, metalness: 0.5 })),
  office: std({ color: 0xc8c2b6, roughness: 0.7 }),
  officeLit: glow(0.9, 0.85, 0.72),
};

// ---- soldiers
export const SM = {
  fatigue: std({ color: 0x4a4c40, roughness: 0.9 }),
  vest: std({ color: 0x2a2c28, roughness: 0.7, metalness: 0.1 }),
  pad: std({ color: 0x0f100f, roughness: 0.6 }),
  helmet: std({ color: 0x3c4034, roughness: 0.55, metalness: 0.25 }),
  balaclava: std({ color: 0x0d0d0d, roughness: 0.95 }),
  visor: std({ color: 0x000000, roughness: 0.05, metalness: 1, emissive: 0xff3010, emissiveIntensity: 3 }),
  bossVisor: std({ color: 0x000000, roughness: 0.05, metalness: 1, emissive: 0xff1a00, emissiveIntensity: 3 }),
  bossPlate: std({ color: 0x2c2620, roughness: 0.4, metalness: 0.6 }),
};
export const gunMat = std({ color: 0x1b1d1d, roughness: 0.35, metalness: 0.85 });
export const bootMat = std({ color: 0x030303, roughness: 0.2, metalness: 0.3 });

// ---- the hero
export const HM = {
  coat: std({ color: 0x3a2c26, roughness: 0.55, metalness: 0.12, side: THREE.DoubleSide }),   // oiled leather duster
  trousers: std({ color: 0x24201e, roughness: 0.85 }),
  trim: std({ color: 0x140804, emissive: 0xff5a14, emissiveIntensity: 1.5 }),
  void: new THREE.MeshBasicMaterial({ color: 0x000000 }),
  eye: glow(4, 1.5, 0.3),
  glove: std({ color: 0x1e1512, roughness: 0.4, metalness: 0.2 }),
  rune: glow(3, 1.1, 0.25, { transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false }),
  blade: std({ color: 0x9fb3aa, roughness: 0.15, metalness: 1 }),
  bladeEdge: glow(3.6, 1.5, 0.45),
  leather: std({ color: 0x2a1a12, roughness: 0.45, metalness: 0.08 }),  // straps, belt, holster
  buckle: std({ color: 0x8a7a5a, roughness: 0.3, metalness: 0.9 }),
  wrap: std({ color: 0x15100e, roughness: 0.95 }),                    // the cloth over the lower face
  shirt: std({ color: 0x120c0a, roughness: 0.8 }),
  sole: std({ color: 0x0c0a09, roughness: 0.9 }),
};

// ---- character readability: a fresnel rim glow and a back-face outline
/** Adds a view-angle rim light to a standard material, so silhouettes glow at their edges. */
function withRim(mat, r, g, b, power = 2.2) {
  const rim = { value: new THREE.Color(r, g, b) };
  mat.onBeforeCompile = shader => {
    shader.uniforms.uRim = rim;
    shader.fragmentShader = 'uniform vec3 uRim;\n' + shader.fragmentShader.replace('#include <opaque_fragment>',
      `float rimF = 1.0 - clamp(abs(dot(normal, normalize(vViewPosition))), 0.0, 1.0);
      outgoingLight += uRim * pow(rimF, ${power.toFixed(1)});
      #include <opaque_fragment>`);
  };
  mat.customProgramCacheKey = () => 'rim' + power;
  return mat;
}
/** Same leather, single-sided, for closed shapes (chest, arms) so they get an outline too. */
HM.coatSolid = std({ color: 0x3a2c26, roughness: 0.55, metalness: 0.12 });
for (const m of [HM.coat, HM.coatSolid, HM.trousers, HM.glove, HM.leather, HM.wrap]) withRim(m, 0.34, 0.13, 0.04, 3);
Object.assign(SM, {
  rusherVest: std({ color: 0x5a2016, roughness: 0.75, metalness: 0.05 }),
  rusherVisor: std({ color: 0x000000, roughness: 0.05, metalness: 1, emissive: 0xffb000, emissiveIntensity: 3 }),
  sniperVest: std({ color: 0x3b3a2c, roughness: 0.95 }),
  sniperVisor: std({ color: 0x000000, roughness: 0.05, metalness: 1, emissive: 0x38c8ff, emissiveIntensity: 3 }),
  riotVest: std({ color: 0x1c2026, roughness: 0.5, metalness: 0.3 }),
  riotVisor: std({ color: 0x000000, roughness: 0.05, metalness: 1, emissive: 0xfff2d8, emissiveIntensity: 2 }),
  shield: std({ color: 0x1a1e24, roughness: 0.3, metalness: 0.5 }),
  shieldGlass: new THREE.MeshStandardMaterial({ color: 0x8aa0b8, roughness: 0.1, metalness: 0.2, transparent: true, opacity: 0.35, depthWrite: false }),
  shieldStripe: std({ color: 0x111111, emissive: 0xff7a1a, emissiveIntensity: 1.4 }),
});
for (const m of [SM.fatigue, SM.vest, SM.helmet, SM.pad, SM.bossPlate, SM.rusherVest, SM.sniperVest, SM.riotVest, SM.shield]) withRim(m, 0.32, 0.05, 0.02, 3);

const outline = (r, g, b) => new THREE.MeshBasicMaterial({ color: new THREE.Color(r, g, b), side: THREE.BackSide, fog: false });
export const outlineMat = { hero: outline(0.95, 0.38, 0.1), soldier: outline(0.62, 0.05, 0.025) };

/** Give every closed, lit mesh under root a slightly larger back-face shell in a solid colour. */
export function addOutline(root, mat, thickness = 0.02) {
  const targets = [];
  root.traverse(o => {
    if (o.isMesh && !o.userData.noOutline && !o.material.isMeshBasicMaterial && o.material.side !== THREE.DoubleSide) targets.push(o);
  });
  const size = new THREE.Vector3(), centre = new THREE.Vector3();
  for (const m of targets) {
    m.geometry.computeBoundingBox();
    m.geometry.boundingBox.getSize(size); m.geometry.boundingBox.getCenter(centre);
    // tiny parts (buckles, pouches, knuckles): an outline and a shadow there are invisible but cost a draw each
    if (Math.max(size.x, size.y, size.z) < 0.12) { m.castShadow = false; continue; }
    const shell = new THREE.Mesh(m.geometry, mat);
    for (const ax of ['x', 'y', 'z']) {
      const t = Math.min(thickness, size[ax] * 0.3);
      shell.scale[ax] = 1 + (2 * t) / Math.max(size[ax], 1e-3);
      shell.position[ax] = centre[ax] * (1 - shell.scale[ax]); // grow about the geometry's centre
    }
    m.add(shell);
  }
}

// Ground overlays (paving, road paint, lamp pools) sit a centimetre or two above the floor. Pull each layer
// forward in depth so they never shimmer or flicker against the ground at a distance.
const groundLayer = (m, n) => Object.assign(m, { polygonOffset: true, polygonOffsetFactor: -n, polygonOffsetUnits: -n * 4 });
groundLayer(M.sidewalk, 1); groundLayer(M.lane, 2); groundLayer(WM.safety, 2); groundLayer(PM.pool, 3);

// ---- surface relief and wet ground
/** Give a material a normal map (bumps that catch the light), at a given strength. */
export function relief(mat, n, scale = 1) {
  if (!mat || !n) return;
  mat.normalMap = n; mat.normalScale.set(scale, scale); mat.needsUpdate = true;
}
relief(M.asphalt, normalFor(asphaltTex, 2), 0.8); relief(M.sidewalk, normalFor(sidewalkTex, 3)); relief(M.roof, normalFor(roofTex, 2.5));
relief(WM.floor, normalFor(concreteFloorTex, 2), 0.7); relief(WM.block, normalFor(blockTex, 3)); relief(WM.cladding, normalFor(corrugatedTex, 3));
relief(WM.roofDeck, normalFor(corrugatedTex, 3)); relief(PM.crate, normalFor(crateTex, 2.5));
for (const [style, mats] of Object.entries(FACADE)) if (style !== 'glass') relief(mats[0], normalFor(mats[0].map, 2.2), 0.8); // mortar and window reveals
// outdoor ground is wet: puddles are glossy and mirror the lamps and the sky
puddleRough.repeat.set(0.4, 0.4);
for (const m of [M.asphalt, M.sidewalk]) { m.roughnessMap = puddleRough; m.roughness = 1; m.needsUpdate = true; }
// cloth and leather on the hero and the soldiers
// the hero's cloth and leather stay dark: only a little of the sky in them
for (const m of [HM.coat, HM.coatSolid, HM.trousers, HM.glove, HM.leather, HM.wrap, HM.shirt]) m.envMapIntensity = 0.35;
relief(HM.coat, leatherNormal, 1.3); relief(HM.coatSolid, leatherNormal, 1.3); relief(HM.glove, leatherNormal, 0.6); relief(HM.leather, leatherNormal, 0.6);
relief(HM.trousers, weaveNormal, 0.7); relief(HM.wrap, weaveNormal, 0.8); relief(HM.shirt, weaveNormal, 0.6);
relief(SM.fatigue, weaveNormal, 0.6); relief(SM.balaclava, weaveNormal, 0.5);
