// Stage builders: the warehouse, the rooftops and downtown (the other stages live in maps.js).
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { scene, sun, hemi } from './engine.js';
import { resetEvents } from './events.js';
import { spawnBarrels } from './barrels.js';
import { clearLook } from './look.js';
import { splitBox } from './merge.js';
import { applyAtmosphere, lightShaft } from './atmosphere.js';
import { V3, rand, mulberry32 } from './util.js';
import { M, FACADE, FACADE_STYLES, CAR, PM, WM, neonMats } from './materials.js';
import {
  streetLamp, LAMP_HEAD, acUnit, fountain, kiosk, planter, bulkhead, waterTower, antennaMast,
  palletRack, highBayLamp, HIGH_BAY_Y, roofTruss, column, loadingDock, stepBlock, siteOffice, palletCrate, drumCluster,
  billboardFrame, girder, roofLight, ROOF_LIGHT_Y, roofClutter,
} from './props.js';
import { carParts, carSolids } from './cars.js';
import { dotTex } from './textures.js';
import { level } from './physics.js';
import { STAGES } from './config.js';
import { G } from './state.js';
import { MAP_BUILDERS } from './maps.js';

const FACADE_TILE = 1 / 24; // one facade texture tile = 24 m (8 bays × 8 floors of 3 m)
const ROOF_TILE = 1 / 8;

// ---- building blocks
/** Scale box UVs to world size (k = tiles per metre); offset shifts the side faces' texture. */
function scaleBoxUV(geo, sx, sy, sz, k, kTop = k, [ou, ov] = [0, 0]) {
  const uv = geo.attributes.uv;
  const dims = [[sz, sy, k, 1], [sz, sy, k, 1], [sx, sz, kTop, 0], [sx, sz, kTop, 0], [sx, sy, k, 1], [sx, sy, k, 1]];
  for (let f = 0; f < 6; f++) for (let i = 0; i < 4; i++) {
    const n = f * 4 + i, [a, b, kk, side] = dims[f];
    uv.setXY(n, uv.getX(n) * a * kk + ou * side, uv.getY(n) * b * kk + ov * side);
  }
  uv.needsUpdate = true;
}
/**
 * Solid box with its bottom at y. k/kTop set texture tiling in repeats per metre.
 * It joins the merged scenery (one draw per material for the whole stage) unless keep is set, for boxes an
 * event needs to move or remove later: those come back as { mesh, box }.
 */
function addBox(x, y, z, sx, sy, sz, mat, k = 1 / 2, kTop = k, { edges = true, offset, keep = false } = {}) {
  const geo = new THREE.BoxGeometry(sx, sy, sz);
  scaleBoxUV(geo, sx, sy, sz, k, kTop, offset);
  if (!keep) {
    if (edges) edgeGeos.push(new THREE.EdgesGeometry(geo).translate(x, y + sy / 2, z));
    decorGeo(geo, mat, x, y + sy / 2, z);
    const box = { min: new V3(x - sx / 2, y, z - sz / 2), max: new V3(x + sx / 2, y + sy, z + sz / 2) };
    level.boxes.push(box);
    return { mesh: null, box };
  }
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y + sy / 2, z);
  m.castShadow = m.receiveShadow = true;
  if (edges) m.add(new THREE.LineSegments(new THREE.EdgesGeometry(geo), M.edge));
  level.group.add(m);
  const box = { min: new V3(x - sx / 2, y, z - sz / 2), max: new V3(x + sx / 2, y + sy, z + sz / 2) };
  level.boxes.push(box);
  return { mesh: m, box }; // events can move or remove it
}
/** Invisible collision (for decor that should still be solid). */
function addSolid(x, y, z, sx, sy, sz) {
  level.boxes.push({ min: new V3(x - sx / 2, y, z - sz / 2), max: new V3(x + sx / 2, y + sy, z + sz / 2) });
}
/** Scenery only: no collision, no outline. */
function addDecor(geo, mat, x, y, z) {
  const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); level.group.add(m); return m;
}

// Small repeated detail (cornices, parapets, fire escapes, sidewalks, lane paint) is batched
// per material and merged into one mesh when the stage finishes building.
let decorBuckets = new Map(), edgeGeos = [];
function decorGeo(geo, mat, x, y, z, rotY = 0) {
  if (geo.index) geo = geo.toNonIndexed(); // merged buckets mix box, extrude and shape geometry
  if (rotY) geo.rotateY(rotY);
  geo.translate(x, y, z);
  if (!decorBuckets.has(mat)) decorBuckets.set(mat, []);
  decorBuckets.get(mat).push(geo);
}
/** Decor box with its bottom at y. */
function decorBox(x, y, z, sx, sy, sz, mat, k = 1 / 2) {
  const geo = new THREE.BoxGeometry(sx, sy, sz);
  scaleBoxUV(geo, sx, sy, sz, k);
  decorGeo(geo, mat, x, y + sy / 2, z);
}
function flushDecor() {
  for (const [mat, geos] of decorBuckets) {
    const merged = mergeGeometries(geos, false);
    geos.forEach(g => g.dispose());
    const m = new THREE.Mesh(merged, mat); m.castShadow = m.receiveShadow = true; level.group.add(m);
  }
  if (edgeGeos.length) {
    // every box outline on the stage as one set of lines
    const lines = mergeGeometries(edgeGeos, false); edgeGeos.forEach(g => g.dispose());
    level.group.add(new THREE.LineSegments(lines, M.edge));
  }
  decorBuckets = new Map(); edgeGeos = [];
}

/**
 * A building: facade box (solid), cornice and roof parapet, plus optional street-level shops,
 * a fire escape and a rooftop water tank.
 */
function building(cx, cz, w, d, bottom, top, style, rnd, { shops = false, fireEscape = false, tank = false, clutter = false } = {}) {
  const h = top - bottom;
  // walls and roof join the merged scenery (one draw per material, not six per building); collision as before
  const bgeo = new THREE.BoxGeometry(w, h, d);
  scaleBoxUV(bgeo, w, h, d, FACADE_TILE, ROOF_TILE, [Math.floor(rnd() * 8) / 8, 0]);
  const [walls, caps] = splitBox(bgeo); bgeo.dispose();
  decorGeo(walls, FACADE[style][0], cx, bottom + h / 2, cz); decorGeo(caps, M.roof, cx, bottom + h / 2, cz);
  addSolid(cx, bottom, cz, w, h, d);
  // cornice and parapet
  decorBox(cx, top - 0.34, cz, w + 0.36, 0.32, d + 0.36, M.cornice); // top sits 2 cm under the roof so the two never z-fight
  const t = 0.25, ph = 0.5;
  decorBox(cx, top, cz - d / 2 + t / 2, w, ph, t, M.cornice); decorBox(cx, top, cz + d / 2 - t / 2, w, ph, t, M.cornice);
  decorBox(cx - w / 2 + t / 2, top, cz, t, ph, d - 2 * t, M.cornice); decorBox(cx + w / 2 - t / 2, top, cz, t, ph, d - 2 * t, M.cornice);
  if (clutter) placeProp(roofClutter(w, d, rnd), cx, top, cz);
  if (shops) {
    decorBox(cx, bottom, cz, w + 0.3, 3.6, d + 0.3, M.storefront, FACADE_TILE);
    decorBox(cx, bottom + 3.6, cz, w + 0.5, 0.25, d + 0.5, M.cornice);
    // an awning over one side
    const side = (rnd() * 4) | 0, along = side < 2 ? w : d, len = along * (0.3 + rnd() * 0.4);
    const n = [[0, 1], [0, -1], [1, 0], [-1, 0]][side];
    const ax = cx + n[0] * ((side < 2 ? 0 : w / 2) + 0.9), az = cz + n[1] * ((side < 2 ? d / 2 : 0) + 0.9);
    decorBox(ax, bottom + 3.0, az, side < 2 ? len : 1.6, 0.1, side < 2 ? 1.6 : len, M.awning);
  }
  if (fireEscape && h > 9) {
    // iron landings every floor on one face, joined by ladders
    const side = (rnd() * 4) | 0, n = [[0, 1], [0, -1], [1, 0], [-1, 0]][side];
    const faceW = side < 2 ? w : d, slide = (rnd() - 0.5) * Math.max(0, faceW - 5);
    const at = (out, lateral) => side < 2
      ? [cx + lateral, cz + n[1] * (d / 2 + out)]
      : [cx + n[0] * (w / 2 + out), cz + lateral];
    const rot = side < 2 ? 0 : Math.PI / 2;
    for (let f = 1; f * 3 < h - 2; f++) {
      const y = bottom + f * 3;
      let [px, pz] = at(0.6, slide);
      decorGeo(new THREE.BoxGeometry(3.4, 0.07, 1.2), M.iron, px, y, pz, rot);
      [px, pz] = at(1.18, slide);
      decorGeo(new THREE.BoxGeometry(3.4, 0.05, 0.05), M.iron, px, y + 0.95, pz, rot);
      for (const e of [-1.7, 1.7]) { const [qx, qz] = at(1.18, slide + e); decorGeo(new THREE.BoxGeometry(0.05, 1, 0.05), M.iron, qx, y + 0.5, qz); }
      for (const e of [1.0, 1.4]) { const [qx, qz] = at(0.95, slide + e); decorGeo(new THREE.BoxGeometry(0.05, 3, 0.05), M.iron, qx, y - 1.5, qz); }
    }
  }
  if (tank && w > 8 && d > 8) {
    // wooden water tank on four legs (solid, so you can stand on it)
    const tx = cx + (rnd() - 0.5) * (w - 6), tz = cz + (rnd() - 0.5) * (d - 6);
    for (const [lx, lz] of [[-0.9, -0.9], [0.9, -0.9], [-0.9, 0.9], [0.9, 0.9]]) decorBox(tx + lx, top, tz + lz, 0.15, 1.6, 0.15, M.iron);
    decorGeo(new THREE.CylinderGeometry(1.35, 1.35, 2.4, 16), M.tank, tx, top + 2.8, tz);
    decorGeo(new THREE.ConeGeometry(1.45, 0.7, 16), M.iron, tx, top + 4.35, tz);
    addSolid(tx, top + 1.6, tz, 2.7, 2.4, 2.7);
  }
}

/** Place a prop's parts (see props.js) as merged decor at (x, y, z), turned rot about y. */
function placeProp(parts, x, y, z, rot = 0) { for (const { geo, mat } of parts) decorGeo(geo, mat, x, y, z, rot); }
/** A prop with a solid box footprint (bottom at y). */
function solidProp(parts, x, y, z, sx, sy, sz, rot = 0) { placeProp(parts, x, y, z, rot); addSolid(x, y, z, sx, sy, sz); }

/** A parked car at (x, z) facing rot (radians about y). Detail is merged decor; collision is invisible boxes. */
function addCar(x, z, rot, rnd) {
  const type = rnd() < 0.35 ? 'suv' : 'sedan';
  const paint = CAR.paints[(rnd() * CAR.paints.length) | 0];
  for (const { geo, mat } of carParts(type, paint, rnd() < 0.3)) decorGeo(geo, mat, x, 0, z, rot);
  const c = Math.cos(rot), s = Math.sin(rot), across = Math.abs(s) > 0.5;
  for (const [cx, bottom, lx, h, lz] of carSolids(type)) addSolid(x + cx * c, bottom, z - cx * s, across ? lz : lx, h, across ? lx : lz);
}

function addLight(color, intensity, dist, x, y, z) {
  const l = new THREE.PointLight(color, intensity, dist, 1.6); l.position.set(x, y, z); level.group.add(l);
}
function addFloor(w, d, mat, tile) {
  const fg = new THREE.PlaneGeometry(w, d); fg.rotateX(-Math.PI / 2);
  const uv = fg.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * w / tile, uv.getY(i) * d / tile);
  const floor = new THREE.Mesh(fg, mat); floor.receiveShadow = true; level.group.add(floor);
}
function addMoon(x, y, z, size) {
  const moon = new THREE.Sprite(new THREE.SpriteMaterial({ map: dotTex, color: new THREE.Color(2.4, 2.1, 1.8), fog: false, depthWrite: false }));
  moon.position.set(x, y, z); moon.scale.setScalar(size); level.group.add(moon);
}
/** A ring of lit towers far outside the playable area. */
function addSkyline(count, rMin, rMax, rnd, height, base) {
  const beacon = new THREE.BoxGeometry(0.4, 0.4, 0.4);
  for (let i = 0; i < count; i++) {
    const a = i / count * Math.PI * 2 + rnd(-0.05, 0.05), r = rnd(rMin, rMax);
    const x = Math.cos(a) * r, z = Math.sin(a) * r, w = rnd(10, 26), d = rnd(10, 26), top = rnd(...height);
    const tall = top - base, style = FACADE_STYLES[(rnd(0, 1) * FACADE_STYLES.length) | 0];
    const geo = new THREE.BoxGeometry(w, tall, d); scaleBoxUV(geo, w, tall, d, FACADE_TILE, ROOF_TILE, [Math.floor(rnd(0, 8)) / 8, 0]);
    const [walls, caps] = splitBox(geo); geo.dispose();
    decorGeo(walls, FACADE[style][0], x, base + tall / 2, z); decorGeo(caps, M.roof, x, base + tall / 2, z);
    if (rnd(0, 1) < 0.35) addDecor(beacon, M.beacon, x, top + 0.3, z);
  }
}
function setSky(background, fog, density, sunColor, sunIntensity) {
  scene.background.set(background);
  scene.fog = new THREE.FogExp2(fog, density);
  sun.color.set(sunColor); sun.intensity = sunIntensity;
  hemi.intensity = 1.1; G.blackout = false; // undo any event that dimmed the last stage
}

// ---- stages
function buildLobby() {
  level.floorY = 0;
  setSky(0x0b0907, 0x14100c, 0.01, 0xffe2c0, 0.5);
  const R = mulberry32(4242);
  const HW = 40, HD = 30, WH = 22;
  addFloor(HW * 2, HD * 2, WM.floor, 8);

  // shell: corrugated steel over a block band, a ribbon of clerestory windows high up
  addBox(0, 0, -HD - 0.5, HW * 2 + 2, WH, 1, WM.cladding, 1 / 4, 1 / 4, { edges: false });
  addBox(0, 0, HD + 0.5, HW * 2 + 2, WH, 1, WM.cladding, 1 / 4, 1 / 4, { edges: false });
  addBox(-HW - 0.5, 0, 0, 1, WH, HD * 2, WM.cladding, 1 / 4, 1 / 4, { edges: false });
  addBox(HW + 0.5, 0, 0, 1, WH, HD * 2, WM.cladding, 1 / 4, 1 / 4, { edges: false });
  for (const [x, z, sx, sz, alongX] of [[0, -HD + 0.1, HW * 2, 0.2, true], [0, HD - 0.1, HW * 2, 0.2, true], [-HW + 0.1, 0, 0.2, HD * 2, false], [HW - 0.1, 0, 0.2, HD * 2, false]]) {
    decorBox(x, 0, z, sx, 3, sz, WM.block, 1 / 4);
    const inset = alongX ? [0, Math.sign(-z) * 0.07] : [Math.sign(-x) * 0.07, 0];
    decorBox(x + inset[0], 15, z + inset[1], alongX ? sx : 0.06, 2.4, alongX ? 0.06 : sz, WM.clerestory);
    const span = alongX ? sx : sz;
    for (let t = -span / 2 + 2.5; t < span / 2; t += 2.5) {
      decorBox(alongX ? t : x + inset[0] * 1.6, 15, alongX ? z + inset[1] * 1.6 : t, 0.1, 2.4, 0.1, WM.steel);
    }
  }
  // roof: trusses every 10 m, purlins, and the deck
  for (let x = -35; x <= 35; x += 10) placeProp(roofTruss(HD * 2), x, 0, 0);
  for (let z = -28; z <= 28; z += 4) decorBox(0, 21.5, z, HW * 2, 0.12, 0.12, WM.steel);
  const deck = new THREE.PlaneGeometry(HW * 2, HD * 2);
  const duv = deck.attributes.uv; for (let i = 0; i < duv.count; i++) duv.setXY(i, duv.getX(i) * HW / 2, duv.getY(i) * HD / 2);
  decorGeo(deck.rotateX(Math.PI / 2), WM.roofDeck, 0, WH, 0);
  // high-bay lamps
  for (const x of [-24, -8, 8, 24]) for (const z of [-12, 12]) {
    placeProp(highBayLamp(), x, 0, z);
    addLight(0xffc27a, 55, 30, x, HIGH_BAY_Y - 0.4, z);
    lightShaft(x, HIGH_BAY_Y - 0.4, z, 0, 4.5, 0xffc27a);
  }
  // concrete columns
  for (const x of [-28, -14, 14, 28]) for (const z of [-12, 12]) solidProp(column(1.2, 19), x, 0, z, 1.2, WH, 1.2);
  // pallet racking: the wall-run lanes
  solidProp(palletRack(22, 7, 1, R), 0, 0, -20, 22, 7, 1);
  solidProp(palletRack(22, 7, 1, R), 0, 0, 20, 22, 7, 1);
  solidProp(palletRack(14, 7, 1, R), -32, 0, 0, 1, 7, 14, Math.PI / 2);
  solidProp(palletRack(14, 7, 1, R), 32, 0, 0, 1, 7, 14, Math.PI / 2);
  // loading dock in the middle, with steps
  solidProp(loadingDock(8, 3, 8), 0, 0, 0, 8, 3, 8);
  solidProp(stepBlock(3, 1.4, 3), 0, 0, 5.5, 3, 1.4, 3);
  solidProp(stepBlock(3, 1.4, 3), 0, 0, -5.5, 3, 1.4, 3);
  // site offices in two corners (their roofs are perches)
  solidProp(siteOffice(10, 5, 10), -35, 0, -25, 10, 5, 10);
  solidProp(siteOffice(10, 5, 10), 35, 0, 25, 10, 5, 10, Math.PI);
  // crates on pallets, and clusters of oil drums
  for (const [x, z] of [[-8, -9], [10, -6], [-18, 4], [20, 8], [-5, 14], [7, -14], [-22, -18], [24, -21], [15, 22], [-15, 24], [-9, -25], [26, -3]])
    solidProp(palletCrate(), x, 0, z, 2.2, 1.3, 2.2);
  for (const [x, z, c, r] of [[-37, 12, 2, 3], [37, -12, 2, 3], [18, -27.5, 3, 2], [-18, 27.5, 3, 2]])
    solidProp(drumCluster(c, r, R), x, 0, z, c * 0.62, 0.9, r * 0.62);
  // painted safety lines: walkways and a box around the dock
  for (const z of [-6.5, 6.5]) { decorBox(-22, 0, z, 30, 0.015, 0.12, WM.safety); decorBox(22, 0, z, 30, 0.015, 0.12, WM.safety); }
  for (const [x, z, sx, sz] of [[0, -7.5, 11, 0.12], [0, 7.5, 11, 0.12], [-5.5, 0, 0.12, 15], [5.5, 0, 0.12, 15]]) decorBox(x, 0, z, sx, 0.015, sz, WM.safety);
  level.spawns = [[-36, -5], [36, 5], [-10, -27], [10, 27], [0, -27], [-36, 20], [36, -20], [-25, 0], [25, 16], [-25, -6]].map(([x, z]) => [x, z, 0]);
  return { name: 'lobby', label: 'WAREHOUSE', start: new V3(0, 3, 0), orbitY: 2.5, killY: -1e9, spawnJitter: 1.2, bounds: [-HW, HW, -HD, HD],
    barrels: [[-10, 0, -10], [12, 0, -9], [-21, 0, 7], [22, 0, 11], [-6, 0, 17], [8, 0, -17], [-3, 3, 2.5]] };
}

function buildRooftop() {
  level.floorY = -1e9;
  setSky(0x120a07, 0x241208, 0.0075, 0xb8c2ff, 1.8);
  const R = mulberry32(911);
  const styles = ['brick', 'concrete', 'glass', 'brick', 'concrete', 'glass', 'brick'];
  let n = 0;
  const STREET = -58;
  const tower = (x0, x1, z0, z1, top) => {
    const style = styles[n++];
    building((x0 + x1) / 2, (z0 + z1) / 2, x1 - x0, z1 - z0, STREET, top, style, R, { shops: true, fireEscape: style === 'brick', clutter: true });
  };
  tower(-10, 10, -8, 8, 0);        // centre
  tower(-9, 9, -30, -13, 2);       // north
  tower(-8, 10, 13, 28, -1);       // south
  tower(16, 34, -10, 12, 1);       // east
  tower(-34, -17, -12, 10, 0.5);   // west
  tower(18, 30, -28, -16, 5);      // north-east perch
  tower(-30, -14, 16, 28, -2);     // south-west
  // neon billboards over the wide gaps: run along them to cross
  // [x, bottom, z, width, height, depth, sign, faces +z?]
  for (const [x, y, z, w, h, d, sign, front] of [
    [-13.5, -3, -9.2, 9, 9, 0.5, 0, true], [-11, -4, 14.5, 10, 9, 0.5, 1, false],
    [13.5, -2, -12.2, 11, 10, 0.5, 1, true], [0, 2, -29.6, 14, 7, 0.6, 0, true],
  ]) {
    addBox(x, y, z, w, h, d, neonMats[sign], 1 / w, 1 / w, { edges: false });
    placeProp(billboardFrame(w, h, d, y - STREET), x, y, z, front ? 0 : Math.PI);
    addLight(0xffd0a0, 30, 16, x, y + 0.5, z + (front ? 1.8 : -1.8));
  }
  solidProp(girder(6.2, 0.6, 1.2), 13, -0.6, 0, 6.2, 0.6, 1.2); // steel beam, centre to east
  for (const [x, y, z, sx, sy, sz] of [
    [-5, 0, -3, 2, 1.3, 2], [4, 0, 4, 2.4, 1.3, 1.6], [6, 0, -4, 1.6, 1.3, 2.4],
    [28, 1, 6, 2, 1.3, 2], [20, 1, 8, 2, 1.3, 2], [-26, 0.5, 0, 2.2, 1.3, 2.2],
    [5, -1, 20, 2.2, 1.3, 2.2], [-2, -1, 24, 2.2, 1.3, 4], [-20, -2, 22, 2.2, 1.3, 2.2],
  ]) solidProp(acUnit(sx, sy, sz), x, y, z, sx, sy, sz);
  solidProp(bulkhead(3.5, 3, 3.5), -6, 0, 4, 3.5, 3, 3.5);
  solidProp(bulkhead(5, 3.5, 4), 22, 1, -7.5, 5, 3.5, 4);
  solidProp(bulkhead(3, 2.5, 3), -22, 0.5, -8, 3, 2.5, 3, Math.PI);
  solidProp(waterTower(3.2, 7), -4, 2, -25, 3.2, 7, 3.2);
  solidProp(antennaMast(9), 27, 5, -26, 0.6, 9, 0.6);
  addDecor(new THREE.BoxGeometry(0.35, 0.35, 0.35), M.beacon, 27, 14.2, -26);
  addLight(0xff3020, 25, 18, 27, 14, -26);
  for (const [x, y, z] of [[3, 0, -5], [4, 2, -20], [-4, -1, 18], [25, 1, -2], [-26, 0.5, 6]]) {
    placeProp(roofLight(), x, y, z);
    addLight(0xffc890, 28, 18, x, y + ROOF_LIGHT_Y - 0.2, z);
    lightShaft(x, y + ROOF_LIGHT_Y - 0.25, z, y, 2.4, 0xffc890);
  }
  // the street far below: asphalt, lamp light, traffic
  const street = new THREE.PlaneGeometry(420, 420); street.rotateX(-Math.PI / 2);
  const suv = street.attributes.uv; for (let i = 0; i < suv.count; i++) suv.setXY(i, suv.getX(i) * 52, suv.getY(i) * 52);
  decorGeo(street, M.asphalt, 0, STREET, 0);
  for (let i = 0; i < 40; i++) {
    const x = rand(-110, 110), z = rand(-110, 110);
    decorGeo(new THREE.PlaneGeometry(12, 12).rotateX(-Math.PI / 2), PM.pool, x, STREET + 0.05, z);
    if (i % 2) {
      const alongX = Math.random() < 0.5, head = Math.random() < 0.5;
      for (const o of [-0.7, 0.7]) decorBox(x + (alongX ? 0 : o), STREET + 0.5, z + (alongX ? o : 0), 0.3, 0.2, 0.3, head ? CAR.headOn : CAR.tailOn);
    }
  }
  addSkyline(46, 62, 135, rand, [-5, 55], STREET);
  addMoon(-60, 90, -220, 40);
  level.spawns = [[-6, -19, 2], [6, -24, 2], [0, 17, -1], [6, 25, -1], [28, -2, 1], [24, 5, 1], [-28, -7, 0.5], [-24, 5, 0.5], [22, -21, 5], [-25, 21, -2]];
  return { name: 'rooftop', label: 'ROOFTOP', start: new V3(0, 0, 0), orbitY: 4, killY: -16, spawnJitter: 0.4,
    barrels: [[-3, 0, 6], [7, 0, -6], [27, 1, 3], [-24, 0.5, 4], [3, 2, -22], [-4, -1, 21]] };
}

function buildCity() {
  level.floorY = 0;
  setSky(0x120a07, 0x221008, 0.0055, 0xb8c2ff, 1.9);
  const R = mulberry32(7331), rr = (a, b) => a + R() * (b - a);
  const SIZE = 125;
  addFloor(SIZE * 2 + 60, SIZE * 2 + 60, M.asphalt, 8);
  level.spawns = [];
  // 28 m blocks on a 40 m grid, split into lots by 4 m alleys; taller toward the edge
  const blocks = [-100, -60, -20, 20, 60, 100];
  for (const bx of blocks) for (const bz of blocks) {
    // the plaza lays its own paving over the four middle blocks; a second slab there z-fights with it
    if (Math.abs(bx) < 40 && Math.abs(bz) < 40) continue; // leave the plaza open
    decorBox(bx, 0, bz, 32, 0.01, 32, M.sidewalk, 1 / 8);
    const edge = Math.max(Math.abs(bx), Math.abs(bz)) / 100;
    const xs = R() < 0.6 ? [[bx - 14, bx - 2], [bx + 2, bx + 14]] : [[bx - 14, bx + 14]];
    const zs = R() < 0.6 ? [[bz - 14, bz - 2], [bz + 2, bz + 14]] : [[bz - 14, bz + 14]];
    for (const [x0, x1] of xs) for (const [z0, z1] of zs) {
      const top = Math.round(rr(5, 11 + 15 * edge)), cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, w = x1 - x0, d = z1 - z0;
      const style = top > 18 && R() < 0.6 ? 'glass' : FACADE_STYLES[(R() * FACADE_STYLES.length) | 0];
      const tank = top > 11 && R() < 0.35;
      building(cx, cz, w, d, 0, top, style, R, { shops: style !== 'glass' || R() < 0.5, fireEscape: style === 'brick' && R() < 0.7, tank, clutter: true });
      if (!tank && R() < 0.6) {
        const ax = cx + rr(-2, 2), az = cz + rr(-2, 2), sx = rr(1.8, 3), sy = rr(1.2, 2.4), sz = rr(1.8, 3);
        solidProp(acUnit(sx, sy, sz), ax, top, az, sx, sy, sz);
      }
      if (R() < 0.22) addBox(cx, top, z1 - 0.5, w * 0.7, 5, 0.5, neonMats[R() < 0.5 ? 0 : 1], 1 / (w * 0.7), 1 / (w * 0.7), { edges: false });
      level.spawns.push([x0 + 1.6, z0 + 1.6, top]);
    }
  }
  // plaza: paving, a fountain to start on, kiosks and low walls
  decorBox(0, 0, 0, 78, 0.01, 78, M.sidewalk, 1 / 8);
  solidProp(fountain(), 0, 0, 0, 6, 1.2, 6);
  for (const [x, z] of [[-14, -14], [14, 14], [-14, 14], [14, -14]]) solidProp(kiosk(), x, 0, z, 3, 3, 3, Math.atan2(-x, -z));
  solidProp(planter(10), 0, 0, -20, 10, 1.2, 0.8); solidProp(planter(10), 0, 0, 20, 10, 1.2, 0.8);
  solidProp(planter(10), -20, 0, 0, 0.8, 1.2, 10, Math.PI / 2); solidProp(planter(10), 20, 0, 0, 0.8, 1.2, 10, Math.PI / 2);
  // dashed centre lines, broken at the crossings
  const lanes = [-80, -40, 0, 40, 80];
  const crossing = v => lanes.some(l => Math.abs(v - l) < 8) || Math.abs(v) < 40;
  for (const lane of lanes) for (let t = -118; t <= 118; t += 6) {
    if (crossing(t)) continue;
    decorBox(t, 0, lane, 3, 0.015, 0.18, M.lane);
    decorBox(lane, 0, t, 0.18, 0.015, 3, M.lane);
  }
  // parked cars
  for (let i = 0; i < 28; i++) {
    const alongX = R() < 0.5, lane = lanes[(R() * lanes.length) | 0], t = rr(-110, 110), side = R() < 0.5 ? -2.9 : 2.9; // against the curb
    const x = alongX ? t : lane + side, z = alongX ? lane + side : t;
    if (Math.abs(x) < 24 && Math.abs(z) < 24) continue;
    addCar(x, z, (alongX ? 0 : Math.PI / 2) + (R() < 0.5 ? Math.PI : 0), R);
  }
  // street lamps: every head glows, only the ones near the plaza cast light
  for (const x of lanes) for (const z of lanes) {
    const px = x + 6.5, pz = z + 6.5;
    placeProp(streetLamp(), px, 0, pz, Math.PI); // arm reaches out over the road (-x)
    addSolid(px, 0, pz, 0.3, 7.5, 0.3);
    if (Math.abs(x) <= 40 && Math.abs(z) <= 40) { addLight(0xff9a4a, 40, 24, px - LAMP_HEAD.x, LAMP_HEAD.y - 0.2, pz); lightShaft(px - LAMP_HEAD.x, LAMP_HEAD.y - 0.25, pz, 0, 3.2, 0xff9a4a); }
    if (!(x === 0 && z === 0)) level.spawns.push([x + rr(-2, 2), z + rr(-2, 2), 0]);
  }
  // towers too tall to climb wall the city in
  for (const [x, z, sx, sz] of [[0, -SIZE - 6, SIZE * 2 + 24, 12], [0, SIZE + 6, SIZE * 2 + 24, 12], [-SIZE - 6, 0, 12, SIZE * 2], [SIZE + 6, 0, 12, SIZE * 2]])
    building(x, z, sx, sz, 0, 75, 'glass', R);
  addSkyline(40, 170, 240, rr, [60, 130], 0);
  addMoon(-80, 120, -250, 45);
  return { name: 'city', label: 'DOWNTOWN', start: new V3(0, 1.2, 0), orbitY: 5, killY: -1e9, spawnJitter: 0.4,
    barrels: [[-8, 0, 8], [9, 0, -9], [-24, 0, -4], [24, 0, 6], [4, 0, 26], [-5, 0, -26], [-11.5, 0, -14], [15, 0, 13]] };
}

const BUILDERS = { lobby: buildLobby, rooftop: buildRooftop, city: buildCity, ...MAP_BUILDERS };

/** The building helpers, for the stages in maps.js. */
export const kit = {
  addBox, addSolid, addDecor, decorGeo, decorBox, placeProp, solidProp, addLight, addFloor, addMoon, addSkyline, setSky,
  building, addCar, FACADE_TILE, ROOF_TILE,
};

/** Which stage wave w is played on: the start stage, then the next one every five waves. */
export const stageFor = w => STAGES[((G.daily ? G.daily.stage : G.startStage) + Math.floor((Math.max(w, 1) - 1) / 5)) % STAGES.length];

/** Build a stage, replacing the current one. Returns false if it was already loaded. */
export function loadLevel(name) {
  if (level.info && level.info.name === name) return false;
  if (level.group) {
    scene.remove(level.group);
    level.group.traverse(o => { if (o.geometry) o.geometry.dispose(); });
  }
  level.group = new THREE.Group(); scene.add(level.group);
  level.boxes = [];
  decorBuckets = new Map(); edgeGeos = [];
  resetEvents(); clearLook();
  level.info = BUILDERS[name]();
  flushDecor();
  spawnBarrels(level.info.barrels || []);
  applyAtmosphere(level.info.name);
  return true;
}
