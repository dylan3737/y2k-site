// Procedural canvas textures, so the game ships with no image files.
import * as THREE from 'three';
import { renderer } from './engine.js';

// full anisotropic filtering keeps floors, roofs and facades crisp (not shimmering) at shallow angles
const MAX_ANISO = renderer.capabilities.getMaxAnisotropy();

function canvas(w, h = w) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  return [c, c.getContext('2d')];
}
function toTexture(c, { repeat = true, aniso = MAX_ANISO } = {}) {
  const t = new THREE.CanvasTexture(c);
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = aniso;
  return t;
}

/** Soft round dot for particles, muzzle flashes and the moon. */
export const dotTex = (() => {
  const [c, g] = canvas(64);
  const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.35, 'rgba(255,255,255,0.5)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
})();




function neonSign(big, small) {
  const [c, g] = canvas(512);
  g.fillStyle = '#000'; g.fillRect(0, 0, 512, 512);
  g.strokeStyle = '#ff3a1a'; g.lineWidth = 6; g.shadowColor = '#ff3a1a'; g.shadowBlur = 24; g.strokeRect(24, 24, 464, 464);
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.font = 'bold 120px Impact, "Arial Black", sans-serif'; g.fillStyle = '#ff5a2a';
  big.forEach((line, i) => g.fillText(line, 256, 170 + i * 120));
  g.font = 'bold 40px Impact, "Arial Black", sans-serif'; g.fillStyle = '#ffc070'; g.shadowColor = '#ffae40';
  g.fillText(small, 256, 440);
  return toTexture(c, { repeat: false });
}
export const neonTexs = [neonSign(['PRIME', 'CUTS'], 'OPEN ALL NIGHT'), neonSign(['NO', 'MERCY'], 'GRILL · BAR · MOTEL')];

// ---- city surfaces ------------------------------------------------------------
const pick = (list, r = Math.random()) => {
  const total = list.reduce((s, [, w]) => s + w, 0);
  let x = r * total;
  for (const [v, w] of list) if ((x -= w) <= 0) return v;
  return list[0][0];
};
const noise = (g, w, h, n, base, spread) => {
  for (let i = 0; i < n; i++) {
    const v = (Math.random() * spread) | 0;
    g.fillStyle = `rgb(${base[0] + v},${base[1] + v},${base[2] + v})`;
    g.fillRect(Math.random() * w, Math.random() * h, 2, 2);
  }
};
const LIT = [['#ffcf88', 5], ['#ffe3b8', 3], ['#fff2dc', 2], ['#bcd6ff', 1.2], ['#8fb2ff', 0.4]];

/** Draw one window: dark glass with a faint sky reflection, or lit from inside (blinds, furniture). Lit windows also go on the emissive map. */
function windowPane(g, ge, x, y, w, h, litChance) {
  const glass = g.createLinearGradient(x, y, x + w * 0.6, y + h);
  glass.addColorStop(0, '#2a333d'); glass.addColorStop(0.45, '#12171d'); glass.addColorStop(1, '#0a0d11');
  g.fillStyle = glass; g.fillRect(x, y, w, h);
  if (Math.random() > litChance) return;
  const col = pick(LIT), glowLevel = 0.55 + Math.random() * 0.45;
  for (const [ctx, alpha] of [[g, 0.85], [ge, glowLevel]]) {
    const inside = ctx.createLinearGradient(x, y, x, y + h);
    inside.addColorStop(0, col); inside.addColorStop(1, '#3a2410');
    ctx.globalAlpha = alpha; ctx.fillStyle = inside; ctx.fillRect(x, y, w, h); ctx.globalAlpha = 1;
    ctx.fillStyle = 'rgba(0,0,0,0.55)';
    if (Math.random() < 0.4) { const drop = h * (0.2 + Math.random() * 0.5); for (let yy = y; yy < y + drop; yy += 3) ctx.fillRect(x, yy, w, 1); } // blinds
    if (Math.random() < 0.35) ctx.fillRect(x + w * (0.2 + Math.random() * 0.5), y + h * 0.6, w * 0.25, h * 0.4); // furniture
  }
}

/** A 24 m × 24 m facade tile: 8 bays by 8 floors. Returns { map, emissiveMap }. */
function facade(style) {
  const [c, g] = canvas(512), [e, ge] = canvas(512);
  ge.fillStyle = '#000'; ge.fillRect(0, 0, 512, 512);
  const B = 64;
  if (style === 'brick') {
    g.fillStyle = '#3e241c'; g.fillRect(0, 0, 512, 512);
    for (let y = 0; y < 512; y += 8) {
      const off = (y / 8) % 2 ? 8 : 0;
      for (let x = -16; x < 512; x += 16) {
        const t = (Math.random() * 20) | 0;
        g.fillStyle = `rgb(${88 + t},${46 + (t * 0.6 | 0)},${34 + (t * 0.4 | 0)})`; g.fillRect(x + off + 1, y + 1, 14, 6);
      }
    }
  } else if (style === 'concrete') {
    g.fillStyle = '#7a746c'; g.fillRect(0, 0, 512, 512);
    noise(g, 512, 512, 5000, [100, 95, 88], 36);
    g.fillStyle = 'rgba(0,0,0,0.25)';
    for (let i = 0; i <= 512; i += B) { g.fillRect(0, i, 512, 2); g.fillRect(i, 0, 1, 512); }
  } else {
    g.fillStyle = '#1c2630'; g.fillRect(0, 0, 512, 512);
  }
  for (let fy = 0; fy < 8; fy++) for (let bx = 0; bx < 8; bx++) {
    const x = bx * B, y = fy * B;
    if (style === 'brick') {
      g.fillStyle = '#a79a88'; g.fillRect(x + 13, y + 9, 38, 5); g.fillRect(x + 12, y + 52, 40, 5); // lintel, sill
      g.fillStyle = '#1a1411'; g.fillRect(x + 15, y + 13, 34, 40);                                 // frame
      windowPane(g, ge, x + 17, y + 15, 30, 36, 0.28);
      g.fillStyle = '#1a1411'; g.fillRect(x + 31, y + 15, 2, 36); g.fillRect(x + 17, y + 31, 30, 2); // muntins
    } else if (style === 'concrete') {
      g.fillStyle = '#1b1a19'; g.fillRect(x, y + 20, B, 30);
      windowPane(g, ge, x + 3, y + 22, B - 6, 26, 0.3);
      g.fillStyle = '#4c4843'; g.fillRect(x + B / 2 - 1, y + 20, 2, 30);
    } else {
      windowPane(g, ge, x + 2, y + 3, B - 4, 50, 0.34);
      g.fillStyle = '#26303a'; g.fillRect(x, y + 54, B, 10);                                        // spandrel
      g.fillStyle = '#4a5560'; g.fillRect(x, y, 2, B); g.fillRect(x + B / 2, y + 3, 1, 50);          // mullions
    }
  }
  return { map: toTexture(c), emissiveMap: toTexture(e) };
}
export const facades = { brick: facade('brick'), concrete: facade('concrete'), glass: facade('glass') };

/** Street-level shop fronts: 4 units per 24 m, stretched over a 3.6 m band (see texture repeat in materials). */
export const storefront = (() => {
  const [c, g] = canvas(512, 128), [e, ge] = canvas(512, 128);
  g.fillStyle = '#231e1b'; g.fillRect(0, 0, 512, 128); ge.fillStyle = '#000'; ge.fillRect(0, 0, 512, 128);
  const signs = ['BAR', '24H', 'PAWN', 'NOODLES', 'LIQUOR', 'DINER', 'TATTOO', 'HOTEL', 'GUNS', 'CAFE', 'DELI', 'LAUNDRY'];
  const colors = ['#ff4a2a', '#ffb13b', '#39d0c8', '#efe6d4', '#ff2e6a', '#9df05a'];
  for (let i = 0; i < 4; i++) {
    const x = i * 128, col = colors[(Math.random() * colors.length) | 0];
    g.fillStyle = '#15110f'; g.fillRect(x + 2, 0, 124, 128);
    // sign
    for (const [ctx, a] of [[g, 0.9], [ge, 1]]) {
      ctx.globalAlpha = a; ctx.fillStyle = '#0c0a09'; ctx.fillRect(x + 8, 6, 112, 22);
      ctx.fillStyle = col; ctx.font = 'bold 17px Impact, "Arial Black", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(signs[(Math.random() * signs.length) | 0], x + 64, 18); ctx.globalAlpha = 1;
    }
    // shop window and door
    windowPane(g, ge, x + 8, 36, 82, 84, 0.75);
    g.fillStyle = '#15110f'; g.fillRect(x + 48, 36, 2, 84);
    windowPane(g, ge, x + 96, 44, 24, 76, 0.4);
  }
  const map = toTexture(c), emissiveMap = toTexture(e);
  return { map, emissiveMap };
})();

/** Gravel and tar roof. */
export const roofTex = (() => {
  const [c, g] = canvas(256);
  g.fillStyle = '#403b37'; g.fillRect(0, 0, 256, 256);
  noise(g, 256, 256, 9000, [50, 46, 43], 40);
  g.fillStyle = 'rgba(0,0,0,0.35)';
  for (let i = 0; i < 5; i++) g.fillRect(0, Math.random() * 256, 256, 2);
  for (let i = 0; i < 6; i++) { g.fillStyle = `rgba(20,18,16,${0.2 + Math.random() * 0.3})`; g.fillRect(Math.random() * 220, Math.random() * 220, 20 + Math.random() * 40, 14 + Math.random() * 30); }
  return toTexture(c);
})();

/** Worn asphalt with cracks and stains. */
export const asphaltTex = (() => {
  const [c, g] = canvas(256);
  g.fillStyle = '#2b2927'; g.fillRect(0, 0, 256, 256);
  noise(g, 256, 256, 12000, [34, 32, 30], 26);
  g.strokeStyle = 'rgba(0,0,0,0.5)'; g.lineWidth = 1;
  for (let i = 0; i < 6; i++) {
    let x = Math.random() * 256, y = Math.random() * 256;
    g.beginPath(); g.moveTo(x, y);
    for (let k = 0; k < 6; k++) { x += (Math.random() - 0.5) * 30; y += (Math.random() - 0.5) * 30; g.lineTo(x, y); }
    g.stroke();
  }
  for (let i = 0; i < 5; i++) { g.fillStyle = 'rgba(10,8,6,0.25)'; g.beginPath(); g.arc(Math.random() * 256, Math.random() * 256, 8 + Math.random() * 20, 0, Math.PI * 2); g.fill(); }
  return toTexture(c);
})();

/** Concrete sidewalk slabs, 2 m apart at 8 m per tile. */
export const sidewalkTex = (() => {
  // 4x4 paving slabs over one 8 m tile. Everything here is soft and low-contrast on purpose:
  // hairline joints and pixel speckle break up into crawling dots once the plaza shrinks into the distance.
  const S = 512, N = 4, cell = S / N;
  const [c, g] = canvas(S);
  g.fillStyle = '#6e6861'; g.fillRect(0, 0, S, S);
  // each slab a slightly different shade, like real paving
  for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) {
    const v = Math.random() - 0.5;
    g.fillStyle = v > 0 ? `rgba(255,240,220,${v * 0.1})` : `rgba(0,0,0,${-v * 0.12})`;
    g.fillRect(i * cell, j * cell, cell, cell);
  }
  // mottling: soft blobs, not single pixels
  for (let k = 0; k < 700; k++) {
    const x = Math.random() * S, y = Math.random() * S, r = 4 + Math.random() * 14, a = 0.03 + Math.random() * 0.04;
    const col = Math.random() < 0.5 ? '0,0,0' : '255,245,230';
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, `rgba(${col},${a})`); gr.addColorStop(1, `rgba(${col},0)`);
    g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
  }
  // wide, feathered joints: they read as calm lines at any distance
  for (let i = 0; i <= N; i++) {
    const p = i * cell;
    for (const [w, a] of [[12, 0.05], [7, 0.08], [3, 0.14]]) {
      g.fillStyle = `rgba(0,0,0,${a})`;
      g.fillRect(0, p - w / 2, S, w); g.fillRect(p - w / 2, 0, w, S);
    }
  }
  return toTexture(c);
})();

/** Wooden crate face: plank boards inside a darker frame with a diagonal brace. One tile per crate face. */
export const crateTex = (() => {
  const [c, g] = canvas(256);
  g.fillStyle = '#7a5634'; g.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 32) {
    const t = (Math.random() * 24) | 0;
    g.fillStyle = `rgb(${112 + t},${78 + t},${48 + (t >> 1)})`; g.fillRect(0, y + 1, 256, 30);
    g.fillStyle = 'rgba(40,24,12,0.5)'; g.fillRect(0, y, 256, 2);
  }
  noise(g, 256, 256, 3000, [70, 48, 28], 40);
  g.strokeStyle = '#4a3019'; g.lineWidth = 22; g.strokeRect(11, 11, 234, 234);
  g.beginPath(); g.moveTo(22, 234); g.lineTo(234, 22); g.stroke();
  g.fillStyle = '#2a2a2a'; for (const [x, y] of [[14, 14], [242, 14], [14, 242], [242, 242]]) g.fillRect(x - 4, y - 4, 8, 8);
  return toTexture(c);
})();

// ---- warehouse surfaces ---------------------------------------------------------
/** Corrugated steel cladding: vertical ribs, seams and a little rust (4 m per tile). */
export const corrugatedTex = (() => {
  const [c, g] = canvas(256);
  for (let x = 0; x < 256; x += 16) {
    const rib = g.createLinearGradient(x, 0, x + 16, 0);
    rib.addColorStop(0, '#5e6366'); rib.addColorStop(0.35, '#8a8f92'); rib.addColorStop(0.6, '#6c7174'); rib.addColorStop(1, '#4a4e51');
    g.fillStyle = rib; g.fillRect(x, 0, 16, 256);
  }
  g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(0, 126, 256, 3);
  for (let i = 0; i < 7; i++) {
    const x = Math.random() * 256, len = 30 + Math.random() * 90;
    const rust = g.createLinearGradient(0, 128, 0, 128 + len);
    rust.addColorStop(0, 'rgba(120,60,25,0.55)'); rust.addColorStop(1, 'rgba(120,60,25,0)');
    g.fillStyle = rust; g.fillRect(x, 128, 3 + Math.random() * 5, len);
  }
  return toTexture(c);
})();

/** Polished concrete slab: joints every 4 m, oil stains and scuffs (8 m per tile). */
export const concreteFloorTex = (() => {
  const [c, g] = canvas(256);
  g.fillStyle = '#77726b'; g.fillRect(0, 0, 256, 256);
  noise(g, 256, 256, 9000, [100, 95, 89], 34);
  for (let i = 0; i < 9; i++) {
    const x = Math.random() * 256, y = Math.random() * 256, r = 8 + Math.random() * 26;
    g.fillStyle = `rgba(30,26,22,${0.12 + Math.random() * 0.2})`; g.beginPath(); g.ellipse(x, y, r, r * (0.5 + Math.random() * 0.5), Math.random() * 3, 0, Math.PI * 2); g.fill();
  }
  g.fillStyle = 'rgba(20,18,16,0.55)'; g.fillRect(0, 0, 256, 2); g.fillRect(0, 128, 256, 2); g.fillRect(0, 0, 2, 256); g.fillRect(128, 0, 2, 256);
  return toTexture(c);
})();

/** Painted concrete blocks (40 × 20 cm) for the lower wall band (4 m per tile). */
export const blockTex = (() => {
  const [c, g] = canvas(256);
  g.fillStyle = '#4f4b47'; g.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 13) {
    const off = (y / 13) % 2 ? 13 : 0;
    for (let x = -26; x < 256; x += 26) { const t = (Math.random() * 12) | 0; g.fillStyle = `rgb(${128 + t},${124 + t},${116 + t})`; g.fillRect(x + off + 1, y + 1, 24, 11); }
  }
  return toTexture(c);
})();

/** Black and yellow hazard stripes (1 m per tile). */
export const hazardTex = (() => {
  const [c, g] = canvas(128);
  g.fillStyle = '#d9a91a'; g.fillRect(0, 0, 128, 128);
  g.fillStyle = '#141414';
  for (let x = -128; x < 256; x += 64) { g.beginPath(); g.moveTo(x, 128); g.lineTo(x + 32, 128); g.lineTo(x + 160, 0); g.lineTo(x + 128, 0); g.fill(); }
  return toTexture(c);
})();

/** Subway tile: cream bevelled bricks, 2:1, in running bond. Soft joints so the walls don't shimmer. */
export const tileTex = (() => {
  const S = 512, TW = 64, TH = 32;
  const [c, g] = canvas(S);
  g.fillStyle = '#d6d0c2'; g.fillRect(0, 0, S, S);
  for (let row = 0; row * TH < S; row++) {
    const off = row % 2 ? TW / 2 : 0;
    for (let x = -TW; x < S + TW; x += TW) {
      const v = Math.random() - 0.5;
      g.fillStyle = v > 0 ? `rgba(255,250,235,${v * 0.18})` : `rgba(60,50,40,${-v * 0.14})`;
      g.fillRect(x + off, row * TH, TW, TH);
      // a soft highlight along each tile's top edge reads as the bevel
      g.fillStyle = 'rgba(255,255,255,0.08)'; g.fillRect(x + off + 3, row * TH + 3, TW - 6, 5);
    }
  }
  for (const [w, a] of [[7, 0.05], [4, 0.08], [2, 0.12]]) {
    g.fillStyle = `rgba(40,34,28,${a})`;
    for (let y = 0; y <= S; y += TH) g.fillRect(0, y - w / 2, S, w);
    for (let row = 0; row * TH < S; row++) {
      const off = row % 2 ? TW / 2 : 0;
      for (let x = off; x <= S; x += TW) g.fillRect(x - w / 2, row * TH, w, TH);
    }
  }
  return toTexture(c);
})();

// ---- surface relief: normal maps worked out from a height image, so light catches grain, joints and creases
/** A tangent-space normal map from a height canvas (brighter = higher). strength scales the slopes. */
function normalFromHeight(src, strength = 2) {
  const w = src.width, h = src.height, sg = src.getContext('2d').getImageData(0, 0, w, h).data;
  const [c, g] = canvas(w, h), out = g.createImageData(w, h), d = out.data;
  const H = (x, y) => sg[(((y + h) % h) * w + ((x + w) % w)) * 4] / 255; // red channel, wrapped so tiles stay seamless
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const dx = (H(x + 1, y) - H(x - 1, y)) * strength, dy = (H(x, y + 1) - H(x, y - 1)) * strength;
    const l = Math.hypot(dx, dy, 1), i = (y * w + x) * 4;
    d[i] = (-dx / l * 0.5 + 0.5) * 255; d[i + 1] = (dy / l * 0.5 + 0.5) * 255; d[i + 2] = (1 / l * 0.5 + 0.5) * 255; d[i + 3] = 255;
  }
  g.putImageData(out, 0, 0);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = MAX_ANISO;
  return t; // linear data, not colour
}
/** Greyscale height from a colour texture's canvas (dark joints sit low, bright faces high). */
function heightFromTexture(tex) {
  const img = tex.image, [c, g] = canvas(img.width, img.height);
  g.filter = 'grayscale(1) contrast(1.4)'; g.drawImage(img, 0, 0);
  return c;
}
const normalCache = new Map();
/** A normal map that matches a colour texture (same tiling). */
export function normalFor(tex, strength = 2) {
  if (!tex || !tex.image) return null;
  const key = tex.uuid + strength;
  if (!normalCache.has(key)) {
    const n = normalFromHeight(heightFromTexture(tex), strength);
    n.repeat.copy(tex.repeat); n.offset.copy(tex.offset);
    normalCache.set(key, n);
  }
  return normalCache.get(key);
}

/** Creased, grainy leather (the duster and gloves). */
export const leatherNormal = (() => {
  const S = 256, [c, g] = canvas(S);
  g.fillStyle = '#808080'; g.fillRect(0, 0, S, S);
  for (let i = 0; i < 2600; i++) { const v = 100 + Math.random() * 60; g.fillStyle = `rgb(${v},${v},${v})`; g.fillRect(Math.random() * S, Math.random() * S, 2, 2); } // grain
  g.lineCap = 'round';
  for (let i = 0; i < 26; i++) {
    // long soft creases running down the coat
    const x = Math.random() * S, y = Math.random() * S, len = 30 + Math.random() * 70, a = Math.PI / 2 + (Math.random() - 0.5) * 0.6;
    for (const [w, v] of [[7, 112], [3, 90]]) {
      g.strokeStyle = `rgb(${v},${v},${v})`; g.lineWidth = w; g.beginPath(); g.moveTo(x, y);
      g.quadraticCurveTo(x + Math.cos(a) * len * 0.5 + (Math.random() - 0.5) * 20, y + Math.sin(a) * len * 0.5, x + Math.cos(a) * len, y + Math.sin(a) * len); g.stroke();
    }
  }
  const t = normalFromHeight(c, 2.5); t.repeat.set(3, 3); return t;
})();
/** Diagonal twill weave (trousers, the face wrap). */
export const weaveNormal = (() => {
  const S = 128, [c, g] = canvas(S);
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) { const v = 128 + 70 * Math.sin((x + y) * Math.PI / 4) * (0.6 + 0.4 * Math.sin(y * Math.PI / 2)); g.fillStyle = `rgb(${v},${v},${v})`; g.fillRect(x, y, 1, 1); }
  const t = normalFromHeight(c, 1.2); t.repeat.set(8, 8); return t;
})();
/** Puddles for wet outdoor floors: as a roughness map, the dark blobs are glossy and mirror lights and sky. */
export const puddleRough = (() => {
  const S = 256, [c, g] = canvas(S);
  g.fillStyle = 'rgb(220,220,220)'; g.fillRect(0, 0, S, S);
  for (let i = 0; i < 7; i++) {
    const x = Math.random() * S, y = Math.random() * S, r = 18 + Math.random() * 34;
    for (const [ox, oy] of [[0, 0], [S, 0], [-S, 0], [0, S], [0, -S]]) { // wrap so the pattern tiles
      const gr = g.createRadialGradient(x + ox, y + oy, r * 0.3, x + ox, y + oy, r);
      gr.addColorStop(0, 'rgb(28,28,28)'); gr.addColorStop(0.75, 'rgb(60,60,60)'); gr.addColorStop(1, 'rgba(220,220,220,0)');
      g.fillStyle = gr; g.beginPath(); g.ellipse(x + ox, y + oy, r * 1.4, r, Math.random(), 0, Math.PI * 2); g.fill();
    }
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = MAX_ANISO;
  return t;
})();
