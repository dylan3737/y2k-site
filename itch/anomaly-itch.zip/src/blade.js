// The thrown katana: a quick wind-up, then it spins out along your aim, kills the first enemy it meets and pins them to the wall
// behind, then sticks in whatever it hits. Throw again to recall it (it cuts through anyone on the way back),
// or walk over it. While it's out you have no blade: no slash, no dash-cut, no parry.
import * as THREE from 'three';
import { scene, camera } from './engine.js';
import { V3, damp } from './util.js';

// the blade's own scratch vectors: killing something runs code that borrows the shared ones
const dirV = new V3(), handV = new V3(), lookV = new V3();
import { rayWorld, rayAABB } from './physics.js';
import { sparks, embers } from './fx.js';
import { sfx } from './audio.js';
import { G, P, world } from './state.js';
import { hero } from './hero.js';
import { isLive } from './soldiers.js';
import { damageSoldier } from './combat.js';
import { droneAlong } from './drones.js';
import { popup } from './ui.js';
import { rumble } from './rumble.js';

const SPEED = 42, RECALL = 58, RANGE = 45, PIN_REACH = 12, PICKUP = 1.6;
/** Seconds from the throw press to the blade leaving the hand: the hero's wind-up (hero.js poses it). */
export const WINDUP = 0.075;
let b = null; // { state: 'flying' | 'falling' | 'stuck' | 'recall', outer, spinner, tip, blur, pos, vel, travelled, carry, hit: Set }
let winding = false; // pressed, still in the hand
/** When (G.clock) the last throw was pressed and the last catch landed, for the hero's throw and catch poses. */
export const bladeAnim = { thrownAt: -9, caughtAt: -9 };

export const bladeInHand = () => !b && !winding;
/** Where the blade is, when it's out: { state, pos } (for the HUD), else null. */
export const bladeState = () => (b ? { state: b.state, pos: b.pos.clone() } : null);

const blurGeo = new THREE.RingGeometry(0.22, 0.66, 40, 1).rotateX(-Math.PI / 2);
function makeMesh() {
  const outer = new THREE.Group(), spinner = new THREE.Group(), copy = hero.katana.clone(true);
  copy.visible = true; copy.position.set(0, 0, 0.45); copy.rotation.set(Math.PI / 2, 0, 0); // blade flat, tip toward -z, middle at the pivot
  copy.traverse(o => { if (o.isMesh) o.castShadow = true; });
  const tip = new THREE.Object3D(); tip.position.set(0, -1.05, 0.02); copy.add(tip);
  // the spin smears into a faint disc of steel and ember
  const blur = new THREE.Mesh(blurGeo, new THREE.MeshBasicMaterial({ color: 0xffb27a, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
  spinner.add(copy); outer.add(spinner, blur); scene.add(outer);
  return { outer, spinner, tip, blur };
}

/** Throw it (if it's in hand), or call it back (if it's out). */
export function throwKatana() {
  if (G.mode !== 'play' || winding) return;
  if (b) { recall(); return; }
  winding = true; bladeAnim.thrownAt = G.clock; // it leaves the hand at the end of the wind-up (updateBlade)
  P.swordT = 0; P.slashT = 0; P.chargeT = 0; P.chargeReady = false;
  sfx.whoosh(0.8);
}
function release() {
  winding = false;
  camera.updateMatrixWorld(); // the aim as it is now, not as it was at the last render
  const dir = camera.getWorldDirection(new V3());
  // out of the throwing hand, toward whatever the crosshair is on
  const pos = hero.arms[1].hand.getWorldPosition(new V3());
  if (!hero.root.visible || pos.distanceTo(P.pos) > 2.5) pos.set(P.pos.x, P.pos.y + 1.3, P.pos.z).addScaledVector(dir, 0.8);
  const aim = camera.position.clone().addScaledVector(dir, rayWorld(camera.position, dir, RANGE));
  const to = aim.sub(pos);
  if (to.length() > 3 && to.normalize().dot(dir) > 0.8) dir.copy(to);
  const { outer, spinner, tip, blur } = makeMesh();
  b = { state: 'flying', outer, spinner, tip, blur, pos, vel: dir.clone().multiplyScalar(SPEED), travelled: 0, carry: null, hit: new Set(), spin: 0, quiver: 0 };
  sfx.slash(); sfx.whoosh(1.2); rumble(0.2, 0.05, 50);
}
function recall() {
  if (!b || b.state === 'recall') return;
  if (b.carry) { b.carry.pin = null; b.carry = null; } // the pinned body drops
  b.state = 'recall'; b.hit = new Set(); sfx.whoosh(1.5);
}
function catchIt() {
  removeMesh(); b = null; bladeAnim.caughtAt = G.clock;
  sfx.clang(); rumble(0.25, 0.1, 60);
}
function removeMesh() { scene.remove(b.outer); b.blur.material.dispose(); }
export function resetBlade() {
  if (b) { if (b.carry) b.carry.pin = null; removeMesh(); }
  b = null; winding = false; bladeAnim.thrownAt = bladeAnim.caughtAt = -9;
}

/** Everything the blade cuts on a segment from p0 along dir for len metres (enemies it hasn't hit yet this flight). */
function cutAlong(p0, dir, len, tags) {
  let first = null;
  for (const s of world.soldiers) {
    if (!isLive(s) || b.hit.has(s)) continue;
    const k = s.scale, p = s.pos;
    const t = rayAABB(p0, dir, p.x - 0.4 * k, p.y, p.z - 0.4 * k, p.x + 0.4 * k, p.y + 1.95 * k, p.z + 0.4 * k, len);
    if (t < len && (!first || t < first.t)) first = { s, t };
  }
  const dr = droneAlong(p0, dir, len);
  if (dr && !b.hit.has(dr.d) && (!first || dr.t < first.t)) { b.hit.add(dr.d); dr.d.hurt(999, tags); }
  if (!first) return null;
  const s = first.s; b.hit.add(s);
  const pt = p0.clone().addScaledVector(dir, first.t);
  sparks.emit(pt, 12, 5, 3, 1.4, 0.4, 0.3, 4);
  if (s.boss) { s.knock.set(0, 0, 0); damageSoldier(s, 250, false, dir, tags); return { s, pt, boss: true }; }
  s.knock.set(dir.x * 3, 1, dir.z * 3);
  damageSoldier(s, 999, false, dir, tags);
  return { s, pt, boss: false };
}

/** Once a frame during play (world time). */
export function updateBlade(dt) {
  if (winding && G.clock - bladeAnim.thrownAt >= WINDUP) release();
  if (!b) return;
  const pos = b.pos;
  if (b.state === 'flying' || b.state === 'falling') {
    if (b.state === 'falling') b.vel.y -= 24 * dt;
    else if (b.travelled > RANGE) b.state = 'falling';
    const step = b.vel.length() * dt, dir = dirV.copy(b.vel).normalize();
    // enemies first: the first one it meets dies and rides the blade to the wall
    const cut = cutAlong(pos, dir, step, b.carry ? ['THROWN'] : ['THROWN', 'PINNED']);
    if (cut && cut.boss) { b.state = 'falling'; b.vel.set(-b.vel.x * 0.2, 4, -b.vel.z * 0.2); } // bounces off the Juggernaut
    else if (cut && !b.carry) {
      const wall = rayWorld(cut.pt, dir, PIN_REACH);
      if (wall < PIN_REACH) { b.carry = cut.s; cut.s.pin = { dir: dir.clone(), at: null }; popup(cut.pt.clone().setY(cut.pt.y + 1), 'PINNED', 'gold'); }
    }
    const tw = rayWorld(pos, dir, step);
    if (tw < step) {
      // stick in the wall (or floor), point first
      pos.addScaledVector(dir, tw);
      b.state = 'stuck'; b.stuckDir = dir.clone(); b.quiver = 1;
      sparks.emit(pos, 16, 5, 3, 2, 0.8, 0.3, 10); sfx.clang(); G.shake = Math.max(G.shake, 0.2);
      if (b.carry) b.carry.pin.at = pos.clone();
    } else { pos.addScaledVector(b.vel, dt); b.travelled += step; }
    b.spin += dt * 30;
  } else if (b.state === 'recall') {
    const hand = handV.set(P.pos.x, P.pos.y + 1.2, P.pos.z);
    const to = hand.clone().sub(pos), d = to.length();
    if (d < 1) { catchIt(); return; }
    to.divideScalar(d);
    const step = Math.min(d, RECALL * dt);
    cutAlong(pos, to, step, ['RECALL']);
    pos.addScaledVector(to, step);
    b.vel.copy(to).multiplyScalar(RECALL);
    b.spin += dt * 36;
  } else if (b.state === 'stuck') {
    if (Math.hypot(P.pos.x - pos.x, P.pos.z - pos.z) < PICKUP && Math.abs(P.pos.y + 1 - pos.y) < 2) { catchIt(); return; }
    if (Math.random() < 0.08) embers(pos, 1, 0.3, 0.3, 0);
  }
  // pose the mesh: spinning on a slight bank while it moves, tip buried and quivering when stuck
  b.outer.position.copy(pos);
  const moving = b.state !== 'stuck';
  if (!moving) {
    b.quiver = Math.max(0, b.quiver - dt * 2.2);
    const q = b.quiver * b.quiver * 0.16 * Math.sin(G.clock * 70);
    b.outer.lookAt(lookV.copy(pos).add(b.stuckDir)); b.spinner.rotation.set(q, Math.PI, q * 0.5); b.outer.position.addScaledVector(b.stuckDir, -0.45);
  } else { b.outer.lookAt(lookV.copy(pos).add(b.vel)); b.outer.rotateZ(0.3); b.spinner.rotation.set(0, b.spin, 0); }
  b.blur.material.opacity = damp(b.blur.material.opacity, moving ? 0.16 : 0, 20, dt);
  b.blur.visible = b.blur.material.opacity > 0.01;
  if (moving && Math.random() < 0.7) sparks.emit(b.tip.getWorldPosition(lookV), 1, 0.4, 2.2, 1.3, 0.6, 0.16, 0); // the tip draws a thin ember spiral
  // a pinned body travels with the blade
  if (b.carry && b.carry.pin && !b.carry.pin.at) b.carry.pinPos = pos.clone();
}
