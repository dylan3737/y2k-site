// Visual juice: the katana trail, shell casings, afterimages, bullet holes and speed lines.
import * as THREE from 'three';
import { scene } from './engine.js';
import { V3, clamp, rand, MOTION } from './util.js';
import { level } from './physics.js';
import { sfx } from './audio.js';
import { G, P } from './state.js';
import { hero } from './hero.js';
import { look } from './style.js';

// ---- katana trail: a ribbon between the blade's base and tip over the last few frames
const TRAIL = 14;
const trail = { base: [], tip: [], geo: new THREE.BufferGeometry(), mesh: null, mat: null };
{
  const pos = new Float32Array(TRAIL * 2 * 3), alpha = new Float32Array(TRAIL * 2), idx = [];
  for (let i = 0; i < TRAIL - 1; i++) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
  trail.geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  trail.geo.setAttribute('alpha', new THREE.BufferAttribute(alpha, 1));
  trail.geo.setIndex(idx);
  trail.mat = new THREE.ShaderMaterial({
    uniforms: { color: { value: new THREE.Color(3.6, 1.5, 0.45) } },
    vertexShader: 'attribute float alpha; varying float vA; void main(){ vA = alpha; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
    fragmentShader: 'uniform vec3 color; varying float vA; void main(){ gl_FragColor = vec4(color * vA, vA); }',
    transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide,
  });
  trail.mesh = new THREE.Mesh(trail.geo, trail.mat); trail.mesh.frustumCulled = false; scene.add(trail.mesh);
}
const bladeBase = new V3(0, -0.12, 0), bladeTip = new V3(0, -1.06, 0);
function updateTrail() {
  const cutting = hero.katana.visible && (P.slashT > 0 || P.dashT > 0);
  if (cutting) {
    hero.katana.updateMatrixWorld(true);
    trail.base.unshift(hero.katana.localToWorld(bladeBase.clone()));
    trail.tip.unshift(hero.katana.localToWorld(bladeTip.clone()));
  } else if (trail.base.length) { trail.base.pop(); trail.tip.pop(); } // let the tail catch up
  trail.base.length = Math.min(trail.base.length, TRAIL); trail.tip.length = Math.min(trail.tip.length, TRAIL);
  const n = trail.base.length, pos = trail.geo.attributes.position.array, alpha = trail.geo.attributes.alpha.array;
  for (let i = 0; i < TRAIL; i++) {
    const k = Math.min(i, n - 1);
    const b = n ? trail.base[k] : bladeBase, t = n ? trail.tip[k] : bladeTip;
    pos.set([b.x, b.y, b.z, t.x, t.y, t.z], i * 6);
    const a = i < n ? (1 - i / TRAIL) ** 1.6 : 0;
    alpha[i * 2] = a * 0.15; alpha[i * 2 + 1] = a * 0.85; // brightest along the edge at the tip
  }
  trail.geo.attributes.position.needsUpdate = true; trail.geo.attributes.alpha.needsUpdate = true;
  trail.mesh.visible = n > 1;
  const e = look.slash || [3.6, 1.5, 0.45];
  trail.mat.uniforms.color.value.setRGB(e[0] * 0.6, e[1] * 0.6, e[2] * 0.6);
}

// ---- shell casings: brass that bounces and tinks
const casingGeo = new THREE.CylinderGeometry(0.018, 0.018, 0.055, 6).rotateZ(Math.PI / 2);
const casingMat = new THREE.MeshStandardMaterial({ color: 0xc8a048, roughness: 0.3, metalness: 1, emissive: 0x3a2200 });
let casings = [];
/** Throw a casing out of a pistol at p, to the hero's `side` (+1 right, -1 left). */
export function ejectCasing(p, side) {
  const m = new THREE.Mesh(casingGeo, casingMat); m.position.copy(p); scene.add(m);
  const yaw = P.yaw, rx = Math.cos(yaw) * side, rz = -Math.sin(yaw) * side;
  casings.push({ m, v: new V3(rx * rand(2, 3.5) + P.vel.x * 0.8, rand(2.5, 4), rz * rand(2, 3.5) + P.vel.z * 0.8), spin: new V3(rand(-20, 20), rand(-20, 20), rand(-20, 20)), t: 0, bounces: 0, floor: groundAt(p) });
  if (casings.length > 48) scene.remove(casings.shift().m);
}
function groundAt(p) {
  let top = level.floorY > -1e3 ? level.floorY : -1e9;
  for (const b of level.boxes) if (p.x > b.min.x && p.x < b.max.x && p.z > b.min.z && p.z < b.max.z && b.max.y <= p.y + 0.1 && b.max.y > top) top = b.max.y;
  return top;
}
function updateCasings(dt) {
  for (let i = casings.length - 1; i >= 0; i--) {
    const c = casings[i]; c.t += dt;
    if (c.t > 4 || c.m.position.y < -100) { scene.remove(c.m); casings.splice(i, 1); continue; }
    if (c.bounces < 3) {
      c.v.y -= 24 * dt; c.m.position.addScaledVector(c.v, dt);
      c.m.rotation.x += c.spin.x * dt; c.m.rotation.y += c.spin.y * dt;
      if (c.m.position.y < c.floor + 0.02) {
        c.m.position.y = c.floor + 0.02; c.v.y = -c.v.y * 0.35; c.v.x *= 0.5; c.v.z *= 0.5; c.spin.multiplyScalar(0.4); c.bounces++;
        if (c.bounces === 1) sfx.tink();
      }
    }
    if (c.t > 3) c.m.scale.setScalar(4 - c.t);
  }
}

// ---- afterimages: fading copies of the hero during a dash-cut or a dive
let ghosts = [], ghostT = 0;
function spawnGhost() {
  const g = hero.body.clone(true);
  const mat = new THREE.MeshBasicMaterial({ color: new THREE.Color(1.4, 0.45, 0.12), transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false });
  const e = look.slash; if (e) mat.color.setRGB(e[0] * 0.4, e[1] * 0.4, e[2] * 0.4);
  g.traverse(o => { if (o.isMesh) { o.material = mat; o.castShadow = false; } if (o.isSprite || o.isLight) o.visible = false; });
  hero.body.updateMatrixWorld(true);
  hero.body.matrixWorld.decompose(g.position, g.quaternion, g.scale);
  scene.add(g);
  ghosts.push({ g, mat, t: 0 });
}
function updateGhosts(dt) {
  if ((P.dashT > 0 || P.diveT > 0) && MOTION > 0.5) { ghostT -= dt; if (ghostT <= 0) { ghostT = P.dashT > 0 ? 0.03 : 0.06; spawnGhost(); } }
  for (let i = ghosts.length - 1; i >= 0; i--) {
    const o = ghosts[i]; o.t += dt;
    o.mat.opacity = 0.35 * (1 - o.t / 0.3);
    if (o.t >= 0.3) { scene.remove(o.g); o.mat.dispose(); ghosts.splice(i, 1); }
  }
}

// ---- bullet holes: hot pockmarks that cool and fade
const holeGeo = new THREE.CircleGeometry(0.07, 10);
const holeMat = new THREE.MeshBasicMaterial({ color: 0x050303, transparent: true, opacity: 0.85, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -16 });
const glowGeo = new THREE.CircleGeometry(0.11, 10);
let holes = [];
/** Leave a hole where a shot hit the world at p, travelling along dir. */
export function bulletHole(p, dir) {
  const n = surfaceNormal(p, dir);
  if (!n) return;
  const hole = new THREE.Mesh(holeGeo, holeMat);
  const glowMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(3, 1.2, 0.3), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -5, polygonOffsetUnits: -20 });
  const glow = new THREE.Mesh(glowGeo, glowMat);
  for (const m of [hole, glow]) { m.position.copy(p).addScaledVector(n, 0.012); m.lookAt(p.clone().add(n)); level.group.add(m); }
  holes.push({ hole, glow, glowMat, t: 0 });
  if (holes.length > 70) { const o = holes.shift(); level.group.remove(o.hole); level.group.remove(o.glow); o.glowMat.dispose(); }
}
/** The face of the box (or floor) that p sits on, as an outward normal. */
function surfaceNormal(p, dir) {
  if (level.floorY > -1e3 && Math.abs(p.y - level.floorY) < 0.03) return new V3(0, 1, 0);
  for (const b of level.boxes) {
    const e = 0.03;
    if (p.x < b.min.x - e || p.x > b.max.x + e || p.y < b.min.y - e || p.y > b.max.y + e || p.z < b.min.z - e || p.z > b.max.z + e) continue;
    const faces = [[Math.abs(p.x - b.min.x), -1, 0, 0], [Math.abs(p.x - b.max.x), 1, 0, 0], [Math.abs(p.y - b.min.y), 0, -1, 0],
      [Math.abs(p.y - b.max.y), 0, 1, 0], [Math.abs(p.z - b.min.z), 0, 0, -1], [Math.abs(p.z - b.max.z), 0, 0, 1]];
    faces.sort((a, c) => a[0] - c[0]);
    const n = new V3(faces[0][1], faces[0][2], faces[0][3]);
    return n.dot(dir) < 0 ? n : null;
  }
  return null;
}
function updateHoles(dt) {
  for (const o of holes) { if (o.t < 2) { o.t += dt; o.glowMat.opacity = Math.max(0, 1 - o.t / 1.2); } }
}
export function clearLook() { for (const o of holes) { o.glowMat.dispose(); } holes = []; }

// ---- speed lines at the screen edges
const canvas = document.createElement('canvas'); canvas.id = 'speedlines';
const ctx = canvas.getContext('2d');
let lineAlpha = 0;
function updateSpeedLines(dt) {
  const hud = document.getElementById('hud');
  if (!canvas.parentNode && hud) hud.prepend(canvas);
  const hv = Math.hypot(P.vel.x, P.vel.z, P.vel.y * 0.5);
  const want = G.mode === 'play' && MOTION > 0.5 ? clamp((hv - 13) / 12, 0, 1) + (P.dashT > 0 ? 0.8 : 0) : 0;
  lineAlpha += (Math.min(1, want) - lineAlpha) * Math.min(1, dt * 10);
  const w = canvas.width = Math.floor(innerWidth / 2), h = canvas.height = Math.floor(innerHeight / 2);
  if (lineAlpha < 0.02) return;
  ctx.strokeStyle = `rgba(255,236,220,${0.28 * lineAlpha})`; ctx.lineWidth = 1.2;
  const cx = w / 2, cy = h / 2, R = Math.hypot(cx, cy);
  ctx.beginPath();
  for (let i = 0; i < 46; i++) {
    const a = Math.random() * Math.PI * 2, r0 = R * rand(0.55, 0.8), r1 = R * 1.05;
    ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); ctx.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1);
  }
  ctx.stroke();
}

/** Once a frame, after the hero is posed. dt is real time (the effects keep moving in slow motion). */
export function updateLook(dt, dtWorld) {
  updateTrail();
  updateCasings(dtWorld);
  updateGhosts(dt);
  updateHoles(dtWorld);
  updateSpeedLines(dt);
}
