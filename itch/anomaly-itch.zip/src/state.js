// All mutable game state lives here so every system reads and writes the same objects.
import { V3 } from './util.js';
import { T, DEFAULT_STAGE } from './config.js';

/** Run-wide state: mode, clock, wave flow, score and screen effects. */
export const G = {
  mode: 'menu',          // 'menu' | 'play' | 'paused' | 'dead'
  clock: 0,
  timeScale: 1,          // world speed; below 1 during bullet time and dives
  focusActive: false,
  beatT: 0,
  startStage: DEFAULT_STAGE,
  // waves
  wave: 0,
  toSpawn: 0,
  maxAlive: 3,
  spawnTimer: 0,
  waveGap: 0,
  bossPending: false,
  waveStartT: 0,
  waveHurt: false,
  // score
  score: 0,
  kills: 0,
  combo: 0,
  lastKill: -99,
  lives: T.startLives,
  continuesLeft: T.maxContinues,
  hellfire: T.startHellfire,
  nextLifeAt: T.firstExtraLife,
  // feel
  hitStop: 0,
  flash: 0,
  shake: 0,
  hurtFlash: 0,
  camDist: 3.4,
  parryT: 0,             // real seconds of perfect-parry slow motion left
  finalT: 0,             // real seconds of last-kill slow motion left
  hints: { basics: false, hellfire: false, city: false, dash: false },
};

function playerDefaults() {
  return {
    grounded: false, lastGround: 0, airJumps: 1,
    wall: null, wallCd: 0, climb: null, climbLeft: T.climbTime, climbCd: 0,
    slideT: 0, diveT: 0, diveAge: 0, diveCd: 0, flip: false, surf: null,
    hp: 100, focus: 100, lastHurt: -99, invT: 0,
    eye: 1.62, roll: 0, bob: 0, yaw: 0, pitch: -0.12,
    ammo: T.magSize, reloadT: 0, fireCd: 0, side: 0, power: null, powerT: 0,
    slashT: 0, slashCd: 0, slashDir: 1, slashTilt: 0, swordT: 0, slashStep: 0, lastSlashAt: -9,
    chargeT: 0, chargeReady: false, dashT: 0, dashCd: 0, dashV: new V3(),
  };
}

/** The player's body and ability state. */
export const P = { pos: new V3(0, 3, 0), vel: new V3(), safe: new V3(0, 3, 0), r: 0.36, h: 1.8, ...playerDefaults() };

export function resetPlayer(start) {
  Object.assign(P, playerDefaults());
  P.pos.copy(start); P.safe.copy(start); P.vel.set(0, 0, 0);
}

/** Held and queued input from keyboard, mouse and gamepad. */
export const input = {
  fire: false, focus: false, focusToggle: false,
  jump: false, dive: false,
  slashHeld: false,
  touch: { x: 0, y: 0 }, // the on-screen joystick
  move: { forward: false, back: false, left: false, right: false }, // held movement actions (keyboard)
  pad: { on: false, x: 0, y: 0, fire: false, focus: false, slash: false },
  mouseAt: 0, // performance.now() of the last mouse move during play (for the "click to aim" prompt)
};
export const firing = () => input.fire || input.pad.fire;

/** Live actors. Arrays are replaced when filtered, so always read them through this object. */
export const world = { soldiers: [], bullets: [], pickups: [], barrels: [], drones: [] };
