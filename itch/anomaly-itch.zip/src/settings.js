// Player settings: graphics, sound and controls. Saved in this browser; other modules read `settings` live
// and anything with a side effect (render quality, volumes) subscribes with onSettingsChange.
import { store } from './util.js';

/** Every setting, in the order the settings page shows them. */
export const SCHEMA = [
  { group: 'Graphics', key: 'quality', label: 'Quality', type: 'choice', options: ['low', 'medium', 'high'], labels: ['Low', 'Medium', 'High'], def: 'high',
    note: 'Resolution, anti-aliasing, shadows and bloom' },
  { group: 'Graphics', key: 'fov', label: 'Field of view', type: 'range', min: 65, max: 100, step: 1, def: 78, fmt: v => v + '°' },
  { group: 'Graphics', key: 'shake', label: 'Screen shake', type: 'choice', options: ['off', 'low', 'full'], labels: ['Off', 'Low', 'Full'], def: 'full' },
  { group: 'Graphics', key: 'killcam', label: 'Final-kill camera', type: 'choice', options: ['off', 'on'], labels: ['Off', 'On'], def: 'on' },
  { group: 'Graphics', key: 'crt', label: 'CRT filter', type: 'choice', options: ['off', 'on'], labels: ['Off', 'On'], def: 'off' },
  { group: 'Sound', key: 'master', label: 'Master volume', type: 'range', min: 0, max: 100, step: 5, def: 80, fmt: v => v + '%' },
  { group: 'Sound', key: 'music', label: 'Music', type: 'range', min: 0, max: 100, step: 5, def: 70, fmt: v => v + '%' },
  { group: 'Sound', key: 'effects', label: 'Effects', type: 'range', min: 0, max: 100, step: 5, def: 100, fmt: v => v + '%' },
  { group: 'Sound', key: 'announcer', label: 'Announcer', type: 'choice', options: ['off', 'on'], labels: ['Off', 'On'], def: 'on' },
  { group: 'Controls', key: 'mouseSens', label: 'Mouse sensitivity', type: 'range', min: 0.25, max: 3, step: 0.05, def: 1, fmt: v => v.toFixed(2) + '×' },
  { group: 'Controls', key: 'padSens', label: 'Stick sensitivity', type: 'range', min: 0.25, max: 3, step: 0.05, def: 1, fmt: v => v.toFixed(2) + '×' },
  { group: 'Controls', key: 'invertY', label: 'Invert look', type: 'choice', options: ['off', 'on'], labels: ['Off', 'On'], def: 'off' },
  { group: 'Controls', key: 'rumble', label: 'Controller rumble', type: 'range', min: 0, max: 100, step: 10, def: 50, fmt: v => (v ? v + '%' : 'Off') },
];
const DEFAULTS = Object.fromEntries(SCHEMA.map(s => [s.key, s.def]));
export const SHAKE = { off: 0, low: 0.45, full: 1 };

function load() {
  let saved = {};
  try { saved = JSON.parse(store.get('settings', '{}')) || {}; } catch { /* corrupt: defaults */ }
  // carry over the older one-off switches
  if (saved.quality == null && store.get('gfx')) saved.quality = store.get('gfx');
  if (saved.crt == null && store.get('crt')) saved.crt = store.get('crt') === 'on' ? 'on' : 'off';
  if (saved.announcer == null && store.get('voice')) saved.announcer = store.get('voice') === 'off' ? 'off' : 'on';
  const s = { ...DEFAULTS };
  for (const def of SCHEMA) {
    const v = saved[def.key];
    if (def.type === 'choice' && def.options.includes(v)) s[def.key] = v;
    if (def.type === 'range' && typeof v === 'number' && v >= def.min && v <= def.max) s[def.key] = v;
  }
  return s;
}

export const settings = load();
const listeners = [];
export const onSettingsChange = fn => { listeners.push(fn); };
function save() { store.set('settings', JSON.stringify(settings)); }

export function setSetting(key, value) {
  if (settings[key] === value) return;
  settings[key] = value; save();
  for (const fn of listeners) fn(key, value);
}
export function resetSettings() {
  for (const def of SCHEMA) settings[def.key] = def.def;
  save();
  for (const fn of listeners) fn('*');
}
