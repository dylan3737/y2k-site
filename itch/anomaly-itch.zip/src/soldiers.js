// Elite soldiers: models, AI, shooting and corpses. Their bullets fly in bullets.js; the Juggernaut's AI is in boss.js.
import * as THREE from 'three';
import { scene } from './engine.js';
import { V3, rand, clamp, damp, lerpAngle, tmpA, tmpB } from './util.js';
import { SM, gunMat, bootMat, outlineMat, addOutline } from './materials.js';
import { level, moveBody, rayWorld, groundBelow } from './physics.js';
import { sparks, embers, splat } from './fx.js';
import { mergeRigidParts } from './merge.js';
import { sfx } from './audio.js';
import { T, difficulty } from './config.js';
import { G, P, world } from './state.js';
import { killSoldier } from './combat.js';
import { spawnBullet } from './bullets.js';
import { updateBoss, bossIntro } from './boss.js';

// ---- model: a jointed operator in fatigues, plate carrier and helmet, rifle held two-handed
const HIP_Y = 0.95, THIGH = 0.45, SHIN = 0.43, SHOULDER_Y = 1.46, UPPER_ARM = 0.31, FOREARM = 0.29;
/** Soldier types: how fast they move, how tough they are, the range band they like to fight at. */
export const KINDS = {
  grunt: { speed: 4.6, hp: 1, near: 7, far: 19, vest: 'vest', visor: 'visor' },
  rusher: { speed: 7.2, hp: 0.8, near: 3.2, far: 7, vest: 'rusherVest', visor: 'rusherVisor' },
  sniper: { speed: 3.4, hp: 0.7, near: 18, far: 38, vest: 'sniperVest', visor: 'sniperVisor' },
  shield: { speed: 3.3, hp: 1.3, near: 4, far: 12, vest: 'riotVest', visor: 'riotVisor' },
};
const SNIPE_CHARGE = 1.3; // seconds the laser paints you before the shot

function buildModel(boss, kind = 'grunt') {
  const K = KINDS[kind];
  const g = new THREE.Group();
  const add = (geo, mat, x, y, z, parent = g) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; parent.add(m); return m; };
  const box = (w, h, d, mat, x, y, z, parent = g) => add(new THREE.BoxGeometry(w, h, d), mat, x, y, z, parent);
  const joint = (parent, x, y, z = 0) => { const j = new THREE.Group(); j.position.set(x, y, z); parent.add(j); return j; };
  const capsule = (r, len) => new THREE.CapsuleGeometry(r, len, 5, 12);

  // legs: hip → knee → boot, with knee pads
  const pelvis = joint(g, 0, HIP_Y);
  const legs = [-1, 1].map(side => {
    const hip = joint(pelvis, side * 0.11, 0);
    add(capsule(0.085, THIGH - 0.14), SM.fatigue, 0, -THIGH / 2, 0, hip);
    const knee = joint(hip, 0, -THIGH);
    box(0.13, 0.13, 0.07, SM.pad, 0, -0.02, 0.07, knee);
    add(capsule(0.068, SHIN - 0.12), SM.fatigue, 0, -SHIN / 2, 0, knee);
    const ankle = joint(knee, 0, -SHIN);
    box(0.13, 0.12, 0.29, bootMat, 0, -0.02, 0.045, ankle);
    return { hip, knee, ankle };
  });

  // torso: belt, fatigue shirt, plate carrier with magazine pouches, shoulders
  box(0.34, 0.16, 0.22, SM.fatigue, 0, 0, 0, pelvis);
  box(0.36, 0.06, 0.24, SM.pad, 0, HIP_Y + 0.08, 0); // battle belt
  add(capsule(0.17, 0.22), SM.fatigue, 0, 1.27, 0).scale.set(1.22, 1, 0.8);
  box(0.42, 0.44, 0.33, SM[K.vest], 0, 1.28, 0.005);
  for (const x of [-0.13, 0, 0.13]) box(0.1, 0.13, 0.06, SM.pad, x, 1.16, 0.185);
  box(0.26, 0.12, 0.05, SM.pad, 0, 1.4, 0.18); // admin pouch
  add(capsule(0.08, 0.32), SM.fatigue, 0, SHOULDER_Y - 0.02, 0).rotation.z = Math.PI / 2;

  // head: balaclava, rounded helmet with a brim, glowing goggle band, headset, night-vision mount
  add(new THREE.CylinderGeometry(0.055, 0.06, 0.1, 10), SM.balaclava, 0, 1.56, 0);
  const head = joint(g, 0, 1.6);
  add(new THREE.SphereGeometry(0.108, 14, 12), SM.balaclava, 0, 0.12, 0, head).scale.set(0.92, 1.1, 1);
  add(new THREE.SphereGeometry(0.135, 18, 10, 0, Math.PI * 2, 0, Math.PI * 0.52), SM.helmet, 0, 0.14, -0.005, head).scale.set(1, 0.95, 1.05);
  add(new THREE.CylinderGeometry(0.14, 0.143, 0.025, 20), SM.helmet, 0, 0.145, -0.005, head);
  const visor = add(new THREE.CylinderGeometry(0.112, 0.112, 0.055, 18, 1, true, -0.95, 1.9), boss ? SM.bossVisor : SM[K.visor], 0, 0.125, 0, head);
  visor.userData.noOutline = true;
  box(0.05, 0.05, 0.05, SM.pad, 0, 0.21, 0.13, head);
  for (const x of [-0.115, 0.115]) add(new THREE.CylinderGeometry(0.045, 0.045, 0.04, 12), SM.pad, x, 0.1, 0, head).rotation.z = Math.PI / 2;

  // arms: shoulder → elbow → glove
  const arms = [-1, 1].map(side => {
    const shoulder = joint(g, side * 0.25, SHOULDER_Y);
    add(capsule(0.066, UPPER_ARM - 0.13), SM.fatigue, 0, -UPPER_ARM / 2, 0, shoulder);
    const elbow = joint(shoulder, 0, -UPPER_ARM);
    add(capsule(0.058, FOREARM - 0.11), SM.fatigue, 0, -FOREARM / 2, 0, elbow);
    const hand = joint(elbow, 0, -FOREARM);
    add(new THREE.SphereGeometry(0.048, 10, 8), SM.pad, 0, -0.02, 0, hand).scale.set(0.9, 1.2, 1);
    return { shoulder, elbow, hand };
  });

  // rifle in the right hand, barrel running down the forearm so it points wherever the arm aims
  const rifle = joint(arms[1].hand, 0, -0.03, 0.03);
  let muzzle;
  if (kind === 'rusher') {
    // pump shotgun: short and fat
    box(0.06, 0.3, 0.085, gunMat, 0, -0.1, 0, rifle);
    add(new THREE.CylinderGeometry(0.026, 0.026, 0.28, 10), gunMat, 0, -0.36, 0.02, rifle);
    box(0.06, 0.12, 0.07, SM.pad, 0, -0.33, -0.03, rifle);                                // pump
    box(0.05, 0.22, 0.08, gunMat, 0, 0.14, -0.01, rifle);
    muzzle = joint(rifle, 0, -0.5, 0.02);
  } else if (kind === 'sniper') {
    // long rifle with a big scope
    box(0.055, 0.44, 0.08, gunMat, 0, -0.14, 0, rifle);
    add(new THREE.CylinderGeometry(0.014, 0.014, 0.5, 8), gunMat, 0, -0.6, 0.01, rifle);
    add(new THREE.CylinderGeometry(0.03, 0.03, 0.26, 10), gunMat, 0, -0.12, 0.08, rifle);  // scope
    box(0.05, 0.24, 0.09, gunMat, 0, 0.15, -0.01, rifle);
    muzzle = joint(rifle, 0, -0.86, 0.01);
  } else {
    box(0.06, kind === 'shield' ? 0.26 : 0.4, 0.09, gunMat, 0, -0.14, 0, rifle);          // receiver + handguard
    add(new THREE.CylinderGeometry(0.016, 0.016, 0.24, 8), gunMat, 0, kind === 'shield' ? -0.36 : -0.46, 0.01, rifle);
    box(0.045, 0.09, 0.15, gunMat, 0, -0.1, -0.08, rifle);                                  // magazine
    box(0.05, 0.22, 0.08, gunMat, 0, 0.14, -0.01, rifle);                                   // stock, back toward the shoulder
    box(0.04, 0.1, 0.05, gunMat, 0, -0.08, 0.07, rifle);                                    // optic
    muzzle = joint(rifle, 0, kind === 'shield' ? -0.5 : -0.6, 0.01);
  }
  let shield = null;
  if (kind === 'shield') {
    // riot shield carried square in front: covers the body, leaves the head
    shield = joint(g, -0.08, 0.98, 0.4);
    box(0.62, 1.05, 0.04, SM.shield, 0, 0, 0, shield);
    box(0.4, 0.16, 0.045, SM.shieldGlass, 0, 0.3, 0, shield).userData.noOutline = true;
    box(0.64, 0.035, 0.05, SM.shieldStripe, 0, -0.1, 0, shield);
    box(0.64, 0.035, 0.05, SM.shieldStripe, 0, 0.1, 0, shield);
  }

  const plates = [];
  if (boss) {
    // Juggernaut: pauldrons, a heavy chest plate and a face plate (shot off in this order)
    for (const x of [-0.33, 0.33]) { const m = add(new THREE.SphereGeometry(0.13, 12, 8), SM.bossPlate, x, SHOULDER_Y + 0.02, 0); m.scale.set(1.2, 0.8, 1.2); plates.push(m); }
    plates.push(box(0.5, 0.48, 0.38, SM.bossPlate, 0, 1.28, 0.01));
    plates.push(box(0.2, 0.13, 0.05, SM.bossPlate, 0, 0.03, 0.1, head));
  }
  g.rotation.order = 'YXZ';
  g.traverse(o => { if (o.isMesh) o.receiveShadow = false; });
  for (const p of plates) p.userData.keep = true; // armour plates fly off one at a time
  mergeRigidParts(g); // ~70 meshes down to a couple per joint
  addOutline(g, outlineMat.soldier, 0.015);
  return {
    model: g, head, muzzle, rifle, pelvis, shield, plates, ankleL: legs[0].ankle, ankleR: legs[1].ankle,
    legL: legs[0].hip, legR: legs[1].hip, kneeL: legs[0].knee, kneeR: legs[1].knee,
    armL: arms[0].shoulder, armR: arms[1].shoulder, elbowL: arms[0].elbow, elbowR: arms[1].elbow,
  };
}

/** Rifle up at the target (aimX = shoulder pitch), or held at low ready. The left hand supports the handguard. */
export function poseRifle(s, aimX, aiming, dt, sway = 0) {
  const kick = (s.kick || 0) ** 2 * 0.22 + (s.flinch || 0) * 0.35; // muzzle climbs with each shot, jerks up when hit
  s.armR.rotation.x = damp(s.armR.rotation.x, (aiming ? aimX : -0.55 + sway) - kick, aiming ? 16 : 10, dt);
  s.elbowR.rotation.x = damp(s.elbowR.rotation.x, aiming ? -0.05 - kick * 0.5 : -1.0, 12, dt);
  if (s.kind === 'shield') {
    s.armL.rotation.x = damp(s.armL.rotation.x, -0.95 - kick * 0.3, 10, dt);
    s.armL.rotation.z = damp(s.armL.rotation.z, 0.25, 10, dt);
    s.elbowL.rotation.x = damp(s.elbowL.rotation.x, -1.25, 10, dt);
    return;
  }
  s.armL.rotation.x = damp(s.armL.rotation.x, (aiming ? aimX + 0.3 : -0.45 + sway) - kick, aiming ? 16 : 10, dt);
  s.armL.rotation.z = damp(s.armL.rotation.z, 0.55, 12, dt);
  s.elbowL.rotation.x = damp(s.elbowL.rotation.x, aiming ? -0.8 : -1.1, 12, dt);
}

const laserGeo = new THREE.CylinderGeometry(0.01, 0.01, 1, 6); laserGeo.rotateX(Math.PI / 2); laserGeo.translate(0, 0, 0.5);

/** opts: { y, spawnT (seconds of flare before they appear), boss, idle (title-screen dummy), kind } */
export function makeSoldier(x, z, opts = {}) {
  const kind = opts.boss ? 'grunt' : opts.kind || 'grunt';
  const parts = buildModel(!!opts.boss, kind);
  const s = {
    ...parts,
    pos: new V3(x, opts.y || 0, z), vel: new V3(), knock: new V3(), r: 0.34, h: 1.9, scale: 1,
    hp: 100, maxHp: 100, dead: false, deathT: 0, surfed: false, surfAgain: 0,
    spawnT: opts.spawnT || 0, idle: !!opts.idle, boss: !!opts.boss,
    fireCd: rand(1.4, 2.6),
    strafeDir: 1, strafeT: 0, los: false, losT: 0, stuck: 0, edgeCd: 0,
    dodgeT: 0, dodgeCd: rand(0.5, 2), dodgeDir: new V3(), phase: Math.random() * 6,
    kind, charge: 0, laser: null,
    amp: 0, legYaw: 0, lastVel: new V3(), accF: 0, accR: 0, kick: 0, flinch: 0, hitDir: new V3(), breathT: Math.random() * 6,
    stagger: 0, headSnap: 0, // seconds left reeling from a hit; a headshot's snap-back (1 → 0)
  };
  s.hp = s.maxHp = Math.round((s.idle ? 100 : difficulty(G.wave).hp) * KINDS[kind].hp);
  if (G.daily && G.daily.mod === 'glass' && !opts.boss) s.hp = s.maxHp = 1; // glass: anything kills them
  if (kind === 'sniper') {
    const mat = new THREE.MeshBasicMaterial({ color: new THREE.Color(3, 0.35, 0.12), transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false });
    s.laser = new THREE.Mesh(laserGeo, mat); s.laser.visible = false; scene.add(s.laser);
  }
  if (s.boss) {
    Object.assign(s, { scale: 1.6, r: 0.55, h: 3, fireCd: 2.5 });
    s.hp = s.maxHp = 1400 + G.wave * 100;
    s.model.scale.setScalar(1.6);
    s.armor = s.plates.map(mesh => ({ mesh, hp: 150 + G.wave * 12 }));
    if (G.daily && G.daily.mod === 'glass') { s.hp = s.maxHp = Math.round(s.maxHp / 4); for (const a of s.armor) a.hp = 1; }
    s.bs = { state: 'walk', t: 0, cd: 2.5, n: 0, dir: new V3(), sweep: 1, wave: null };
  }
  s.model.position.copy(s.pos); s.model.visible = s.spawnT <= 0;
  scene.add(s.model);
  world.soldiers.push(s);
  return s;
}
export function clearSoldiers() { for (const s of world.soldiers) removeSoldierModel(s); world.soldiers = []; }
export const isLive = s => !s.dead && s.spawnT <= 0 && !s.idle;

export function hasLineOfSight(s) {
  tmpA.set(s.pos.x, s.pos.y + 1.7, s.pos.z);
  tmpB.set(P.pos.x, P.pos.y + P.eye, P.pos.z).sub(tmpA);
  const d = tmpB.length(); tmpB.divideScalar(d);
  return rayWorld(tmpA, tmpB, d) >= d - 0.3;
}

/** A riot shield stops body hits coming at its front (headshots clear the top of it). */
export function shieldBlocks(s, dir, head) {
  if (s.kind !== 'shield' || head || s.dead) return false;
  const f = s.model.rotation.y, l = Math.hypot(dir.x, dir.z) || 1;
  return (dir.x * Math.sin(f) + dir.z * Math.cos(f)) / l < -0.4;
}


/** Fire at the player. pellets/cone make a shotgun blast; aim scales the spread (sniper rounds are near-perfect). */
export function shoot(s, dist, { pellets = 1, cone = 0, speed = T.enemyBulletSpeed, dmg = 1, aim = 1 } = {}) {
  s.model.updateMatrixWorld(true);
  const muzzle = s.muzzle.getWorldPosition(new V3());
  const target = new V3(P.pos.x, P.pos.y + 1.2, P.pos.z).addScaledVector(P.vel, (dist / speed) * 0.55);
  const spread = (0.25 + dist * 0.025) * aim * difficulty(G.wave).aim * (G.blackout ? 2.4 : 1); // blackout: they can barely see you
  target.x += rand(-1, 1) * spread; target.y += rand(-0.6, 0.6) * spread; target.z += rand(-1, 1) * spread;
  const dir = target.sub(muzzle).normalize();
  for (let i = 0; i < pellets; i++) {
    const d = dir.clone();
    if (cone) { d.x += rand(-cone, cone); d.y += rand(-cone, cone) * 0.5; d.z += rand(-cone, cone); d.normalize(); }
    spawnBullet(muzzle, d.multiplyScalar(speed), dmg);
  }
  sparks.emit(muzzle, 10, 3, 3.2, 1.8, 0.6, 0.12, 0);
  s.kick = 1;
  sfx.enemyShot(clamp(9 / (dist + 4), 0.08, 0.9), 0.45 + 0.55 * G.timeScale);
}


// ---- death: a staged, directional fall
const easeIn = t => t * t;
/** Timing per kind of kill: stagger before falling, fall duration, how far the knees buckle and the hips drop. */
const DEATH = {
  shot: { stagger: 0.26, fall: 0.44, knees: 1.0, drop: 0.14 },
  head: { stagger: 0.05, fall: 0.36, knees: 1.5, drop: 0.3 },
  crush: { stagger: 0, fall: 0.28, knees: 1.7, drop: 0.45 },
  blast: { stagger: 0, fall: 0.34, knees: 0.6, drop: 0 },
};

/**
 * Start a soldier's death. kind: 'shot' | 'head' | 'crush' | 'blast'.
 * impact is the horizontal direction the killing blow pushed; the body falls that way.
 */
export function beginDeath(s, kind, impact) {
  Object.assign(s, { dead: true, deathT: 0, h: 0.35, deathKind: kind, bounced: false, pool: null, headLoll: rand(-0.6, 0.6) });
  s.model.rotation.order = 'YXZ';
  s.pelvis.rotation.y = 0; s.model.rotation.z = 0;
  if (s.laser) s.laser.visible = false;
  const face = s.model.rotation.y, fx = Math.sin(face), fz = Math.cos(face);
  const along = impact.x * fx + impact.z * fz;   // + means pushed forward (from behind)
  const across = impact.x * fz - impact.z * fx;  // + means pushed toward the model's +x side
  if (Math.abs(along) >= Math.abs(across) * 0.8) { s.fallAxis = 'x'; s.fallSign = along < 0 ? 1 : -1; } // 1 = onto his back
  else { s.fallAxis = 'z'; s.fallSign = across > 0 ? -1 : 1; }
  // drop the rifle: it tumbles away on its own
  s.model.updateMatrixWorld(true);
  scene.attach(s.rifle);
  s.droppedRifle = {
    obj: s.rifle, rest: false, ground: s.pos.y,
    vel: new V3(impact.x * 2 + rand(-1, 1), 2.5, impact.z * 2 + rand(-1, 1)),
    spin: new V3(rand(-7, 7), rand(-7, 7), rand(-7, 7)),
  };
}

/** Where the torso ends up once the body is lying down (for the blood pool). */
function restingChest(s) {
  const face = s.model.rotation.y, fx = Math.sin(face), fz = Math.cos(face), reach = 0.9 * s.scale;
  const [dx, dz] = s.fallAxis === 'x' ? [-fx * s.fallSign, -fz * s.fallSign] : [fz * -s.fallSign, -fx * -s.fallSign];
  return new V3(s.pos.x + dx * reach, s.pos.y, s.pos.z + dz * reach);
}

function updateDroppedRifle(s, dt) {
  const r = s.droppedRifle;
  if (!r || r.rest) return;
  r.vel.y -= T.gravity * dt;
  r.obj.position.addScaledVector(r.vel, dt);
  r.obj.rotation.x += r.spin.x * dt; r.obj.rotation.y += r.spin.y * dt; r.obj.rotation.z += r.spin.z * dt;
  if (r.obj.position.y <= r.ground + 0.06) {
    r.rest = true;
    r.obj.position.y = r.ground + 0.06;
    r.obj.rotation.order = 'YXZ'; r.obj.rotation.set(Math.PI / 2, rand(0, Math.PI * 2), 0); // lying flat
    sfx.clatter();
  }
}

/** Remove a soldier's model (and the rifle he dropped) from the scene. */
export function removeSoldierModel(s) {
  scene.remove(s.model);
  if (s.laser) scene.remove(s.laser);
  if (s.droppedRifle) scene.remove(s.droppedRifle.obj);
}

function updateCorpse(s, dt) {
  s.deathT += dt;
  updateDroppedRifle(s, dt);
  if (s.pin) {
    // pinned by a thrown katana: slumped against the wall with the blade through the chest (or riding the blade there)
    const p = s.pin.at || s.pinPos;
    if (p) {
      const d = s.pin.dir;
      s.pos.set(p.x - d.x * 0.3, p.y - 1.25 * s.scale, p.z - d.z * 0.3);
      s.model.position.copy(s.pos);
      s.model.rotation.set(0.14, Math.atan2(-d.x, -d.z), 0);
      s.vel.set(0, 0, 0);
      s.kneeL.rotation.x = damp(s.kneeL.rotation.x, 0.5, 8, dt); s.kneeR.rotation.x = damp(s.kneeR.rotation.x, 0.7, 8, dt);
      s.legL.rotation.x = damp(s.legL.rotation.x, -0.2, 8, dt); s.legR.rotation.x = damp(s.legR.rotation.x, -0.3, 8, dt);
      s.armL.rotation.x = damp(s.armL.rotation.x, 0.15, 8, dt); s.armR.rotation.x = damp(s.armR.rotation.x, 0.1, 8, dt);
      s.armL.rotation.z = damp(s.armL.rotation.z, 0.35, 8, dt); s.armR.rotation.z = damp(s.armR.rotation.z, -0.35, 8, dt);
      s.head.rotation.x = damp(s.head.rotation.x, 0.7, 6, dt);
    }
    if (s.deathT > 11.5) { removeSoldierModel(s); s.remove = true; }
    return;
  }
  if (s.pool && s.pool.scale.x < s.poolSize) s.pool.scale.multiplyScalar(1 + dt * 0.35); // blood spreads
  if (s.surfed) return; // the player is riding it; player.js positions it

  s.vel.y -= T.gravity * dt;
  if (moveBody(s, dt)) { s.vel.x *= 1 - Math.min(1, 5 * dt); s.vel.z *= 1 - Math.min(1, 5 * dt); }

  // tilt: a small stagger, an accelerating fall, then a little bounce as the body lands
  const d = DEATH[s.deathKind], t = s.deathT, lean = d.stagger > 0 ? 0.14 : 0;
  let tilt;
  if (t < d.stagger) tilt = lean * Math.sin(t / d.stagger * Math.PI / 2);
  else {
    const k = Math.min(1, (t - d.stagger) / d.fall);
    tilt = lean + (Math.PI / 2 - lean) * easeIn(k);
    const after = t - d.stagger - d.fall;
    if (after >= 0) {
      if (after < 0.25) tilt -= 0.09 * Math.sin(after / 0.25 * Math.PI);
      if (!s.bounced) {
        s.bounced = true;
        sfx.thud();
        s.pool = splat(restingChest(s), 0.15 * s.scale); s.poolSize = rand(0.45, 0.65) * s.scale;
      }
    }
  }
  const lying = Math.min(1, tilt / (Math.PI / 2));
  const drop = d.drop * s.scale * (1 - lying) * Math.min(1, t / 0.2); // knees buckling lowers the hips first
  const sink = s.deathT > 10 ? (s.deathT - 10) * 0.5 : 0;
  s.model.position.set(s.pos.x, s.pos.y + 0.16 * s.scale * lying - drop - sink, s.pos.z);
  if (s.fallAxis === 'x') { s.model.rotation.x = -tilt * s.fallSign; s.model.rotation.z = 0; }
  else { s.model.rotation.z = tilt * s.fallSign; s.model.rotation.x = 0; }

  // limbs: knees buckle and arms fling while falling; then a loose sprawl with one knee up
  const down = tilt > 1.25, onBack = s.fallAxis === 'x' && s.fallSign === 1;
  const r = down ? 5 : 12;
  s.kneeL.rotation.x = damp(s.kneeL.rotation.x, down ? 0.35 : d.knees, r, dt);
  s.kneeR.rotation.x = damp(s.kneeR.rotation.x, down ? 1.05 : d.knees * 0.8, r, dt);
  s.legL.rotation.x = damp(s.legL.rotation.x, down ? 0.1 : -0.45 * d.knees, r, dt);
  s.legR.rotation.x = damp(s.legR.rotation.x, down ? -0.2 : -0.4 * d.knees, r, dt);
  s.legL.rotation.z = damp(s.legL.rotation.z, down ? -0.22 : -0.08, r, dt);
  s.legR.rotation.z = damp(s.legR.rotation.z, down ? 0.26 : 0.08, r, dt);
  const armX = down ? (onBack ? -2.7 : -0.3) : (onBack ? -2.2 : -1.0);
  s.armL.rotation.x = damp(s.armL.rotation.x, armX, 8, dt); s.armR.rotation.x = damp(s.armR.rotation.x, armX + 0.3, 8, dt);
  s.armL.rotation.z = damp(s.armL.rotation.z, down ? 0.9 : 0.6, 8, dt); s.armR.rotation.z = damp(s.armR.rotation.z, down ? -0.8 : -0.5, 8, dt);
  s.elbowL.rotation.x = damp(s.elbowL.rotation.x, down ? -0.4 : -0.7, 8, dt); s.elbowR.rotation.x = damp(s.elbowR.rotation.x, down ? -0.9 : -0.3, 8, dt);
  // the head snaps with the hit, then lolls to one side
  s.head.rotation.x = damp(s.head.rotation.x, down ? 0.2 * s.fallSign : (t < 0.15 ? -0.5 : 0.35) * s.fallSign, 14, dt);
  s.head.rotation.z = damp(s.head.rotation.z, down ? s.headLoll : 0, 4, dt);
  s.head.rotation.y = damp(s.head.rotation.y, down ? s.headLoll * 0.6 : 0, 4, dt);

  if (s.deathT > 11.5 || s.pos.y < level.info.killY) { removeSoldierModel(s); s.remove = true; }
}

// ---- AI

// ---- movement animation
const smooth = t => t * t * (3 - 2 * t);
const wrapAngle = a => Math.atan2(Math.sin(a), Math.cos(a));
/** One leg's gait: heel strike at π/2, stance through π, toe-off at 3π/2. */
function gaitLeg(p, amp) {
  const sn = Math.sin(p);
  return {
    hip: -0.42 * sn * amp,
    knee: amp * (0.14 * Math.max(0, -Math.cos(p)) + 0.75 * Math.max(0, Math.cos(p + 0.35)) ** 1.5),
    toe: amp * (0.35 * Math.max(0, -sn) ** 3 - 0.2 * Math.max(0, sn) ** 4),
  };
}

/**
 * Legs, hips and balance for a live soldier. The pelvis turns toward the direction of travel (and walks
 * backwards when he backs off), so strafing and retreating step properly instead of sliding.
 */
export function animateSoldierBody(s, dt, aiming, dist, dy) {
  const face = s.model.rotation.y, sf = Math.sin(face), cf = Math.cos(face);
  const vf = s.vel.x * sf + s.vel.z * cf, vr = s.vel.x * cf - s.vel.z * sf, sp = Math.hypot(vf, vr);
  const inv = 1 / Math.max(dt, 1e-3), ax = (s.vel.x - s.lastVel.x) * inv, az = (s.vel.z - s.lastVel.z) * inv;
  s.lastVel.copy(s.vel);
  s.accF = damp(s.accF, clamp(ax * sf + az * cf, -30, 30), 6, dt);
  s.accR = damp(s.accR, clamp(ax * cf - az * sf, -30, 30), 6, dt);

  // which way the legs face, and whether the cycle runs backwards
  let yaw = 0, dir = 1;
  if (sp > 0.4 && s.dodgeT <= 0) {
    yaw = Math.atan2(vr, vf);
    if (Math.abs(yaw) > 1.75) { yaw = wrapAngle(yaw + Math.PI); dir = -1; }
    yaw = clamp(yaw, -1.15, 1.15);
  }
  s.legYaw = damp(s.legYaw, yaw, 8, dt);
  s.pelvis.rotation.y = s.legYaw;
  s.amp = damp(s.amp, s.dodgeT > 0 ? 0 : clamp(sp / 3, 0, 1), 9, dt);
  if (sp > 0.3 && s.dodgeT <= 0) s.phase += dir * dt * (3.6 + sp * 0.95) * (s.boss ? 0.78 : 1);
  const A = s.amp, ph = s.phase;
  const gl = gaitLeg(ph, A), gr = gaitLeg(ph + Math.PI, A);

  // stance: knees bent and weight forward while aiming (a tactical glide); relaxed otherwise; buckling when staggered
  const reel = smooth(clamp(s.stagger / 0.35, 0, 1));
  const bent = (aiming ? 0.24 : 0.1) + reel * 0.32, idle = 1 - A;
  s.breathT += dt;
  const breath = Math.sin(s.breathT * 1.6);
  const legs = [[s.legL, s.kneeL, s.ankleL, gl, -1], [s.legR, s.kneeR, s.ankleR, gr, 1]];
  for (const [hip, knee, ankle, g, side] of legs) {
    const relax = idle * (side > 0 ? 0.1 : 0); // weight on the left leg when standing
    const h = g.hip - bent * 0.55 - relax * 0.5, k = g.knee + bent + relax;
    hip.rotation.x = damp(hip.rotation.x, h, 16, dt);
    knee.rotation.x = damp(knee.rotation.x, k, 16, dt);
    hip.rotation.z = damp(hip.rotation.z, side * (0.05 + (s.dodgeT > 0 ? 0.35 : 0)), 12, dt);
    ankle.rotation.x = clamp(-(hip.rotation.x + knee.rotation.x + s.model.rotation.x) + g.toe, -0.6, 0.9);
  }

  // body: bob over the planted foot, lean with acceleration, bank into a dodge, rock back when hit
  s.kick = Math.max(0, s.kick - dt * 7);
  s.flinch = Math.max(0, s.flinch - dt * 5);
  s.headSnap = Math.max(0, s.headSnap - dt * 4);
  const hitF = s.hitDir.x * sf + s.hitDir.z * cf, hitR = s.hitDir.x * cf - s.hitDir.z * sf;
  const bob = -A * 0.035 * (1 + Math.cos(2 * ph)) / 2 - bent * 0.09 * s.scale + 0.004 * breath * idle;
  let lx = (aiming ? 0.07 : 0.03) + clamp(s.accF / 30, -1, 1) * 0.14 + clamp(vf / 10, -1, 1) * 0.06;
  let lz = -clamp(s.accR / 30, -1, 1) * 0.12 - 0.03 * A * Math.cos(ph);
  if (s.dodgeT > 0) lz = -clamp(vr / 15, -1, 1) * 0.55;
  lx += (smooth(s.flinch) * 0.3 + reel * 0.14) * hitF - s.kick * s.kick * 0.04 + (s.bossLean || 0);
  lz -= (smooth(s.flinch) * 0.25 + reel * 0.12) * hitR;
  s.model.rotation.x = damp(s.model.rotation.x, lx, 14, dt);
  s.model.rotation.z = damp(s.model.rotation.z, lz, 14, dt);
  s.model.position.y = s.pos.y + bob - (s.bossCrouch || 0) * 0.35 * s.scale;

  // head: leads the body onto the player; scans when he's lost sight of them
  const toPlayer = clamp(wrapAngle(Math.atan2(P.pos.x - s.pos.x, P.pos.z - s.pos.z) - face), -1.1, 1.1);
  const scan = aiming ? 0 : Math.sin(G.clock * 0.8 + s.phase * 0.3) * 0.5;
  s.head.rotation.y = damp(s.head.rotation.y, toPlayer + scan, 9, dt);
  const snap = s.flinch * 0.35 + smooth(s.headSnap) * 0.55; // a headshot throws the head back hard
  s.head.rotation.x = damp(s.head.rotation.x, -Math.atan2(dy, dist) * 0.5 - s.model.rotation.x * 0.6 + snap * hitF, s.headSnap > 0 ? 30 : 12, dt);
  s.head.rotation.z = damp(s.head.rotation.z, -s.model.rotation.z * 0.6, 12, dt);
}

export function updateSoldier(s, dt) {
  if (s.spawnT > 0) {
    s.spawnT -= dt;
    if (s.spawnT <= 0) { s.model.visible = true; embers(tmpA.set(s.pos.x, s.pos.y + 0.2, s.pos.z), 30, 4, 0.5, 4); if (s.boss) bossIntro(s); }
    return;
  }
  if (s.dead) { updateCorpse(s, dt); return; }
  const dx = P.pos.x - s.pos.x, dz = P.pos.z - s.pos.z;
  const dist = Math.hypot(dx, dz) || 0.001, tx = dx / dist, tz = dz / dist;
  if (s.idle) {
    s.model.position.copy(s.pos);
    poseRifle(s, -1.45 + Math.sin(G.clock * 1.4 + s.phase) * 0.02, true, dt);
    s.model.position.y += Math.sin(G.clock * 1.4 + s.phase) * 0.005;
    s.head.rotation.y = Math.sin(G.clock * 0.4 + s.phase) * 0.4;
    for (const [hip, knee, ankle, k] of [[s.legL, s.kneeL, s.ankleL, 0.12], [s.legR, s.kneeR, s.ankleR, 0.22]]) {
      hip.rotation.x = -k * 0.6; knee.rotation.x = k; ankle.rotation.x = -k * 0.4;
    }
    return;
  }
  if (s.pos.y < level.info.killY + 2) { killSoldier(s, false, ['FREEFALL']); return; }
  if (s.boss) { updateBoss(s, dt, dx, dz, dist); return; }

  // pick a direction: close in when far or blind, back off when close, strafe otherwise
  s.losT -= dt; if (s.losT <= 0) { s.losT = 0.25; s.los = hasLineOfSight(s); }
  s.strafeT -= dt; if (s.strafeT <= 0) { s.strafeT = rand(0.9, 2.4); s.strafeDir = Math.random() < 0.5 ? -1 : 1; }
  let mx, mz;
  const K = KINDS[s.kind];
  if (!s.los || dist > K.far) { mx = tx - tz * s.strafeDir * 0.7; mz = tz + tx * s.strafeDir * 0.7; }
  else if (dist < K.near) { mx = -tx - tz * s.strafeDir * 0.5; mz = -tz + tx * s.strafeDir * 0.5; }
  else { mx = -tz * s.strafeDir; mz = tx * s.strafeDir; }
  const ml = Math.hypot(mx, mz) || 1; mx /= ml; mz /= ml;
  s.edgeCd -= dt;
  if (!groundBelow(s.pos.x + mx * 1.3 * s.scale, s.pos.z + mz * 1.3 * s.scale, s.pos.y)) {
    mx = 0; mz = 0;
    if (s.edgeCd <= 0) { s.strafeDir *= -1; s.edgeCd = 0.6; }
  }
  // reeling from a hit: barely any drive of his own and loose footing, so the shove carries him
  s.stagger = Math.max(0, s.stagger - dt);
  const reeling = s.stagger > 0;
  const speed = K.speed * (reeling ? 0.2 : 1), grip = reeling ? 2.5 : 6;
  s.dodgeCd -= dt;
  if (s.dodgeT > 0) {
    s.dodgeT -= dt; s.vel.x = s.dodgeDir.x * 15; s.vel.z = s.dodgeDir.z * 15;
    if (Math.random() < 0.5) embers(tmpA.set(s.pos.x, s.pos.y + 0.1, s.pos.z), 2, 1.5, 0.4, 3);
  } else {
    s.vel.x = damp(s.vel.x, mx * speed, grip, dt); s.vel.z = damp(s.vel.z, mz * speed, grip, dt);
  }
  if (s.knock.lengthSq() > 0) { s.vel.add(s.knock); s.knock.set(0, 0, 0); }
  s.vel.y -= T.gravity * dt;
  const bx = s.pos.x, bz = s.pos.z;
  const steps = Math.ceil(dt * Math.hypot(s.vel.x, s.vel.z) / 0.2) || 1;
  for (let i = 0; i < steps; i++) moveBody(s, dt / steps);
  if (Math.hypot(s.pos.x - bx, s.pos.z - bz) < speed * dt * 0.3) {
    s.stuck += dt;
    if (s.stuck > 0.5) { s.strafeDir *= -1; s.stuck = 0; s.strafeT = rand(1, 2); }
  } else s.stuck = 0;

  // pose: legs walk the way he's moving while the chest stays on the player
  s.model.position.copy(s.pos);
  s.model.rotation.y = lerpAngle(s.model.rotation.y, Math.atan2(dx, dz), 1 - Math.exp(-10 * dt));
  const aiming = s.los && dist < 55 && !reeling; // the rifle drops while he reels
  const dy = (P.pos.y + 1.2) - (s.pos.y + 1.45 * s.scale);
  animateSoldierBody(s, dt, aiming, dist, dy);
  const sway = Math.sin(s.phase) * 0.12 * s.amp;
  poseRifle(s, -(Math.PI / 2 + Math.atan2(dy, dist)), aiming, dt, sway);

  // fire: single shots, shotgun blasts up close, or a charged sniper round (the Juggernaut fires from updateBoss)
  s.fireCd -= dt;
  if (s.kind === 'sniper') { updateSniper(s, dt, aiming && G.mode === 'play' && dist < 70, dist, dy); return; }
  if (G.mode !== 'play') return;
  const pace = difficulty(G.wave).pace;
  if (aiming && s.fireCd <= 0) {
    if (s.kind === 'rusher') {
      if (dist < 12) { shoot(s, Math.hypot(dist, dy), { pellets: 6, cone: 0.07, dmg: 0.4, aim: 0.5 }); s.fireCd = rand(1.3, 1.9) * pace; }
    } else { shoot(s, Math.hypot(dist, dy)); s.fireCd = rand(1.1, 2.3) * pace * (s.kind === 'shield' ? 1.3 : 1); }
  }
}


/** Snipers paint you with a laser that brightens and flickers, then fire one fast, heavy round. */
function updateSniper(s, dt, canShoot, dist, dy) {
  const las = s.laser;
  if (canShoot && s.fireCd <= 0) {
    if (s.charge === 0) sfx.lockOn();
    s.charge += dt;
    s.model.updateMatrixWorld(true);
    const m = s.muzzle.getWorldPosition(tmpA);
    tmpB.set(P.pos.x, P.pos.y + 1.2, P.pos.z);
    las.visible = true; las.position.copy(m); las.lookAt(tmpB); las.scale.set(1, 1, m.distanceTo(tmpB));
    const k = s.charge / SNIPE_CHARGE;
    las.material.opacity = 0.12 + 0.55 * k + (k > 0.8 && Math.sin(G.clock * 70) > 0 ? 0.35 : 0);
    if (s.charge >= SNIPE_CHARGE) {
      shoot(s, Math.hypot(dist, dy), { speed: 85, dmg: 2.2, aim: 0.1 });
      s.charge = 0; s.fireCd = rand(2.6, 3.6); las.visible = false;
    }
  } else {
    s.charge = 0; las.visible = false;
  }
}

/** Soldiers occasionally combat-roll out of a shot's way. Returns true if this one did. */
export function tryDodge(s) {
  if (s.dodgeCd > 0 || s.dodgeT > 0 || s.stagger > 0) return false; // no rolling away while reeling
  if (Math.random() > (s.boss ? 0.08 : G.focusActive ? 0.04 : 0.1)) return false;
  const side = Math.random() < 0.5 ? -1 : 1;
  s.dodgeDir.set(Math.cos(P.yaw) * side, 0, -Math.sin(P.yaw) * side);
  const safe = () => groundBelow(s.pos.x + s.dodgeDir.x * 3.4, s.pos.z + s.dodgeDir.z * 3.4, s.pos.y);
  if (!safe()) { s.dodgeDir.multiplyScalar(-1); if (!safe()) return false; }
  s.dodgeT = 0.18; s.dodgeCd = s.boss ? 3 : rand(2.5, 4.5);
  sfx.whoosh(0.6 + 0.4 * G.timeScale);
  return true;
}

/** Keep live soldiers from standing inside each other. */
export function separateSoldiers() {
  const list = world.soldiers;
  for (let i = 0; i < list.length; i++) for (let j = i + 1; j < list.length; j++) {
    const a = list[i], b = list[j]; if (a.dead || b.dead) continue;
    const rr = a.r + b.r + 0.1;
    const dx = a.pos.x - b.pos.x, dz = a.pos.z - b.pos.z, d = Math.hypot(dx, dz);
    if (d < rr && d > 1e-4) { const p = (rr - d) / 2 / d; a.pos.x += dx * p; a.pos.z += dz * p; b.pos.x -= dx * p; b.pos.z -= dz * p; }
  }
}
