// Anomaly: entry point and main loop.
import { composer, grade, followSun, applyQuality } from './engine.js';
import { $, clamp, damp } from './util.js';
import { level } from './physics.js';
import { loadLevel } from './levels.js';
import { updateParticles, updateFx } from './fx.js';
import { updateMusic } from './audio.js';
import { neonMats } from './materials.js';
import { T, STAGES } from './config.js';
import { G, P, world } from './state.js';
import { updatePlay, updateMenu, makeDisplaySoldiers, renderWorldBoards, renderDailyNote } from './game.js';
import { initLeaderboard } from './leaderboard.js';
import { settings, onSettingsChange } from './settings.js';
import { initSettingsUI } from './settingsUI.js';
import { initStyle } from './style.js';
import { bindTouch } from './touch.js';
import { updateAtmosphere } from './atmosphere.js';
import { ACTIONS, actionKey, actionPad, onBindingsChange } from './bindings.js';
import { updatePops } from './ui.js';
import { renderScores } from './scores.js';
import { bindInput, pollGamepad } from './input.js';

function applyDisplaySettings(key) {
  if (key === '*' || key === 'quality' || key === undefined) applyQuality(settings.quality);
  grade.uniforms.crt.value = settings.crt === 'on' ? 1 : 0;
}
applyDisplaySettings();
onSettingsChange(applyDisplaySettings);
loadLevel(STAGES[G.startStage]);
makeDisplaySoldiers();
renderScores($('menuScores'));
bindInput();
initSettingsUI();
initStyle();
bindTouch();
/** The How to play list on the title screen, from the current bindings. */
function renderHowTo() {
  const dl = $('keysList'); dl.textContent = '';
  const row = (keys, text) => {
    const dt = document.createElement('dt');
    for (const k of keys) { const kb = document.createElement('kbd'); kb.textContent = k; dt.append(kb); }
    const dd = document.createElement('dd'); dd.textContent = text; dl.append(dt, dd);
  };
  row(['forward', 'left', 'back', 'right'].map(actionKey), 'Move · run along a wall to wall-run · run straight at one to climb it');
  for (const a of ACTIONS.slice(4)) row([actionKey(a.id)], `${a.label}${a.desc ? ': ' + a.desc : ''} (controller: ${actionPad(a.id)})`);
  row(['Land on'], 'Stomp soldiers and drones from above · slide into a body to surf it');
  row(['M', 'V', 'N'], 'Music on/off · CRT filter on/off · announcer on/off');
  row(['Controller'], 'Left stick moves, right stick aims, Start / Options pauses');
}
renderHowTo();
renderDailyNote();
onBindingsChange(renderHowTo);
initLeaderboard(renderWorldBoards);

let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  const raw = Math.min(0.05, (now - last) / 1000); last = now;
  pollGamepad(raw);

  // hit-stop: freeze the world for a beat on big hits
  let dt = raw;
  if (G.hitStop > 0 && G.mode !== 'paused') { G.hitStop -= raw; dt = raw * 0.04; }

  if (G.mode === 'menu') updateMenu(dt);
  else if (G.mode === 'play' || G.mode === 'dead') updatePlay(dt);

  if (G.mode !== 'paused') {
    const dtWorld = dt * G.timeScale;
    for (const m of neonMats) m.emissiveIntensity = Math.random() < 0.02 ? 0.25 : damp(m.emissiveIntensity, 1.2, 12, raw);
    updateParticles(dtWorld);
    updateFx(dt, dtWorld);
    grade.uniforms.amount.value = clamp((1 - G.timeScale) / 0.8, 0, 1);
    G.flash = Math.max(0, G.flash - raw * 4);
    grade.uniforms.flash.value = G.flash;
    updatePops(raw);
  }
  followSun(G.mode === 'menu' ? level.info.start : P.pos);
  updateAtmosphere(raw);
  updateMusic(G.mode === 'play' || G.mode === 'dead', {
    boss: world.soldiers.some(s => s.boss && !s.dead),
    slowed: G.focusActive,
    timeScale: G.timeScale,
    heat: G.combo > 1 && G.clock - G.lastKill < T.comboWindow ? clamp((G.combo - 1) / 5, 0, 1) : 0,
  });
  composer.render();
}
requestAnimationFrame(frame);
