// Synthesized sound effects and the chiptune soundtrack (Web Audio, no files).
import { store } from './util.js';
import { settings, onSettingsChange } from './settings.js';

let AC = null, master, sfxBus, noiseBuf, windGain, rainGain, droneFilter, musicBus, musicFilter;
let seqStep = 0, seqNext = 0;
export const audioSettings = { music: store.get('music') !== 'off' };

/** Must run from a user gesture. Safe to call repeatedly. */
export function initAudio() {
  if (AC) { AC.resume(); return; }
  try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch { AC = null; return; }
  master = AC.createGain();
  const comp = AC.createDynamicsCompressor(); master.connect(comp); comp.connect(AC.destination);
  sfxBus = AC.createGain(); sfxBus.connect(master);
  applyVolumes();
  noiseBuf = AC.createBuffer(1, AC.sampleRate, AC.sampleRate);
  const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  // rushing wind while wall-running, climbing, diving or surfing
  const n = AC.createBufferSource(); n.buffer = noiseBuf; n.loop = true;
  const bp = AC.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 700; bp.Q.value = 0.5;
  windGain = AC.createGain(); windGain.gain.value = 0;
  n.connect(bp).connect(windGain).connect(sfxBus); n.start();
  // rain hiss, off until a monsoon rolls in
  const rn = AC.createBufferSource(); rn.buffer = noiseBuf; rn.loop = true; rn.playbackRate.value = 0.8;
  const rf = AC.createBiquadFilter(); rf.type = 'highpass'; rf.frequency.value = 1800;
  rainGain = AC.createGain(); rainGain.gain.value = 0;
  rn.connect(rf).connect(rainGain).connect(sfxBus); rn.start();
  // low drone under everything
  droneFilter = AC.createBiquadFilter(); droneFilter.type = 'lowpass'; droneFilter.frequency.value = 240;
  const dg = AC.createGain(); dg.gain.value = 0.07; droneFilter.connect(dg).connect(sfxBus);
  for (const f of [55, 55.35, 82.4, 110.2]) { const o = AC.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f; o.connect(droneFilter); o.start(); }
  // music bus
  musicBus = AC.createGain(); musicBus.gain.value = 0;
  musicFilter = AC.createBiquadFilter(); musicFilter.type = 'lowpass'; musicFilter.frequency.value = 6000;
  musicBus.connect(musicFilter).connect(master);
}
/** Master and effects levels from the settings page (music is scaled per frame in updateMusic). */
function applyVolumes() {
  if (!AC) return;
  master.gain.setTargetAtTime(0.5 * settings.master / 100, AC.currentTime, 0.02);
  sfxBus.gain.setTargetAtTime(settings.effects / 100, AC.currentTime, 0.02);
}
onSettingsChange(applyVolumes);
/** Rain loudness 0..0.3 (monsoon event). */
export function setRain(v) { if (AC) rainGain.gain.setTargetAtTime(v, AC.currentTime, 0.3); }
export function suspendAudio() { if (AC) AC.suspend(); }
export function resumeAudio() { if (AC) AC.resume(); }

/** Wind loudness (0..0.15) and whether bullet time muffles the drone. */
export function setAmbience(wind, slowed) {
  if (!AC) return;
  windGain.gain.setTargetAtTime(wind, AC.currentTime, 0.08);
  droneFilter.frequency.setTargetAtTime(slowed ? 90 : 240, AC.currentTime, 0.2);
}

function env(g, t, attack, peak, decay) {
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(Math.max(peak, 0.0002), t + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
}
export function tone(f0, f1, dur, type = 'sine', vol = 0.2, delay = 0) {
  if (!AC) return;
  const t = AC.currentTime + delay;
  const o = AC.createOscillator(); o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(f1, 1), t + dur);
  const g = AC.createGain(); env(g, t, 0.004, vol, dur); o.connect(g).connect(sfxBus); o.start(t); o.stop(t + dur + 0.05);
}
function noise(dur, f0, f1, vol = 0.3, type = 'lowpass', rate = 1, delay = 0) {
  if (!AC) return;
  const t = AC.currentTime + delay;
  const s = AC.createBufferSource(); s.buffer = noiseBuf; s.playbackRate.value = rate;
  const f = AC.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(f1, 20), t + dur);
  const g = AC.createGain(); env(g, t, 0.003, vol, dur); s.connect(f).connect(g).connect(sfxBus); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.1);
}
const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
const arpeggio = (root, steps, gap, dur, vol) => steps.forEach((n, i) => tone(mtof(root + n), mtof(root + n), dur, 'square', vol, i * gap));

export const sfx = {
  shot(vol = 1, pitch = 1) {
    tone(1400 * pitch, 180, 0.03, 'square', 0.12 * vol);                       // crack
    noise(0.24 / pitch, 4800 * pitch, 240, 0.8 * vol, 'lowpass', pitch);        // body
    tone(140 * pitch, 38, 0.17 / pitch, 'sine', 0.95 * vol);                    // thump
    noise(0.03, 9000, 5000, 0.2 * vol, 'highpass');                            // snap
    noise(0.35 / pitch, 1600, 250, 0.16 * vol, 'bandpass', pitch * 0.8, 0.07);  // slap back off the buildings
  },
  enemyShot(vol, pitch) {
    noise(0.3 / pitch, 3800 * pitch, 200, 0.5 * vol, 'lowpass', pitch); tone(120 * pitch, 35, 0.2 / pitch, 'sine', 0.7 * vol);
    noise(0.4 / pitch, 1200, 200, 0.12 * vol, 'bandpass', pitch * 0.8, 0.09);
  },
  hit() { tone(2600, 1900, 0.05, 'square', 0.06); },
  kill() { noise(0.28, 1400, 140, 0.4, 'lowpass', 0.7); tone(95, 38, 0.22, 'sine', 0.7); noise(0.12, 3000, 800, 0.15, 'bandpass', 1.3, 0.05); },
  stomp() { tone(120, 32, 0.32, 'sine', 1); noise(0.32, 1000, 70, 0.55, 'lowpass', 0.6); },
  dive() { noise(0.45, 3200, 380, 0.3, 'bandpass'); tone(320, 90, 0.4, 'triangle', 0.07); },
  surf() { noise(0.6, 350, 1300, 0.3, 'bandpass', 0.8); tone(80, 160, 0.3, 'sawtooth', 0.06); },
  focusIn() { tone(520, 45, 0.9, 'sawtooth', 0.14); noise(0.8, 3000, 150, 0.2, 'lowpass', 0.5); },
  focusOut() { tone(50, 480, 0.45, 'sawtooth', 0.1); noise(0.4, 200, 3000, 0.12, 'lowpass'); },
  hurt() { tone(140, 40, 0.3, 'sine', 0.7); noise(0.25, 1500, 200, 0.3); },
  whoosh(pitch = 1) { noise(0.35 / pitch, 2600 * pitch, 350, 0.28, 'bandpass', pitch); },
  jump() { tone(200, 380, 0.08, 'sine', 0.06); },
  airJump() { tone(300, 1100, 0.16, 'triangle', 0.08); noise(0.2, 1000, 3000, 0.08, 'bandpass'); },
  land() { tone(90, 40, 0.15, 'sine', 0.35); },
  lockOn() { tone(1500, 1500, 0.07, 'square', 0.035); tone(1500, 1500, 0.07, 'square', 0.035, 0.12); },
  ricochet() { tone(2600, 1700, 0.09, 'triangle', 0.06); noise(0.05, 5000, 2500, 0.08, 'highpass'); },
  parry() { tone(2200, 3300, 0.14, 'triangle', 0.09); tone(1100, 1650, 0.2, 'sine', 0.06, 0.02); },
  charge() { tone(300, 900, 0.22, 'sawtooth', 0.035); tone(900, 900, 0.08, 'square', 0.03, 0.22); },
  dash() { noise(0.22, 3000, 400, 0.22, 'bandpass'); tone(700, 160, 0.22, 'sawtooth', 0.05); },
  horn() { for (const d of [0, 1.1]) { tone(220, 216, 0.85, 'sawtooth', 0.11, d); tone(277, 272, 0.85, 'sawtooth', 0.09, d); } },
  trainRumble(v) { noise(0.32, 420, 110, 0.3 * v, 'lowpass', 0.6); },
  roar() { tone(95, 60, 0.7, 'sawtooth', 0.18); tone(142, 88, 0.7, 'sawtooth', 0.12); noise(0.7, 900, 200, 0.25, 'lowpass', 0.5); },
  thunder() { noise(1.6, 500, 40, 0.7, 'lowpass', 0.4); tone(52, 28, 1.3, 'sine', 0.6); },
  crackle() { noise(0.35, 7000, 3000, 0.12, 'highpass', 1.6); },
  powerDown() { tone(420, 30, 0.9, 'sawtooth', 0.14); noise(0.3, 3000, 200, 0.2); },
  powerUp() { tone(40, 520, 0.7, 'sawtooth', 0.1); tone(80, 1040, 0.7, 'square', 0.03, 0.1); },
  creak() { tone(64, 44, 1.6, 'sawtooth', 0.12); noise(1.8, 320, 90, 0.3, 'lowpass', 0.3); },
  crash() { noise(1, 2200, 70, 0.8, 'lowpass', 0.6); tone(82, 28, 0.7, 'sine', 0.9); },
  explosion() { noise(1.3, 3200, 55, 0.95, 'lowpass', 0.5); tone(72, 24, 0.9, 'sine', 1); noise(0.4, 7000, 2000, 0.2, 'highpass', 1.2, 0.05); },
  tink() { tone(4200 + Math.random() * 900, 3600, 0.05, 'triangle', 0.018); },
  thud() { tone(75, 32, 0.22, 'sine', 0.45); noise(0.18, 700, 110, 0.22, 'lowpass'); },
  clatter() { tone(1900, 1500, 0.05, 'square', 0.025); tone(1250, 900, 0.07, 'triangle', 0.035, 0.07); },
  impact() { tone(160, 45, 0.22, 'sine', 0.9); noise(0.15, 2500, 200, 0.4); },
  reload() { tone(3200, 2600, 0.03, 'square', 0.05); tone(2400, 2000, 0.03, 'square', 0.05, 0.55); tone(3400, 3000, 0.04, 'square', 0.06, 0.95); },
  spawn(vol) { noise(0.9, 200, 4000, 0.18 * vol, 'bandpass', 0.7); tone(40, 90, 0.8, 'sawtooth', 0.08 * vol); },
  heartbeat() { tone(68, 40, 0.12, 'sine', 0.45); tone(62, 38, 0.12, 'sine', 0.3, 0.16); },
  empty() { tone(1800, 1600, 0.025, 'square', 0.05); },
  slash() { noise(0.16, 9000, 1500, 0.35, 'highpass', 1.4); tone(1800, 500, 0.12, 'sawtooth', 0.04); },
  cut() { noise(0.14, 4200, 700, 0.32, 'bandpass', 1.1); tone(210, 60, 0.16, 'sine', 0.4); }, // blade through a body
  clang() { tone(2400, 2200, 0.25, 'square', 0.05); tone(3600, 3300, 0.2, 'triangle', 0.06); noise(0.1, 8000, 3000, 0.2, 'highpass'); },
  hellfire() { tone(900, 40, 1.0, 'sawtooth', 0.25); noise(1.0, 6000, 100, 0.5, 'lowpass', 0.6); tone(60, 30, 0.8, 'sine', 0.9); },
  alarm() { for (let i = 0; i < 4; i++) tone(880, 620, 0.22, 'square', 0.08, i * 0.32); },
  death() { tone(600, 30, 1.2, 'sawtooth', 0.2); noise(1.2, 3000, 60, 0.4); },
  pickup() { arpeggio(76, [0, 4, 7, 12], 0.045, 0.07, 0.06); },
  oneUp() { arpeggio(72, [0, 4, 7, 12, 16, 19, 24], 0.06, 0.08, 0.06); },
  blip() { tone(1500, 1500, 0.05, 'square', 0.05); tone(2000, 2000, 0.06, 'square', 0.05, 0.06); },
  tick() { tone(440, 440, 0.06, 'square', 0.04); },
};

// ---- chiptune: Am – F – C – G, one bar each; a lead joins every other pass
const PROG = [[45, [57, 60, 64]], [41, [57, 60, 65]], [48, [55, 60, 64]], [43, [55, 59, 62]]];
const BASS = [1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0];
function note(t, f0, f1, dur, type, vol) {
  const o = AC.createOscillator(); o.type = type; o.frequency.setValueAtTime(f0, t);
  if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
  const g = AC.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(musicBus); o.start(t); o.stop(t + dur + 0.02);
}
function hat(t, dur, freq, type, vol) {
  const s = AC.createBufferSource(); s.buffer = noiseBuf;
  const f = AC.createBiquadFilter(); f.type = type; f.frequency.value = freq;
  const g = AC.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  s.connect(f).connect(g).connect(musicBus); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.02);
}
function playStep(step, t, pitch, boss, heat) {
  const bar = Math.floor(step / 16) % 4, s = step % 16, tr = boss ? 1 : 0;
  const [root, chord] = PROG[bar];
  if (BASS[s]) { const f = mtof(root + tr + (s === 3 || s === 11 || s === 14 ? 12 : 0)) * pitch; note(t, f, f, 0.13, boss ? 'sawtooth' : 'square', 0.06); }
  const af = mtof(chord[s % 3] + 12 + tr) * pitch; note(t, af, af, 0.07, 'square', 0.018);
  if (heat > 0.7) note(t, af * 2, af * 2, 0.06, 'sawtooth', 0.012 * heat);            // hot chain: a screaming arp on top
  if ((Math.floor(step / 64) % 2 === 1 || heat > 0.45) && (s === 0 || s === 6 || s === 10 || s === 12)) {
    const lf = mtof(chord[(s / 2 | 0) % 3] + 24 + tr) * pitch; note(t, lf, lf, 0.28, 'triangle', 0.05);
  }
  if (s % 4 === 0) note(t, 150 * pitch, 40, 0.14, 'sine', 0.32);
  if (heat > 0.2 && s % 4 === 2) note(t, 140 * pitch, 40, 0.1, 'sine', 0.18 * heat); // double kick
  if (heat > 0.2 && s % 2 === 0) hat(t, 0.025, 9000, 'highpass', 0.03 * heat);
  if (s === 4 || s === 12) hat(t, 0.12, 1800, 'bandpass', 0.12);
  if (s % 2 === 1 || boss) hat(t, 0.03, 7000, 'highpass', 0.035);
}
/** Call every frame. Slow motion drags the tempo and pitch; bullet time muffles it. */
let heatS = 0;
export function updateMusic(active, { boss, slowed, timeScale, heat = 0 }) {
  if (!AC) return;
  const on = active && audioSettings.music;
  musicBus.gain.setTargetAtTime(on ? 0.6 * settings.music / 100 : 0, AC.currentTime, 0.1);
  musicFilter.frequency.setTargetAtTime(slowed ? 900 : 6000, AC.currentTime, 0.15);
  if (!on) return;
  heatS += (heat - heatS) * 0.04; // build up and cool down over a second or so
  const now = AC.currentTime;
  if (seqNext < now - 0.1) seqNext = now + 0.05;
  const bpm = (boss ? 164 : 148) + 10 * heatS, tempo = 0.45 + 0.55 * timeScale, pitch = 0.82 + 0.18 * timeScale;
  for (let guard = 0; seqNext < now + 0.12 && guard < 8; guard++) {
    playStep(seqStep, seqNext, pitch, boss, heatS);
    seqNext += 60 / bpm / 4 / tempo; seqStep++;
  }
}
// ---- announcer: the browser's speech voice, pitched down, calling the big moments
let voice = null;
function pickVoice() {
  const vs = window.speechSynthesis ? speechSynthesis.getVoices() : [];
  return vs.find(v => /^en/i.test(v.lang) && /\b(male|daniel|david|george|guy|fred|alex|mark|james)\b/i.test(v.name) && !/female/i.test(v.name))
    || vs.find(v => /^en/i.test(v.lang)) || null;
}
/** Say it now (cuts off whatever it was saying: the newest call wins). */
export function announce(text) {
  if (settings.announcer !== 'on' || !window.speechSynthesis || !text) return;
  try {
    const u = new SpeechSynthesisUtterance(String(text).toLowerCase().replace(/!+/g, '!'));
    voice = voice || pickVoice(); if (voice) u.voice = voice;
    u.pitch = 0.55; u.rate = 1.05; u.volume = 0.9 * settings.master / 100;
    speechSynthesis.cancel(); speechSynthesis.speak(u);
  } catch { /* no speech on this browser */ }
}

export function toggleMusic() { audioSettings.music = !audioSettings.music; store.set('music', audioSettings.music ? 'on' : 'off'); }
