// Parked cars: sedans and SUVs built from an extruded side profile with wheel arches,
// plus glass, wheels, lights, bumpers and mirrors. Geometry is in car space (length along x,
// front at +x, ground at y = 0) for the level to place and merge.
import * as THREE from 'three';
import { CAR } from './materials.js';

const TYPES = {
  sedan: {
    len: 4.5, wid: 1.82, floor: 0.36, wheelR: 0.33, wheelBase: 1.35, archR: 0.42,
    // body outline from the front bumper, over the roof, back to the rear bumper
    top: [[2.3, 0.5], [2.26, 0.78], [1.05, 0.9], [0.4, 1.36], [-0.85, 1.39], [-1.55, 0.98], [-2.22, 0.93], [-2.3, 0.62], [-2.28, 0.45]],
    sideWindow: [[0.98, 0.95], [0.42, 1.3], [-0.82, 1.33], [-1.45, 0.97]], pillars: [-0.22],
    windshield: [[1.05, 0.9], [0.4, 1.36]], rearWindow: [[-0.85, 1.39], [-1.55, 0.98]],
    head: [2.27, 0.68, 0.58, 0.1, 0.34], tail: [-2.29, 0.8, 0.6, 0.12, 0.4],
    grille: [2.29, 0.58, 0.14, 0.7], bumperY: 0.45, mirror: [0.95, 1.0],
    solids: [[0, 0, 4.5, 0.95, 1.82], [-0.25, 0.95, 2.2, 0.45, 1.6]],
  },
  suv: {
    len: 4.72, wid: 1.92, floor: 0.45, wheelR: 0.38, wheelBase: 1.45, archR: 0.48,
    top: [[2.36, 0.62], [2.3, 1.02], [1.35, 1.12], [0.75, 1.72], [-1.9, 1.78], [-2.33, 1.7], [-2.36, 0.62]],
    sideWindow: [[1.3, 1.14], [0.8, 1.64], [-1.85, 1.69], [-1.9, 1.14]], pillars: [0.1, -1.0],
    windshield: [[1.35, 1.12], [0.75, 1.72]], rearWindow: [[-2.34, 1.66], [-2.36, 1.12]],
    head: [2.35, 0.86, 0.62, 0.12, 0.3], tail: [-2.37, 1.2, 0.74, 0.34, 0.12],
    grille: [2.37, 0.8, 0.26, 0.9], bumperY: 0.55, mirror: [1.25, 1.2],
    solids: [[0, 0, 4.72, 1.12, 1.92], [-0.4, 1.12, 3.3, 0.66, 1.72]],
  },
};

function bodyGeometry(t) {
  const s = new THREE.Shape(), half = t.len / 2, y = t.floor;
  s.moveTo(-half, y);
  for (const cx of [-t.wheelBase, t.wheelBase]) { s.lineTo(cx - t.archR, y); s.absarc(cx, y, t.archR, Math.PI, 0, true); }
  s.lineTo(half, y);
  for (const [x, yy] of t.top) s.lineTo(x, yy);
  s.closePath();
  const depth = t.wid - 0.12;
  const geo = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: true, bevelThickness: 0.06, bevelSize: 0.06, bevelSegments: 2, curveSegments: 10 });
  geo.translate(0, 0, -depth / 2);
  return geo;
}
const box = (sx, sy, sz, x, y, z) => new THREE.BoxGeometry(sx, sy, sz).translate(x, y, z);
/** A glass pane spanning the car's width along the slope from a to b, nudged outward. */
function slopedPane(a, b, width) {
  const dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy);
  let nx = -dy / len, ny = dx / len; if (ny < 0) { nx = -nx; ny = -ny; }
  const geo = new THREE.PlaneGeometry(len, width).rotateX(-Math.PI / 2).rotateZ(Math.atan2(dy, dx));
  return geo.translate((a[0] + b[0]) / 2 + nx * 0.012, (a[1] + b[1]) / 2 + ny * 0.012, 0);
}

/** All the pieces of one car as [{ geo, mat }], in car space. */
export function carParts(type, paint, lightsOn) {
  const t = TYPES[type], half = t.wid / 2, parts = [];
  const add = (geo, mat) => parts.push({ geo, mat });
  add(bodyGeometry(t), paint);
  // glass: both sides, windshield and rear window; dark pillars over the side glass
  const side = new THREE.ShapeGeometry(new THREE.Shape(t.sideWindow.map(([x, y]) => new THREE.Vector2(x, y))));
  add(side.clone().translate(0, 0, half + 0.003), CAR.glass);
  add(side.translate(0, 0, -half - 0.003), CAR.glass);
  for (const px of t.pillars) for (const z of [half + 0.01, -half - 0.01]) add(box(0.09, 0.5, 0.02, px, (t.sideWindow[0][1] + t.sideWindow[2][1]) / 2, z), CAR.plastic);
  add(slopedPane(...t.windshield, t.wid - 0.34), CAR.glass);
  add(slopedPane(...t.rearWindow, t.wid - 0.4), CAR.glass);
  // wheels: tyre plus rim
  for (const x of [-t.wheelBase, t.wheelBase]) for (const z of [half - 0.1, -half + 0.1]) {
    add(new THREE.CylinderGeometry(t.wheelR, t.wheelR, 0.24, 20).rotateX(Math.PI / 2).translate(x, t.wheelR, z), CAR.tire);
    add(new THREE.CylinderGeometry(t.wheelR * 0.6, t.wheelR * 0.6, 0.25, 10).rotateX(Math.PI / 2).translate(x, t.wheelR, z), CAR.rim);
  }
  // bumpers, grille, mirrors
  const front = t.len / 2;
  add(box(0.18, 0.2, t.wid - 0.04, front + 0.02, t.bumperY, 0), CAR.plastic);
  add(box(0.18, 0.2, t.wid - 0.04, -front - 0.02, t.bumperY, 0), CAR.plastic);
  const [gx, gy, gh, gw] = t.grille; add(box(0.05, gh, gw, gx, gy, 0), CAR.plastic);
  for (const z of [half + 0.08, -half - 0.08]) add(box(0.12, 0.1, 0.18, t.mirror[0], t.mirror[1], z), paint);
  // lights
  const [hx, hy, hz, hh, hw] = t.head, [tx, ty, tz, th, tw] = t.tail;
  for (const s of [1, -1]) {
    add(box(0.08, hh, hw, hx, hy, s * hz), lightsOn ? CAR.headOn : CAR.headOff);
    add(box(0.07, th, tw, tx, ty, s * tz), lightsOn ? CAR.tailOn : CAR.tailOff);
  }
  return parts;
}

/** Invisible collision boxes in car space: [centreX, bottomY, lengthX, height, widthZ]. */
export const carSolids = type => TYPES[type].solids;
