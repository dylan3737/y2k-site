// Controller cursor for the menu, pause and game-over screens: the d-pad or left stick moves a highlight
// between the buttons and stage chips by screen position, and A / Cross presses whatever is highlighted.
import { $ } from './util.js';
import { G } from './state.js';
import { startGame } from './game.js';

let cur = null, shown = false;

const screen = () => (G.mode === 'menu' ? $('menu') : G.mode === 'paused' ? $('pause') : G.mode === 'dead' ? $('over') : null);
const visible = el => el.offsetParent !== null && !el.disabled;
const items = s => [...s.querySelectorAll('.actions button.go, .stages label')].filter(visible);

function paint() {
  for (const el of document.querySelectorAll('.navcur')) if (el !== cur || !shown) el.classList.remove('navcur');
  if (cur && shown) cur.classList.add('navcur');
}

/** Keep the cursor on something visible on the current screen (screens change, buttons hide). */
export function navSync() {
  const s = screen();
  if (!s || s.hidden) { cur = null; paint(); return null; }
  if (!cur || !s.contains(cur) || !visible(cur)) cur = items(s).find(el => el.tagName === 'BUTTON') || null;
  paint();
  return s;
}

/** Move the cursor one step in a direction (dx, dy each -1, 0 or 1), to the nearest item that way. */
export function navMove(dx, dy) {
  const s = navSync();
  if (!s || !cur) return;
  if (!shown) { shown = true; paint(); return; } // the first push only reveals the cursor
  // score by edge gaps: how far ahead the item starts, plus how far it sits off to the side (0 if they line up)
  const a = cur.getBoundingClientRect();
  const gap = (lo1, hi1, lo2, hi2) => Math.max(0, lo2 - hi1, lo1 - hi2);
  let best = null, bestScore = Infinity;
  for (const el of items(s)) {
    if (el === cur) continue;
    const b = el.getBoundingClientRect();
    const along = dx > 0 ? b.left - a.right : dx < 0 ? a.left - b.right : dy > 0 ? b.top - a.bottom : a.top - b.bottom;
    const ahead = dx ? (b.left + b.right - a.left - a.right) * dx : (b.top + b.bottom - a.top - a.bottom) * dy;
    if (ahead <= 4 || along < -4) continue;
    const across = dx ? gap(a.top, a.bottom, b.top, b.bottom) : gap(a.left, a.right, b.left, b.right);
    const score = Math.max(0, along) + across * 2;
    if (score < bestScore) { bestScore = score; best = el; }
  }
  if (!best) return;
  // entering the stage chips from a button lands on the stage already picked, so it doesn't change by accident
  const checked = s.querySelector('.stages input:checked');
  if (best.tagName === 'LABEL' && cur.tagName !== 'LABEL' && checked) best = checked.closest('label');
  cur = best;
  // landing on a stage chip picks that stage
  const radio = cur.querySelector('input[type="radio"]');
  if (radio && !radio.checked) { radio.checked = true; radio.dispatchEvent(new Event('change')); }
  cur.scrollIntoView({ block: 'nearest' });
  paint();
}

/** A / Cross: press the highlighted button; on a stage chip, start the game there. */
export function navActivate() {
  navSync();
  if (!cur) return;
  if (!shown) { shown = true; paint(); return; } // after mouse use, the first press shows where the cursor is
  if (cur.tagName === 'LABEL') startGame();
  else cur.click();
}

/** Show the cursor (a controller was just plugged in) or hide it (the mouse took over). */
export function navShow(on) { shown = on; paint(); }
