// Controller rumble: short, light pulses on hits and impacts. Deliberately subtle.
import { settings } from './settings.js';
let pad = null;

/** The gamepad to rumble (null when none is connected). Called each poll. */
export function setRumblePad(gp) { pad = gp; }

// the settings slider is 0-100; 50 (the default) is the light feel, 100 roughly twice as strong
const strength = () => settings.rumble / 100;

/** weak = the high-frequency motor, strong = the low one, both 0..1 before scaling. */
export function rumble(weak, strong, ms) {
  if (!settings.rumble) return;
  const act = pad && pad.vibrationActuator;
  if (!act || typeof act.playEffect !== 'function') return;
  try {
    const p = act.playEffect('dual-rumble', {
      duration: ms, weakMagnitude: Math.min(1, weak * strength()), strongMagnitude: Math.min(1, strong * strength()),
    });
    if (p && p.catch) p.catch(() => {});
  } catch { /* no rumble on this pad */ }
}
