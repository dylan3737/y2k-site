// The settings page: built from SCHEMA, usable with mouse, keyboard or a controller
// (d-pad up/down picks a row, left/right changes it, B / Circle goes back).
import { $ } from './util.js';
import { SCHEMA, settings, setSetting, resetSettings, onSettingsChange } from './settings.js';
import { sfx } from './audio.js';
import { ACTIONS, actionKey, actionPad, resetBindings, onBindingsChange } from './bindings.js';

let rows = [], focus = 0, returnTo = null;
let capture = null; // { id, device: 'key' | 'pad' } while waiting for the new binding

/** The action being rebound, or null. */
export const isCapturing = () => (capture ? capture.id : null);
export const captureDevice = () => (capture ? capture.device : null);
function startCapture(id, device) { capture = { id, device }; sfx.tick(); renderAll(); }
export function endCapture() { capture = null; sfx.blip(); renderAll(); }

function build() {
  const body = $('settingsBody');
  body.textContent = '';
  rows = [];
  let group = null, box = null;
  for (const def of SCHEMA) {
    if (def.group !== group) {
      group = def.group;
      box = document.createElement('section'); box.className = 'setgroup';
      const h = document.createElement('h3'); h.textContent = group; box.append(h);
      body.append(box);
    }
    const row = document.createElement('div'); row.className = 'setting';
    const name = document.createElement('span'); name.className = 'setname'; name.textContent = def.label;
    if (def.note) { const n = document.createElement('small'); n.textContent = def.note; name.append(n); }
    const ctl = document.createElement('div'); ctl.className = 'setctl';
    let render;
    if (def.type === 'choice') {
      const btns = def.options.map((opt, i) => {
        const b = document.createElement('button'); b.type = 'button'; b.className = 'chip'; b.textContent = def.labels[i];
        b.addEventListener('click', () => { setSetting(def.key, opt); sfx.blip(); });
        ctl.append(b); return b;
      });
      render = () => btns.forEach((b, i) => b.setAttribute('aria-pressed', String(settings[def.key] === def.options[i])));
    } else {
      const input = document.createElement('input'); input.type = 'range';
      Object.assign(input, { min: def.min, max: def.max, step: def.step });
      input.setAttribute('aria-label', def.label);
      const out = document.createElement('output');
      input.addEventListener('input', () => setSetting(def.key, +input.value));
      ctl.append(input, out);
      render = () => { input.value = settings[def.key]; out.textContent = def.fmt(settings[def.key]); };
    }
    row.append(name, ctl); box.append(row);
    row.addEventListener('pointerenter', () => { const i = rows.findIndex(r => r.row === row); if (i >= 0) setFocus(i); });
    rows.push({ def, row, render });
  }
  // controls: every action's key and controller button; select one, then press the new key or button
  const box2 = document.createElement('section'); box2.className = 'setgroup';
  const h2 = document.createElement('h3'); h2.textContent = 'Controls'; box2.append(h2);
  const note = document.createElement('p'); note.className = 'note setnote';
  note.textContent = 'Click a binding (or pick the row and press Enter / A), then press the new key or button. Taking a key another action uses swaps the two. Sticks, Esc and Start stay fixed.';
  box2.append(note);
  for (const a of ACTIONS) {
    const row = document.createElement('div'); row.className = 'setting bindrow';
    const name = document.createElement('span'); name.className = 'setname'; name.textContent = a.label;
    if (a.desc) { const n = document.createElement('small'); n.textContent = a.desc; name.append(n); }
    const ctl = document.createElement('div'); ctl.className = 'setctl';
    const kb = document.createElement('button'); kb.type = 'button'; kb.className = 'chip bind';
    kb.addEventListener('click', () => startCapture(a.id, 'key'));
    ctl.append(kb);
    let pb = null;
    if (a.pad != null) {
      pb = document.createElement('button'); pb.type = 'button'; pb.className = 'chip bind pad';
      pb.addEventListener('click', () => startCapture(a.id, 'pad'));
      ctl.append(pb);
    } else { const s2 = document.createElement('span'); s2.className = 'chip bind fixed'; s2.textContent = 'Left stick'; ctl.append(s2); }
    const render = () => {
      const listening = capture && capture.id === a.id;
      kb.textContent = listening && capture.device === 'key' ? 'Press a key…' : actionKey(a.id);
      kb.classList.toggle('listening', !!(listening && capture.device === 'key'));
      if (pb) {
        pb.textContent = listening && capture.device === 'pad' ? 'Press a button…' : actionPad(a.id);
        pb.classList.toggle('listening', !!(listening && capture.device === 'pad'));
      }
    };
    row.append(name, ctl); box2.append(row);
    row.addEventListener('pointerenter', () => { const i = rows.findIndex(r => r.row === row); if (i >= 0) setFocus(i); });
    rows.push({ def: null, bind: a, row, render });
  }
  const resetRow = document.createElement('div'); resetRow.className = 'setting';
  const rb = document.createElement('button'); rb.type = 'button'; rb.className = 'chip'; rb.textContent = 'Reset controls to defaults';
  rb.addEventListener('click', () => { resetBindings(); sfx.blip(); });
  resetRow.append(document.createElement('span'), rb); box2.append(resetRow);
  rows.push({ def: null, row: rb, render: () => {} });
  body.append(box2);
  // the two buttons at the bottom are rows too, so a controller can reach them
  for (const id of ['setReset', 'setBack']) rows.push({ def: null, row: $(id), render: () => {} });
  renderAll();
}
function renderAll() { for (const r of rows) r.render(); }
function setFocus(i) {
  focus = (i + rows.length) % rows.length;
  rows.forEach((r, k) => r.row.classList.toggle('focus', k === focus));
  rows[focus].row.scrollIntoView({ block: 'nearest' });
}

export const isSettingsOpen = () => !$('settings').hidden;

/** Show the page over `from` (the overlay element to hide meanwhile, restored on close). */
export function openSettings(from) {
  returnTo = from;
  if (from) from.hidden = true;
  $('settings').hidden = false;
  renderAll(); setFocus(0);
}
export function closeSettings() {
  capture = null;
  $('settings').hidden = true;
  if (returnTo) returnTo.hidden = false;
  returnTo = null;
}

/** Controller / keyboard navigation. */
export function settingsMove(d) { setFocus(focus + d); sfx.tick(); }
export function settingsAdjust(d) {
  const { def } = rows[focus];
  if (!def) return;
  if (def.type === 'choice') {
    const i = def.options.indexOf(settings[def.key]);
    const next = def.options[Math.max(0, Math.min(def.options.length - 1, i + d))];
    if (next !== settings[def.key]) { setSetting(def.key, next); sfx.blip(); }
  } else {
    const v = Math.round((settings[def.key] + d * def.step) / def.step) * def.step;
    setSetting(def.key, +Math.max(def.min, Math.min(def.max, v)).toFixed(2));
  }
}
export function settingsActivate(fromPad = false) {
  const r = rows[focus];
  if (r.bind) startCapture(r.bind.id, fromPad && r.bind.pad != null ? 'pad' : 'key');
  else if (!r.def) r.row.click(); else settingsAdjust(1);
}

export function initSettingsUI() {
  build();
  onSettingsChange(renderAll);
  onBindingsChange(renderAll);
  $('setBack').addEventListener('click', () => { closeSettings(); sfx.blip(); });
  $('setReset').addEventListener('click', () => { resetSettings(); sfx.blip(); });
}
