// Explosive barrels: red drums placed around each stage. Any bullet (yours, a deflected one or a stray
// enemy round) or a Hellfire blast sets one off; the blast kills soldiers nearby, hurts you if you're close,
// and sets off other barrels in reach a beat later for a chain reaction.
import * as THREE from 'three';
import { V3, tmpA } from './util.js';
import { level, rayAABB } from './physics.js';
import { sparks, EMBER, embers, addFx, ownMat, shockRing } from './fx.js';
import { sfx } from './audio.js';
import { G, P, world } from './state.js';
import { isLive } from './soldiers.js';
import { damageSoldier } from './combat.js';
import { hurtPlayer } from './player.js';
import { rumble } from './rumble.js';
import { after } from './events.js';
import { popup } from './ui.js';

const R = 0.42, H = 1.1, BLAST = 5.5, HURT = 4.5;
const std = o => new THREE.MeshStandardMaterial(o);
const mats = {
  drum: std({ color: 0xa3180e, roughness: 0.4, metalness: 0.45 }),
  band: std({ color: 0xe0a51a, roughness: 0.5, emissive: 0xff7a1a, emissiveIntensity: 0.35 }),
  lid: std({ color: 0x2a2a2a, roughness: 0.6, metalness: 0.6 }),
  scorch: new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.65, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -16 }),
};
const drumGeo = new THREE.CylinderGeometry(R, R, H, 18).translate(0, H / 2, 0);
const bandGeo = new THREE.CylinderGeometry(R + 0.012, R + 0.012, 0.16, 18);
const lidGeo = new THREE.CylinderGeometry(R * 0.96, R * 0.96, 0.03, 18);
const scorchGeo = new THREE.CircleGeometry(2.6, 20).rotateX(-Math.PI / 2);
const ballGeo = new THREE.IcosahedronGeometry(1, 2);

/** Put a stage's barrels in place (called once the stage is built). */
export function spawnBarrels(list) {
  world.barrels = [];
  for (const [x, y, z] of list) {
    const g = new THREE.Group(); g.position.set(x, y, z);
    for (const [geo, mat, py] of [[drumGeo, mats.drum, 0], [bandGeo, mats.band, 0.35], [bandGeo, mats.band, 0.8], [lidGeo, mats.lid, H]]) {
      const m = new THREE.Mesh(geo, mat); m.position.y = py; m.castShadow = true; g.add(m);
    }
    level.group.add(g);
    const box = { min: new V3(x - R, y, z - R), max: new V3(x + R, y + H, z + R) };
    level.boxes.push(box);
    world.barrels.push({ pos: new V3(x, y, z), mesh: g, box, live: true });
  }
}

/** The nearest barrel a ray hits before tMax, or null. */
export function barrelAlong(origin, dir, tMax) {
  let best = null, bt = tMax;
  for (const b of world.barrels) {
    if (!b.live) continue;
    const t = rayAABB(origin, dir, b.box.min.x, b.box.min.y, b.box.min.z, b.box.max.x, b.box.max.y, b.box.max.z, bt);
    if (t < bt) { bt = t; best = b; }
  }
  return best ? { b: best, t: bt } : null;
}
/** The barrel whose body contains p (a bullet that just hit something), or null. */
export function barrelAt(p) {
  return world.barrels.find(b => b.live && p.x > b.box.min.x - 0.12 && p.x < b.box.max.x + 0.12 && p.z > b.box.min.z - 0.12 && p.z < b.box.max.z + 0.12
    && p.y > b.box.min.y - 0.1 && p.y < b.box.max.y + 0.12) || null;
}

/** Blow a barrel up. chain counts how many barrels set this one off. */
export function explodeBarrel(b, chain = 0) {
  if (!b || !b.live) return;
  b.live = false;
  level.group.remove(b.mesh);
  const i = level.boxes.indexOf(b.box); if (i >= 0) level.boxes.splice(i, 1);
  const c = new V3(b.pos.x, b.pos.y + 0.6, b.pos.z);
  // fireball, shockwave, sparks, a scorch mark and a spinning lid
  const ball = new THREE.Mesh(ballGeo, ownMat(THREE.MeshBasicMaterial, { color: new THREE.Color(3.2, 1.1, 0.25), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
  ball.position.copy(c);
  addFx(ball, 0.45, (o, k) => { o.scale.setScalar(0.6 + k * BLAST * 0.9); o.material.opacity = 0.8 * (1 - k) * (1 - k); });
  shockRing(tmpA.set(b.pos.x, b.pos.y, b.pos.z), [3, 1.3, 0.3], BLAST, 0.4);
  sparks.emit(c, 90, 11, EMBER[0], EMBER[1], EMBER[2], 0.7, 3);
  embers(c, 40, 6, 0.6, 4);
  const scorch = new THREE.Mesh(scorchGeo, mats.scorch); scorch.position.set(b.pos.x, b.pos.y + 0.02, b.pos.z); level.group.add(scorch);
  const lid = new THREE.Mesh(lidGeo, mats.lid); lid.position.copy(c);
  const lv = new V3((Math.random() - 0.5) * 6, 12, (Math.random() - 0.5) * 6); let last = 0;
  addFx(lid, 1.6, (o, k) => { const d = (k - last) * 1.6; last = k; lv.y -= 24 * d; o.position.addScaledVector(lv, d); o.rotation.x += 14 * d; o.rotation.z += 9 * d; });
  sfx.explosion();
  G.flash = Math.max(G.flash, 0.4); G.shake = Math.max(G.shake, 0.8); G.hitStop = Math.max(G.hitStop, 0.06);
  rumble(0.5, 0.7, 240);
  const tags = chain ? ['KABOOM', 'CHAIN REACTION'] : ['KABOOM'];
  if (chain) popup(tmpA.set(c.x, c.y + 1.5, c.z), `CHAIN ×${chain + 1}`, 'gold');
  // everyone in the blast
  for (const s of world.soldiers) {
    if (!isLive(s)) continue;
    const dx = s.pos.x - c.x, dz = s.pos.z - c.z, d = Math.hypot(dx, dz);
    if (d > BLAST || Math.abs(s.pos.y - b.pos.y) > 3) continue;
    s.knock.set(dx / (d || 1) * 14, 8, dz / (d || 1) * 14);
    damageSoldier(s, s.boss ? 220 : 999, false, new V3(dx, 0, dz).normalize(), tags);
  }
  for (const dr of world.drones || []) if (!dr.dead && dr.pos.distanceTo(c) < BLAST + 1) dr.hurt(999, tags);
  const pd = Math.hypot(P.pos.x - c.x, P.pos.z - c.z);
  if (G.mode === 'play' && pd < HURT && Math.abs(P.pos.y - b.pos.y) < 2.5 && P.invT <= 0) {
    hurtPlayer(Math.round(10 + 30 * (1 - pd / HURT)));
    P.vel.set((P.pos.x - c.x) / (pd || 1) * 10, 8, (P.pos.z - c.z) / (pd || 1) * 10);
  }
  // other barrels in reach go up a moment later
  for (const o of world.barrels) {
    if (!o.live || o.pos.distanceTo(b.pos) > BLAST) continue;
    after(0.14, () => explodeBarrel(o, chain + 1));
  }
}

/** Set off every barrel within r of p (Hellfire). */
export function explodeBarrelsNear(p, r) {
  for (const b of world.barrels) if (b.live && b.pos.distanceTo(p) < r) after(0.05 + Math.random() * 0.2, () => explodeBarrel(b));
}
