// The later stages: container docks, a subway station, a construction site, a night market and a nightclub.
// They are built with the same helpers as levels.js (see `kit` there); the subway and the club also animate.
import * as THREE from 'three';
import { V3, rand, mulberry32, clamp } from './util.js';
import { M, PM, WM, neonMats } from './materials.js';
import { corrugatedTex, concreteFloorTex, sidewalkTex, roofTex, tileTex, normalFor, puddleRough } from './textures.js';
import { relief } from './materials.js';
import { stepBlock, siteOffice, palletCrate, drumCluster } from './props.js';
import { level } from './physics.js';
import { kit } from './levels.js';
import { G, P, world } from './state.js';
import { sfx } from './audio.js';
import { isLive } from './soldiers.js';
import { damageSoldier } from './combat.js';
import { hurtPlayer } from './player.js';
import { rumble } from './rumble.js';
import { scene, hemi } from './engine.js';
import { callout } from './ui.js';
import { embers } from './fx.js';
import { after, dropBody, warnMarker, surfaceY, startRain, raining, lightning } from './events.js';
import { lightShaft } from './atmosphere.js';

const std = o => new THREE.MeshStandardMaterial(o);
const glow = (r, g, b) => new THREE.MeshBasicMaterial({ color: new THREE.Color(r, g, b) });
const MM = {
  // docks
  containers: [0xc0402a, 0x2f6fae, 0x3f8a48, 0xe0a52a, 0x8a9094, 0xf0ece2, 0x9a4278, 0x2f9a96]
    .map(c => std({ map: corrugatedTex, color: c, roughness: 0.6, metalness: 0.25 })),
  wetConcrete: std({ map: concreteFloorTex, color: 0x9a948c, roughness: 0.22, metalness: 0.15 }),
  sea: std({ color: 0x06121a, roughness: 0.06, metalness: 0.9 }),
  hull: std({ color: 0x4a1612, roughness: 0.6, metalness: 0.3 }),
  deck: std({ color: 0x3a4a3c, roughness: 0.8, metalness: 0.2 }),
  white: std({ color: 0xd8d4cc, roughness: 0.6 }),
  crane: std({ color: 0xd9a91a, roughness: 0.5, metalness: 0.5 }),
  bollard: std({ color: 0x1c1c1c, roughness: 0.5, metalness: 0.6 }),
  // subway
  tile: std({ map: tileTex, roughness: 0.3 }),
  platform: std({ map: concreteFloorTex, color: 0x8a8680, roughness: 0.5 }),
  rail: std({ color: 0x9fa3a6, roughness: 0.25, metalness: 0.95 }),
  sleeper: std({ color: 0x3a2c20, roughness: 0.95 }),
  ballast: std({ map: roofTex, color: 0x6a625a, roughness: 1 }),
  train: std({ color: 0xa8adb2, roughness: 0.3, metalness: 0.8 }),
  stripe: std({ color: 0xb8321c, roughness: 0.4, metalness: 0.3 }),
  trainWin: glow(0.7, 0.66, 0.5),
  headlight: glow(2.4, 2.3, 2),
  fluoro: glow(1.15, 1.2, 1.1),
  vending: std({ color: 0x1f3a5a, roughness: 0.4, metalness: 0.4 }),
  vendingLit: glow(1.4, 1.2, 0.8),
  // construction
  dirt: std({ map: roofTex, color: 0x6a5a48, roughness: 1 }),
  concreteRaw: std({ map: concreteFloorTex, color: 0xb0aa9e, roughness: 0.85 }),
  plywood: std({ color: 0xb08a5a, roughness: 0.9 }),
  rebar: std({ color: 0x5a3a2a, roughness: 0.8, metalness: 0.5 }),
  netting: std({ color: 0x2f7a3a, roughness: 0.9, transparent: true, opacity: 0.45, side: THREE.DoubleSide, depthWrite: false }),
  pipe: std({ color: 0x8a847a, roughness: 0.9 }),
  // market
  cobble: std({ map: sidewalkTex, color: 0x7a7068, roughness: 0.35, metalness: 0.1 }),
  tarps: [0x8a1c14, 0x1c4a8a, 0xc28a1a, 0x2f6a3a, 0x7a2a6a].map(c => std({ color: c, roughness: 0.8, side: THREE.DoubleSide })),
  lanterns: [glow(1.5, 0.32, 0.12), glow(1.5, 0.8, 0.22), glow(1.3, 0.18, 0.14)],
  goods: std({ color: 0x7a5030, roughness: 0.7, emissive: 0x5a2a0c, emissiveIntensity: 0.5 }),
  wire: std({ color: 0x111111, roughness: 0.9 }),
  gate: std({ color: 0x9a1c12, roughness: 0.5 }),
  // club
  clubWall: std({ color: 0x100c10, roughness: 0.9 }),
  clubFloor: std({ color: 0x141214, roughness: 0.2, metalness: 0.5 }),
  speaker: std({ color: 0x0b0b0c, roughness: 0.6 }),
  cone: std({ color: 0x1e1e20, roughness: 0.4, metalness: 0.3 }),
  chrome: std({ color: 0xd0d0d0, roughness: 0.12, metalness: 1 }),
  barTop: std({ color: 0x2a1a14, roughness: 0.3, metalness: 0.2 }),
  barLit: glow(0.9, 0.3, 1.3),
};

// relief on the new stages' surfaces; the docks quay and the market cobbles are wet too
for (const m of MM.containers) relief(m, normalFor(corrugatedTex, 3));
relief(MM.wetConcrete, normalFor(concreteFloorTex, 2), 0.8); relief(MM.platform, normalFor(concreteFloorTex, 2), 0.7);
relief(MM.tile, normalFor(tileTex, 3), 0.9); relief(MM.concreteRaw, normalFor(concreteFloorTex, 2.5));
relief(MM.cobble, normalFor(sidewalkTex, 3)); relief(MM.dirt, normalFor(roofTex, 2.5)); relief(MM.ballast, normalFor(roofTex, 3));
for (const m of [MM.wetConcrete, MM.cobble]) { m.roughnessMap = puddleRough; m.roughness = 0.9; m.needsUpdate = true; }

// ---- shared bits
/** A shipping container (solid, outlined) with door bars on one end. */
function container(x, y, z, alongX, len, mat) {
  const sx = alongX ? len : 2.44, sz = alongX ? 2.44 : len;
  kit.addBox(x, y, z, sx, 2.59, sz, mat, 1 / 2.6, 1 / 2.6);
  for (const o of [-0.45, 0.45]) {
    if (alongX) kit.decorBox(x + len / 2 + 0.02, y + 0.15, z + o, 0.05, 2.3, 0.06, M.iron);
    else kit.decorBox(x + o, y + 0.15, z + len / 2 + 0.02, 0.06, 2.3, 0.05, M.iron);
  }
}
/** A stack of containers of height n at (x, z). */
function stack(x, z, n, alongX, len, R) {
  for (let i = 0; i < n; i++) container(x + (R() - 0.5) * 0.3, i * 2.6, z + (R() - 0.5) * 0.3, alongX, len, MM.containers[(R() * MM.containers.length) | 0]);
}
/** A floodlight mast with its lamp and light. */
function floodMast(x, z, h, color = 0xffc890, intensity = 160, dist = 48) {
  kit.decorBox(x, 0, z, 0.35, h, 0.35, PM.pole);
  kit.decorBox(x, h, z, 2.2, 0.5, 0.7, PM.pole);
  kit.decorBox(x, h - 0.08, z, 2, 0.1, 0.55, PM.lens);
  kit.addSolid(x, 0, z, 0.4, h, 0.4);
  kit.addLight(color, intensity, dist, x, h - 0.6, z);
  lightShaft(x, h - 0.2, z, 0, 7, color);
}

// ---- Docks: container stacks, a moored freighter, a gantry crane and cold black water
function buildDocks() {
  level.floorY = -1e9;
  kit.setSky(0x0a0e14, 0x121a22, 0.009, 0xb8c8ff, 2.2);
  const R = mulberry32(5150);
  const sea = new THREE.Mesh(new THREE.PlaneGeometry(700, 700).rotateX(-Math.PI / 2), MM.sea);
  sea.position.y = -1.6; level.group.add(sea);
  // quay and piers: tops at y = 0
  for (const [x, z, sx, sz] of [[0, 0, 72, 40], [-24, 32, 12, 24], [20, -30, 14, 20]])
    kit.addBox(x, -4, z, sx, 4, sz, MM.wetConcrete, 1 / 8, 1 / 8);
  // painted edge line and bollards along the water
  for (const [x, z, sx, sz] of [[0, -19.6, 72, 0.18], [36 - 0.4, 0, 0.18, 40]]) kit.decorBox(x, 0, z, sx, 0.01, sz, WM.safety);
  for (let z = -16; z <= 16; z += 8) { kit.decorGeo(new THREE.CylinderGeometry(0.28, 0.34, 0.7, 10), MM.bollard, 35.2, 0.35, z); kit.addSolid(35.2, 0, z, 0.6, 0.7, 0.6); }
  // container yard: rows with lanes between, stepped heights so you can climb from low to high
  const rows = [
    [-12, [[-26, 2], [-13, 3], [2, 1], [15, 2], [27, 3]]],
    [-4, [[-28, 1], [-17, 2], [8, 3], [22, 1]]],
    [8, [[-26, 3], [-12, 1], [4, 2], [18, 3]]],
    [15, [[-18, 2], [-4, 1], [12, 2], [26, 1]]],
  ];
  for (const [z, list] of rows) for (const [x, n] of list) stack(x, z, n, true, R() < 0.35 ? 6.1 : 12.2, R);
  // pier stacks
  stack(-24, 30, 2, false, 12.2, R); stack(-24, 40, 1, false, 6.1, R); stack(20, -32, 3, true, 12.2, R);
  // the freighter: hull top at 3 m, a gangway of steps up from the quay, containers and a white bridge on deck
  kit.addBox(42, -4, 0, 12, 7, 64, MM.hull, 1 / 4, 1 / 8);
  kit.decorBox(42, 3, 0, 11.6, 0.02, 63.6, MM.deck);
  solidPropSteps(36, 0, 3);
  for (const z of [-20, -6, 8]) stack(42, z, 1 + ((R() * 2) | 0), false, 12.2, R);
  kit.addBox(42, 3, 24, 10, 9, 8, MM.white, 1 / 4, 1 / 4);
  kit.decorBox(42, 10, 19.95, 9.4, 1.2, 0.1, MM.fluoro);
  kit.addBox(42, 12, 24, 6, 1.2, 5, MM.white, 1 / 4, 1 / 4);
  kit.addLight(0xd8e4ff, 30, 22, 42, 11, 18);
  // gantry crane straddling quay and ship: climb a leg, run the beam at 22 m
  for (const x of [30, 52]) for (const z of [-14, -4]) { kit.addBox(x, 0, z, 1.2, 22, 1.2, MM.crane, 1 / 2, 1 / 2); }
  kit.addBox(41, 22, -9, 36, 1.4, 1.6, MM.crane, 1 / 2, 1 / 2);
  kit.addBox(41, 22, -14, 36, 1.4, 1.2, MM.crane, 1 / 2, 1 / 2);
  kit.addBox(41, 22, -4, 36, 1.4, 1.2, MM.crane, 1 / 2, 1 / 2);
  kit.addBox(38, 18.5, -9, 4, 3.2, 4, MM.white, 1 / 2, 1 / 2);
  kit.decorBox(38, 19.5, -11.05, 3.4, 1.2, 0.1, MM.fluoro);
  // lights: tall masts round the yard
  for (const [x, z] of [[-34, -18], [-34, 18], [0, -18], [0, 18], [30, 18], [-24, 42]]) floodMast(x, z, 16);
  kit.addSkyline(30, 170, 260, rand, [20, 70], -1.6);
  kit.addMoon(90, 100, -260, 40);
  level.spawns = [
    [-33, 0, 0], [-8, -17, 0], [10, 17, 0], [30, 2, 0], [-24, 38, 0], [20, -36, 0],
    [-13, -12, 7.8], [27, -12, 7.8], [8, -4, 7.8], [-26, 8, 7.8], [42, -6, 3], [42, 10, 3],
  ];
  return { name: 'docks', label: 'DOCKS', start: new V3(0, 0, 0), orbitY: 5, killY: -3, spawnJitter: 0.5, event: craneDrop([]),
    barrels: [[-20, 0, -16], [5, 0, 2], [-8, 0, 12], [28, 0, -7], [-30, 0, 4], [14, 0, 11.5], [-22, 0, 27]] };
}
const inBox = (p, b, r) => p.x > b.min.x - r && p.x < b.max.x + r && p.z > b.min.z - r && p.z < b.max.z + r && p.y < b.max.y && p.y > b.min.y - 2;
/** Docks event: the crane drops a container where you're standing. It crushes whoever's under it and stays as cover. */
function craneDrop(dropped) {
  return () => {
    const x = P.pos.x + rand(-1.5, 1.5), z = P.pos.z + rand(-1.5, 1.5), y = surfaceY(x, z, P.pos.y + 0.5);
    if (y < -100) return; // over the water
    const alongX = Math.random() < 0.5, sx = alongX ? 6.1 : 2.44, sz = alongX ? 2.44 : 6.1;
    callout('CRANE DROP'); sfx.alarm();
    warnMarker(x, y, z, 3.6, 2.4);
    after(2.4, () => {
      const geo = new THREE.BoxGeometry(sx, 2.59, sz); geo.translate(0, 1.295, 0);
      const mesh = new THREE.Mesh(geo, MM.containers[(Math.random() * MM.containers.length) | 0]);
      mesh.castShadow = mesh.receiveShadow = true;
      mesh.add(new THREE.LineSegments(new THREE.EdgesGeometry(geo), M.edge));
      mesh.position.set(x, y + 26, z); level.group.add(mesh);
      sfx.whoosh(0.5);
      dropBody(mesh, y, () => {
        const box = { min: new V3(x - sx / 2, y, z - sz / 2), max: new V3(x + sx / 2, y + 2.59, z + sz / 2) };
        for (const s of world.soldiers) if (isLive(s) && inBox(s.pos, box, 0.3)) damageSoldier(s, s.boss ? 400 : 999, false, new V3(0, -1, 0), ['CRUSHED']);
        if (G.mode === 'play' && inBox(P.pos, box, P.r)) { if (P.invT <= 0) hurtPlayer(45); P.pos.y = box.max.y + 0.05; P.vel.set(0, 5, 0); }
        level.boxes.push(box);
        dropped.push({ mesh, box });
        if (dropped.length > 4) { const o = dropped.shift(); level.group.remove(o.mesh); level.boxes.splice(level.boxes.indexOf(o.box), 1); }
        sfx.crash(); G.shake = Math.max(G.shake, 0.9); rumble(0.5, 0.7, 250);
        embers(new V3(x, y + 0.3, z), 40, 6, 0.5, 4);
      });
    });
  };
}

/** Steps from the quay (y) up to a deck at `top`, climbing toward +x at x. */
function solidPropSteps(x, y, top) {
  for (let h = 1.1, i = 0; h < top + 0.01; h += 1.1, i++) {
    const hh = Math.min(h, top);
    kit.solidProp(stepBlock(1.2, hh, 2.6), x - 2.4 + i * 1.2, y, 0, 1.2, hh, 2.6);
  }
}

// ---- Subway: two platforms either side of the track, a bridge over it, and a train that doesn't stop
const TRAIN = { len: 38, top: 3.6, speed: 26, half: 1.6 };
function buildSubway() {
  level.floorY = 0;
  kit.setSky(0x050404, 0x0a0806, 0.02, 0xffe2c0, 0.25);
  const HX = 46, HZ = 14, CEIL = 7.5;
  kit.addFloor(HX * 2 + 280, 8, MM.ballast, 4);
  // platforms (tops at 1.2), their edges and the tactile strip
  const edgeMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0.75, 0.55, 0.1) });
  for (const s of [-1, 1]) {
    kit.addBox(0, 0, s * 8.5, HX * 2, 1.2, 11, MM.platform, 1 / 6, 1 / 6);
    kit.decorBox(0, 1.2, s * 3.35, HX * 2, 0.01, 0.6, edgeMat);
  }
  // rails and sleepers down the whole run
  for (const z of [-0.72, 0.72]) kit.decorBox(0, 0.12, z, 400, 0.14, 0.09, MM.rail);
  for (let x = -198; x <= 198; x += 1.2) kit.decorBox(x, 0, 0, 0.26, 0.12, 2.6, MM.sleeper);
  // tiled walls; end walls with the tunnel mouths
  for (const s of [-1, 1]) {
    kit.addBox(0, 0, s * (HZ + 0.5), HX * 2 + 2, CEIL, 1, MM.tile, 1 / 4, 1 / 4, { edges: false });
    for (const zs of [-1, 1]) kit.addBox(s * (HX + 0.5), 0, zs * 8.6, 1, CEIL, 10.8, MM.tile, 1 / 4, 1 / 4, { edges: false });
    kit.addBox(s * (HX + 0.5), 4.6, 0, 1, CEIL - 4.6, 6.4, MM.tile, 1 / 4, 1 / 4, { edges: false });
    // the tunnel beyond: walls and roof so the train comes out of darkness
    for (const zs of [-1, 1]) kit.addBox(s * (HX + 76), 0, zs * 3.6, 150, 4.6, 0.8, WM.block, 1 / 4, 1 / 4, { edges: false });
    kit.addBox(s * (HX + 76), 4.6, 0, 150, 1, 8, WM.block, 1 / 4, 1 / 4, { edges: false });
    kit.addLight(0xff8040, 8, 14, s * (HX + 20), 3.8, 0);
  }
  kit.addBox(0, CEIL, 0, HX * 2 + 2, 1, HZ * 2 + 2, MM.platform, 1 / 6, 1 / 6, { edges: false });
  // columns: wall-run and climb them
  for (const s of [-1, 1]) for (let x = -40; x <= 40; x += 10) kit.addBox(x, 1.2, s * 6.2, 0.7, CEIL - 1.2, 0.7, MM.tile, 1 / 2, 1 / 2);
  // the bridge over the track at 4.6, with steps up from each platform
  kit.addBox(0, 4.2, 0, 6, 0.4, HZ * 2, MM.platform, 1 / 4, 1 / 4);
  for (const s of [-1, 1]) for (let i = 0; i < 3; i++) {
    const h = 1.1 * (i + 1);
    kit.solidProp(stepBlock(2.4, h, 1.2), -4.8, 1.2, s * (10.5 + i * 1.2), 2.4, h, 1.2); // tallest by the wall, next to the bridge
  }
  // fluorescent strips, lights, benches, vending machines, signs
  for (const s of [-1, 1]) for (let x = -40; x <= 40; x += 5) kit.decorBox(x, CEIL - 0.12, s * 8.5, 3.2, 0.1, 0.25, MM.fluoro);
  for (const s of [-1, 1]) for (const x of [-35, -15, 5, 25]) kit.addLight(0xeef4ff, 14, 16, x, CEIL - 0.6, s * 8.5);
  for (const s of [-1, 1]) for (const x of [-30, -20, 15, 35]) kit.solidProp([{ geo: new THREE.BoxGeometry(3, 0.45, 0.6).translate(0, 0.225, 0), mat: M.iron }], x, 1.2, s * 12.8, 3, 0.45, 0.6);
  for (const s of [-1, 1]) for (const x of [-25, 20]) {
    kit.solidProp([
      { geo: new THREE.BoxGeometry(1.1, 2, 0.8).translate(0, 1, 0), mat: MM.vending },
      { geo: new THREE.BoxGeometry(0.8, 1.2, 0.02).translate(0, 1.2, s < 0 ? 0.41 : -0.41), mat: MM.vendingLit },
    ], x, 1.2, s * 13.4, 1.1, 2, 0.8);
  }
  for (const s of [-1, 1]) for (const x of [-10, 30]) kit.addBox(x, 4, s * 13.8, 6, 2.4, 0.3, neonMats[x > 0 ? 1 : 0], 1 / 6, 1 / 6, { edges: false });
  // the train
  const train = makeTrain();
  level.group.add(train.group);
  level.boxes.push(train.box);
  level.spawns = [];
  for (const s of [-1, 1]) for (const x of [-38, -22, -8, 12, 28, 40]) level.spawns.push([x, s * 9.5, 1.2]);
  level.spawns.push([0, 6, 4.6], [0, -6, 4.6]);
  return {
    name: 'subway', label: 'SUBWAY', start: new V3(0, 1.2, 8.5), orbitY: 2.5, orbitR: 5, killY: -1e9, spawnJitter: 0.4,
    barrels: [[-30, 1.2, 10], [24, 1.2, -10], [-12, 1.2, -12], [36, 1.2, 11], [10, 1.2, 12.5], [-38, 1.2, -9]],
    update: dt => updateTrain(train, edgeMat, dt),
    event: () => { train.express = true; if (train.wait > 1.2) train.wait = 1.2; callout('EXPRESS TRAIN'); },
  };
}
function makeTrain() {
  const group = new THREE.Group();
  const add = (geo, mat, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; group.add(m); return m; };
  const CAR = 12.2;
  for (let c = 0; c < 3; c++) {
    const cx = (c - 1) * (CAR + 0.6);
    add(new THREE.BoxGeometry(CAR, 3.1, 3), MM.train, cx, 0.4 + 1.55, 0);
    add(new THREE.BoxGeometry(CAR - 0.4, 0.9, 3.02), MM.trainWin, cx, 2.35, 0);
    add(new THREE.BoxGeometry(CAR, 0.3, 3.03), MM.stripe, cx, 1.3, 0);
    for (const dx of [-3.4, 0, 3.4]) add(new THREE.BoxGeometry(1.3, 2.3, 3.04), M.iron, cx + dx, 1.6, 0);
    add(new THREE.BoxGeometry(2.4, 0.4, 1.6), M.iron, cx, 3.7, 0);
    for (const dx of [-4.2, 4.2]) add(new THREE.BoxGeometry(2.2, 0.5, 2.4), M.iron, cx + dx, 0.3, 0);
  }
  const endX = (CAR * 3 + 1.2) / 2;
  for (const s of [-1, 1]) for (const z of [-0.9, 0.9]) add(new THREE.BoxGeometry(0.08, 0.3, 0.5), MM.headlight, s * endX, 1.1, z);
  const lamp = new THREE.PointLight(0xfff0d0, 0, 26, 1.4); group.add(lamp);
  const box = { min: new V3(), max: new V3() };
  return { group, box, lamp, x: -150, dir: 1, wait: 5, horn: false, sound: 0 };
}
function updateTrain(tr, edgeMat, dt) {
  const prevX = tr.x;
  if (tr.wait > 0) {
    tr.wait -= dt;
    tr.group.visible = false;
    tr.box.min.set(1e6, 0, 0); tr.box.max.set(1e6, 0, 0);
  } else {
    tr.group.visible = true;
    tr.x += tr.dir * TRAIN.speed * (tr.express ? 2 : 1) * dt;
    if (Math.abs(tr.x) > 160) { tr.dir *= -1; tr.x = tr.dir * -150; tr.wait = 9 + Math.random() * 6; tr.horn = false; tr.express = false; }
  }
  const dx = tr.wait > 0 ? 0 : tr.x - prevX;
  tr.group.position.set(tr.x, 0, 0);
  tr.lamp.position.set(tr.dir * (TRAIN.len / 2 + 2), 1.4, 0);
  tr.lamp.intensity = tr.wait > 0 ? 0 : 22;
  if (tr.wait <= 0) {
    tr.box.min.set(tr.x - TRAIN.len / 2, 0.25, -TRAIN.half);
    tr.box.max.set(tr.x + TRAIN.len / 2, TRAIN.top, TRAIN.half);
  }
  // warning: the platform edge flashes while it's coming, and a horn sounds
  const ahead = tr.wait <= 0 && tr.x * tr.dir < 0 && Math.abs(tr.x) < 110;
  const warn = tr.wait <= 0 && Math.abs(tr.x) < 110 + TRAIN.len;
  const flash = warn && Math.sin(G.clock * 14) > 0;
  edgeMat.color.setRGB(flash ? 2 : 0.75, flash ? 0.35 : 0.55, flash ? 0.1 : 0.1);
  if (ahead && !tr.horn && Math.abs(tr.x) < 100) { tr.horn = true; if (G.mode === 'play') sfx.horn(); }
  if (tr.wait <= 0 && G.mode === 'play') {
    tr.sound -= dt;
    const near = Math.abs(tr.x - P.pos.x);
    if (tr.sound <= 0 && near < 70) { tr.sound = 0.22; sfx.trainRumble(clamp(1 - near / 70, 0.05, 1)); if (near < 20) rumble(0.15, 0.3, 200); }
  }
  if (tr.wait > 0) return;
  // riders on the roof go with it
  const onRoof = b => Math.abs(b.pos.y - TRAIN.top) < 0.2 && Math.abs(b.pos.z) < TRAIN.half + 0.2 && Math.abs(b.pos.x - tr.x) < TRAIN.len / 2 + 0.2;
  if (P.grounded && onRoof(P)) P.pos.x += dx;
  for (const s of world.soldiers) if (onRoof(s)) s.pos.x += dx;
  // anyone on the track in front of it gets hit
  // anyone down on the track bed (below the platforms) is in its path, not just those dead centre
  const inPath = (b, r) => Math.abs(b.pos.x - tr.x) < TRAIN.len / 2 + r
    && (b.pos.y < 1.1 ? Math.abs(b.pos.z) < 3 : b.pos.y < TRAIN.top - 0.3 && Math.abs(b.pos.z) < TRAIN.half + r);
  if (G.mode === 'play' && inPath(P, P.r)) {
    if (P.invT <= 0) hurtPlayer(55);
    // thrown up onto the roof, carried along
    P.pos.y = TRAIN.top + 0.05; P.pos.x = tr.x - tr.dir * (TRAIN.len / 2 - 3);
    P.vel.set(tr.dir * 8, 7, (P.pos.z >= 0 ? 1 : -1) * 3);
    G.shake = Math.max(G.shake, 0.8);
  }
  for (const s of world.soldiers) {
    if (!isLive(s) || !inPath(s, s.r)) continue;
    s.knock.set(tr.dir * 18, 9, (s.pos.z >= 0 ? 1 : -1) * 4);
    damageSoldier(s, 9999, false, new V3(tr.dir, 0, 0), ['ROADKILL']);
  }
}

// ---- Construction site: a half-built tower you climb floor by floor, and a crane over it all
function buildSite() {
  level.floorY = 0;
  kit.setSky(0x0e0a08, 0x1a120c, 0.008, 0xffc890, 2.1);
  const R = mulberry32(8080);
  kit.addFloor(220, 220, MM.dirt, 6);
  // hoarding round the site
  for (const [x, z, sx, sz] of [[0, -42, 96, 0.3], [0, 42, 96, 0.3], [-48, 0, 0.3, 84], [48, 0, 0.3, 84]])
    kit.addBox(x, 0, z, sx, 2.6, sz, MM.plywood, 1 / 2.4, 1 / 2.4, { edges: false });
  // the tower: floors every 4.5 m, each smaller than the last; slabs reach the column faces so you can climb straight up
  const F = 4.5, xs = [-15, -7.5, 0, 7.5, 15], zs = [-12, -4, 4, 12];
  const floors = [
    { y: 0.3, x0: -15.3, x1: 15.3, z0: -12.3, z1: 12.3 },
    { y: F, x0: -15.3, x1: 15.3, z0: -12.3, z1: 12.3, hole: [8, 15.3, -12.3, -4] },
    { y: 2 * F, x0: -15.3, x1: 7.8, z0: -12.3, z1: 12.3 },
    { y: 3 * F, x0: -15.3, x1: 0.3, z0: -12.3, z1: 12.3 },
    { y: 4 * F, x0: -15.3, x1: -7.2, z0: -12.3, z1: 4.3 },
  ];
  const slab = (x0, x1, z0, z1, y) => ({ ...kit.addBox((x0 + x1) / 2, y - 0.4, (z0 + z1) / 2, x1 - x0, 0.4, z1 - z0, MM.concreteRaw, 1 / 6, 1 / 6, { keep: true }), x0, x1, z0, z1, y, stubs: [] });
  const chunks = []; // the pieces that can give way in a collapse (nothing else stands on them)
  slab(floors[0].x0, floors[0].x1, floors[0].z0, floors[0].z1, floors[0].y);
  { const f = floors[1], [hx0] = f.hole; slab(f.x0, hx0, f.z0, f.z1, f.y); chunks.push(slab(hx0, f.x1, f.hole[3], f.z1, f.y)); }
  { const f = floors[2]; slab(f.x0, 0.3, f.z0, f.z1, f.y); chunks.push(slab(0.3, f.x1, f.z0, f.z1, f.y)); }
  { const f = floors[3]; slab(f.x0, -7.2, f.z0, f.z1, f.y); chunks.push(slab(-7.2, f.x1, f.z0, f.z1, f.y)); }
  { const f = floors[4]; chunks.push(slab(f.x0, f.x1, f.z0, f.z1, f.y)); }
  const inside = (f, x, z) => x >= f.x0 && x <= f.x1 && z >= f.z0 && z <= f.z1;
  for (let i = 0; i + 1 < floors.length; i++) {
    const f = floors[i], up = floors[i + 1];
    for (const x of xs) for (const z of zs) {
      if (!inside(f, x, z)) continue;
      if (inside(up, x, z)) kit.addBox(x, f.y, z, 0.6, up.y - 0.4 - f.y, 0.6, MM.concreteRaw, 1 / 2, 1 / 2);
      else {
        const stub = kit.addBox(x, f.y, z, 0.6, 1.4, 0.6, MM.concreteRaw, 1 / 2, 1 / 2, { keep: true });
        const on = chunks.find(c => c.y === f.y && x >= c.x0 && x <= c.x1 && z >= c.z0 && z <= c.z1);
        if (on) on.stubs.push(stub);
      }
    }
  }
  // stairs up through the hole to the first floor
  for (let i = 0; i < 3; i++) { const h = 1.1 * (i + 1); kit.solidProp(stepBlock(2.2, h, 2.4), 9.5 + i * 2.2, 0.3, -5.2, 2.2, h, 2.4); }
  // scaffold on the north face: a deck at each floor, joined by ladders (climb them)
  for (let i = 1; i < 4; i++) {
    const y = i * F;
    kit.addBox(-4, y - 0.1, 13.6, 16, 0.1, 2, MM.plywood, 1 / 2, 1 / 2);
    kit.addBox(-11.5 + (i % 2) * 14, y - F, 14.2, 0.6, F, 0.2, M.iron, 1 / 2, 1 / 2);
    for (const x of [-12, -4, 4]) kit.decorBox(x, y - F, 14.55, 0.08, F + 1, 0.08, M.iron);
  }
  kit.decorGeo(new THREE.PlaneGeometry(10, 6).rotateY(Math.PI / 2), MM.netting, 7.9, 3 * F - 3, 4);
  // tower crane: climb the mast, run the jib at 28 m; a container hangs from the hook over the roof
  kit.addBox(26, 0, 18, 2, 28, 2, MM.crane, 1 / 2, 1 / 2);
  kit.addBox(10, 28, 18, 44, 1.2, 1.4, MM.crane, 1 / 2, 1 / 2);
  kit.addBox(26, 29.2, 18, 3, 2.4, 3, MM.crane, 1 / 2, 1 / 2);
  kit.addBox(30.5, 27, 18, 6, 1.2, 3, MM.pipe, 1 / 2, 1 / 2); // counterweight
  kit.decorBox(-4, 24.8, 18, 0.06, 3.2, 0.06, M.iron);
  container(-4, 22.2, 18, true, 6.1, MM.containers[3]);
  // site furniture
  kit.solidProp(siteOffice(10, 5, 6), -34, 0, -32, 10, 5, 6);
  kit.solidProp(siteOffice(10, 5, 6), -34, 5, -32, 10, 5, 6);
  for (const [x, z] of [[24, -20], [30, -8], [-28, 10], [-20, 26], [20, 30], [34, -30]]) kit.solidProp(palletCrate(), x, 0, z, 2.2, 1.3, 2.2);
  kit.solidProp(drumCluster(3, 2, R), 38, 0, 8, 1.9, 0.9, 1.3);
  for (const [x, z] of [[-30, -10], [-30, -6]]) { kit.decorGeo(new THREE.CylinderGeometry(1, 1, 5, 16).rotateZ(Math.PI / 2), MM.pipe, x, 1, z); kit.addSolid(x, 0, z, 5, 2, 2); }
  for (const [x, z, n] of [[24, 10, 2], [-38, 30, 1], [36, 30, 2]]) stack(x, z, n, R() < 0.5, 6.1, R);
  for (const [x, z] of [[-40, -38], [40, -38], [-40, 38], [40, 38], [0, -38], [-24, -18], [22, -18], [-24, 22]]) floodMast(x, z, 12, 0xfff0d8);
  for (const f of floors.slice(1, 4)) kit.addLight(0xffd8a0, 18, 14, (f.x0 + Math.min(f.x1, 5)) / 2, f.y + 3.2, 0);
  kit.addSkyline(34, 120, 220, rand, [25, 110], 0);
  kit.addMoon(-100, 110, -240, 42);
  level.spawns = [
    [-30, -24, 0], [30, -26, 0], [-36, 20, 0], [36, 24, 0], [0, 30, 0], [20, 0, 0], [-24, 0, 0],
    [-10, 0, F], [4, 8, F], [-10, -8, 2 * F], [2, 6, 2 * F], [-8, 0, 3 * F], [-4, 13.6, 2 * F],
  ];
  return { name: 'site', label: 'CONSTRUCTION', start: new V3(0, 0, -26), orbitY: 7, killY: -1e9, bounds: [-47.85, 47.85, -41.85, 41.85], spawnJitter: 0.5, event: collapse(chunks),
    barrels: [[-20, 0, -24], [18, 0, -28], [30, 0, 2], [-30, 0, 20], [-10, 4.5, -6], [-4, 9, 6], [26, 0, 14]] };
}

const onChunk = (p, c) => p.x >= c.x0 && p.x <= c.x1 && p.z >= c.z0 && p.z <= c.z1 && Math.abs(p.y - c.y) < 0.4;
/** Construction event: a floor section creaks, sheds dust, then drops out, taking whoever's on it. */
function collapse(chunks) {
  return () => {
    const left = chunks.filter(c => !c.gone);
    if (!left.length) return;
    const busy = left.find(c => onChunk(P.pos, c)) || left.find(c => world.soldiers.some(s => isLive(s) && onChunk(s.pos, c)));
    const c = busy || left[(Math.random() * left.length) | 0];
    c.gone = true;
    callout('COLLAPSE'); sfx.creak();
    const cx = (c.x0 + c.x1) / 2, cz = (c.z0 + c.z1) / 2;
    warnMarker(cx, c.y, cz, Math.min(c.x1 - c.x0, c.z1 - c.z0) / 2, 2.2, [2.4, 1.4, 0.3]);
    for (let k = 0; k < 9; k++) after(k * 0.24, () => {
      embers(new V3(rand(c.x0, c.x1), c.y - 0.6, rand(c.z0, c.z1)), 8, 1.2, 0.6, 1);
      G.shake = Math.max(G.shake, 0.22);
    });
    after(2.2, () => {
      for (const part of [c, ...c.stubs]) {
        const i = level.boxes.indexOf(part.box); if (i >= 0) level.boxes.splice(i, 1);
        dropBody(part.mesh, part.mesh.position.y - 40, null);
        after(1.6, () => level.group.remove(part.mesh));
      }
      sfx.crash(); G.shake = Math.max(G.shake, 0.8); rumble(0.5, 0.6, 260);
      embers(new V3(cx, c.y, cz), 50, 6, 0.6, 3);
    });
  };
}

// ---- Night market: neon lanes, stalls you can run across, lanterns strung overhead, rooftops joined by planks
function buildMarket() {
  level.floorY = 0;
  kit.setSky(0x0c0608, 0x1a0a0c, 0.012, 0xffb090, 0.6);
  const R = mulberry32(2626), rr = (a, b) => a + R() * (b - a);
  kit.addFloor(200, 200, MM.cobble, 6);
  const LANE = 6, CROSS = 5, END = 52, STYLES = ['brick', 'concrete', 'brick'];
  const roofs = [];
  // buildings along both sides of the main lane (z) and the cross lane (x), with alleys between
  for (const sz of [-1, 1]) for (const sx of [-1, 1]) {
    let x = CROSS;
    while (x < END - 6) {
      const w = Math.min(rr(9, 14), END - 2 - x); if (w < 6) break;
      const top = Math.round(rr(8, 14)), cx = sx * (x + w / 2), cz = sz * (LANE + 7);
      kit.building(cx, cz, w, 14, 0, top, STYLES[(R() * 3) | 0], R, { shops: true, fireEscape: R() < 0.5, clutter: true });
      if (R() < 0.5) kit.addBox(sx * (x + 1.2), 3.8, sz * (LANE + 0.35), 1.1, 5, 0.3, neonMats[(R() * 2) | 0], 1 / 5, 1 / 5, { edges: false });
      roofs.push([cx, cz, top]);
      x += w + (R() < 0.5 ? 3 : 0.6);
    }
  }
  // closing walls: tall blocks at the lane ends and behind
  for (const [x, z, w, d] of [[0, -40, (END - 0) * 2, 12], [0, 40, END * 2, 12], [-END - 6, 0, 12, 92], [END + 6, 0, 12, 92]])
    kit.building(x, z, w, d, 0, 30, 'concrete', R);
  // red gates at the lane ends
  for (const s of [-1, 1]) {
    for (const z of [-LANE + 0.6, LANE - 0.6]) kit.addBox(s * (END - 2), 0, z, 0.7, 7, 0.7, MM.gate, 1 / 2, 1 / 2);
    kit.decorBox(s * (END - 2), 7, 0, 1, 0.6, LANE * 2 + 2, MM.gate);
    kit.decorBox(s * (END - 2), 6.1, 0, 0.8, 0.35, LANE * 2, MM.gate);
  }
  // stalls down both sides of the main lane: counters to vault, tarp roofs to run across
  for (const sz of [-1, 1]) for (let x = -END + 6; x < END - 6; x += 5.5) {
    if (Math.abs(x) < CROSS + 2 || R() < 0.2) continue;
    const z = sz * (LANE - 1.6), tarp = MM.tarps[(R() * MM.tarps.length) | 0];
    kit.addBox(x, 0, z, 4, 1.05, 1.6, WM.pallet, 1 / 2, 1 / 2);
    for (const dx of [-1.9, 1.9]) kit.decorBox(x + dx, 1.05, z + sz * 0.7, 0.08, 1.4, 0.08, M.iron);
    kit.addBox(x, 2.45, z, 4.4, 0.08, 2.4, tarp, 1 / 2, 1 / 2);
    kit.decorBox(x, 1.05, z, 3.4, 0.25, 1.2, MM.goods); // goods on the counter
  }
  // lantern strings across the lanes
  const lanternGeo = new THREE.SphereGeometry(0.16, 10, 8);
  const string = (x0, z0, x1, z1, y, n) => {
    for (let i = 0; i <= n; i++) {
      const t = i / n, sag = Math.sin(t * Math.PI) * 1.1;
      const x = x0 + (x1 - x0) * t, z = z0 + (z1 - z0) * t;
      kit.decorGeo(lanternGeo.clone(), MM.lanterns[i % 3], x, y - sag - 0.3, z);
      if (i < n) {
        const nx = x0 + (x1 - x0) * (i + 1) / n, nz = z0 + (z1 - z0) * (i + 1) / n, len = Math.hypot(nx - x, nz - z);
        const w = new THREE.BoxGeometry(0.03, 0.03, len); w.lookAt(new V3(nx - x, 0, nz - z));
        kit.decorGeo(w, MM.wire, (x + nx) / 2, y - Math.sin((t + 0.5 / n) * Math.PI) * 1.1, (z + nz) / 2);
      }
    }
  };
  for (let x = -END + 8; x < END - 4; x += 8) string(x, -LANE - 0.2, x + 3, LANE + 0.2, 7, 9);
  for (let z = -30; z <= 30; z += 10) if (Math.abs(z) > LANE + 2) string(-CROSS, z, CROSS, z + 2, 7.5, 7);
  for (let x = -END + 8; x < END; x += 16) { const z = (x / 16) % 2 ? 2.5 : -2.5; kit.addLight(0xff7a40, 12, 18, x, 5.5, z); lightShaft(x, 6.3, z, 0, 2.2, 0xff5a40); }
  // plank bridges between facing roofs over the main lane
  for (let i = 0; i + 1 < roofs.length; i++) {
    const [ax, az, at] = roofs[i];
    const b = roofs.find(([bx, bz, bt]) => Math.sign(bz) !== Math.sign(az) && Math.abs(bx - ax) < 3 && Math.abs(bt - at) <= 2 && Math.abs(bz) < 20 && Math.abs(az) < 20);
    if (b && az < 0) kit.addBox(ax, Math.min(at, b[2]) - 0.1, 0, 1.2, 0.12, (LANE + 7) * 2 - 14 + 1, WM.pallet, 1 / 2, 1 / 2);
  }
  kit.addMoon(60, 110, -240, 38);
  level.spawns = [];
  for (let x = -END + 10; x < END - 8; x += 12) level.spawns.push([x, (R() - 0.5) * 3, 0]);
  for (let z = -28; z <= 28; z += 14) level.spawns.push([(R() - 0.5) * 3, z, 0]);
  for (const [x, z, t] of roofs) if (R() < 0.4) level.spawns.push([x, z, t]);
  const monsoon = () => {
    if (raining()) return;
    callout('MONSOON');
    const r = startRain(level.group), fog = scene.fog, d0 = fog.density;
    fog.density = d0 * 1.8;
    for (let i = 0, t = 2.5; i < 7; i++, t += rand(2.2, 3.4)) after(t, () => {
      // strikes land by soldiers more often than by you, and always marked a moment first
      const live = world.soldiers.filter(isLive);
      let x, z, y;
      if (live.length && Math.random() < 0.6) { const s = live[(Math.random() * live.length) | 0]; x = s.pos.x + rand(-1, 1); z = s.pos.z + rand(-1, 1); y = s.pos.y; }
      else { const a = rand(0, Math.PI * 2), d = rand(2.5, 6); x = P.pos.x + Math.cos(a) * d; z = P.pos.z + Math.sin(a) * d; y = P.pos.y; }
      lightning(x, z, y);
    });
    after(26, () => { r.stop(); if (scene.fog === fog) fog.density = d0; });
  };
  return { name: 'market', label: 'NIGHT MARKET', start: new V3(0, 0, 0), orbitY: 4, orbitR: 5.5, killY: -1e9, bounds: [-END, END, -34, 34], spawnJitter: 0.4, event: monsoon,
    barrels: [[-30, 0, 0.5], [20, 0, -1], [-8, 0, 2], [36, 0, 1.5], [1, 0, 20], [-1, 0, -18]] };
}

// ---- Nightclub: a pulsing dance floor, a stage with speaker stacks, a balcony ring and moving lights
function buildClub() {
  level.floorY = 0;
  kit.setSky(0x040204, 0x0a0408, 0.018, 0xb090ff, 0.2);
  MM.barLit.color.setRGB(0.9, 0.3, 1.3);
  const HX = 24, HZ = 18, H = 12, BAL = 5;
  kit.addFloor(HX * 2, HZ * 2, MM.clubFloor, 4);
  for (const s of [-1, 1]) {
    kit.addBox(0, 0, s * (HZ + 0.5), HX * 2 + 2, H, 1, MM.clubWall, 1 / 4, 1 / 4, { edges: false });
    kit.addBox(s * (HX + 0.5), 0, 0, 1, H, HZ * 2, MM.clubWall, 1 / 4, 1 / 4, { edges: false });
  }
  kit.addBox(0, H, 0, HX * 2 + 2, 1, HZ * 2 + 2, MM.clubWall, 1 / 4, 1 / 4, { edges: false });
  // dance floor: 8x8 tiles in four colour groups that pulse to the beat
  const tileMats = [0, 1, 2, 3].map(() => new THREE.MeshBasicMaterial({ color: new THREE.Color() }));
  for (let i = 0; i < 8; i++) for (let j = 0; j < 8; j++)
    kit.decorBox(-7 + i * 2, 0, -5 + j * 2, 1.9, 0.05, 1.9, tileMats[(i + j) % 2 + ((i >> 1) + (j >> 1)) % 2 * 2]);
  // stage and DJ booth at the north end, speaker stacks either side (climb them), an LED wall behind
  kit.addBox(0, 0, HZ - 3.5, 22, 1.4, 7, MM.speaker, 1 / 2, 1 / 2);
  kit.addBox(0, 1.4, HZ - 3.2, 5, 1.1, 1.4, MM.chrome, 1 / 2, 1 / 2);
  for (const s of [-1, 1]) {
    kit.addBox(s * 9, 1.4, HZ - 3, 3, 4.2, 2.4, MM.speaker, 1 / 2, 1 / 2);
    for (let k = 0; k < 3; k++) kit.decorGeo(new THREE.CylinderGeometry(0.55, 0.55, 0.06, 18).rotateX(Math.PI / 2), MM.cone, s * 9, 2.2 + k * 1.3, HZ - 4.23);
  }
  const ledMat = new THREE.MeshBasicMaterial({ color: new THREE.Color() });
  kit.addDecor(new THREE.BoxGeometry(18, 6, 0.2), ledMat, 0, 5.4, HZ - 0.2);
  // balcony round the other three sides at 5 m, a low rail to vault, steps up in one corner
  kit.addBox(0, BAL - 0.4, -HZ + 2.2, HX * 2, 0.4, 4.4, MM.clubWall, 1 / 4, 1 / 4);
  for (const s of [-1, 1]) kit.addBox(s * (HX - 2.2), BAL - 0.4, 1.2, 4.4, 0.4, 29.6, MM.clubWall, 1 / 4, 1 / 4);
  for (let x = -HX + 4.4; x < HX - 4.4; x += 6) kit.addBox(x + 2, BAL, -HZ + 4.35, 4, 1, 0.12, MM.chrome, 1 / 2, 1 / 2);
  for (const s of [-1, 1]) for (let z = -HZ + 6; z < HZ - 8; z += 6) kit.addBox(s * (HX - 4.35), BAL, z + 2, 0.12, 1, 4, MM.chrome, 1 / 2, 1 / 2);
  for (let i = 0; i < 4; i++) { const h = 1.1 * (i + 1); kit.solidProp(stepBlock(2.2, h, 1.2), -HX + 7.5, 0, -HZ + 9.6 - i * 1.2, 2.2, h, 1.2); }
  // bars under the balcony, chrome pillars to wall-run
  for (const s of [-1, 1]) {
    kit.addBox(s * (HX - 3.2), 0, 2, 1, 1.1, 14, MM.barTop, 1 / 2, 1 / 2);
    kit.decorBox(s * (HX - 0.05), 1.6, 2, 0.08, 2, 14, MM.barLit);
  }
  for (const x of [-12, 12]) for (const z of [-9, 7]) kit.addBox(x, 0, z, 0.8, H, 0.8, MM.chrome, 1 / 2, 1 / 2);
  // disco ball, sweeping lasers and three coloured lights that roam the room
  const ball = kit.addDecor(new THREE.IcosahedronGeometry(0.9, 1), MM.chrome, 0, H - 2.2, 0);
  kit.decorBox(0, H - 1.3, 0, 0.04, 1.3, 0.04, M.iron);
  const laserMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0.2, 3, 0.6), transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false });
  const lasers = [];
  for (let i = 0; i < 6; i++) {
    const g = new THREE.BoxGeometry(0.03, 0.03, 34); g.translate(0, 0, -17);
    const l = kit.addDecor(g, laserMat, -6 + i * 2.4, 6.5, HZ - 1); lasers.push(l);
  }
  const roam = [0xff2a6a, 0x2a8aff, 0xa02aff].map(c => { const l = new THREE.PointLight(c, 50, 26, 1.4); level.group.add(l); return l; });
  const wash = new THREE.PointLight(0xffffff, 0, 30, 1.2); wash.position.set(0, H - 1, 0); level.group.add(wash);
  level.spawns = [
    [-18, -12, 0], [18, -12, 0], [-18, 10, 0], [18, 10, 0], [0, -12, 0], [-8, 0, 0], [8, 0, 0],
    [-10, -HZ + 2.2, BAL], [10, -HZ + 2.2, BAL], [-HX + 2.2, 4, BAL], [HX - 2.2, -4, BAL], [0, HZ - 3.5, 1.4],
  ];
  let t = 0, dark = 0;
  const col = new THREE.Color();
  const emergency = new THREE.PointLight(0xff1a0a, 0, 40, 1.2); emergency.position.set(0, H - 1, -HZ + 2); level.group.add(emergency);
  return {
    name: 'club', label: 'NIGHTCLUB', start: new V3(0, 0.05, -2), orbitY: 4, orbitR: 12, killY: -1e9, spawnJitter: 0.4,
    barrels: [[-18, 0, -6], [18, 0, -8], [-14, 0, 9.5], [14, 0, 9.5], [0, 5, -16], [-21.5, 5, 6]],
    event: () => {
      if (dark > 0) return;
      // the power cuts: only muzzle flashes, visors and a red emergency light, and they can't see you either
      dark = 14; callout('BLACKOUT'); sfx.powerDown();
      hemi.intensity = 0.08; G.blackout = true; MM.barLit.color.setRGB(0.02, 0.005, 0.03);
      for (const l of [...roam, wash]) l.intensity = 0;
      lasers.forEach(l => { l.visible = false; });
    },
    update: dt => {
      t += dt;
      if (dark > 0) {
        dark -= dt;
        emergency.intensity = 10 + 8 * Math.sin(t * 2.2);
        for (const m of tileMats) m.color.setRGB(0.015, 0.01, 0.02);
        ledMat.color.setRGB(0.02, 0, 0);
        if (dark <= 0) {
          sfx.powerUp(); hemi.intensity = 1.1; G.blackout = false; emergency.intensity = 0; MM.barLit.color.setRGB(0.9, 0.3, 1.3);
          roam.forEach(l => { l.intensity = 50; }); lasers.forEach(l => { l.visible = true; });
        }
        return;
      }
      const beat = t * 148 / 60, pulse = Math.pow(1 - (beat % 1), 3); // bright on the beat, fading between
      tileMats.forEach((m, i) => m.color.setHSL(((beat / 8 + i * 0.25) % 1), 1, 0.12 + 0.35 * pulse * ((Math.floor(beat) + i) % 2 ? 1 : 0.45)).multiplyScalar(2.2));
      ledMat.color.setHSL((beat / 16) % 1, 0.9, 0.22 + 0.15 * pulse).multiplyScalar(1.8);
      roam.forEach((l, i) => l.position.set(Math.sin(t * 0.6 + i * 2.1) * 16, 6 + Math.sin(t * 0.9 + i) * 2, Math.cos(t * 0.45 + i * 2.1) * 11));
      wash.intensity = 6 * pulse; // a soft swell on the beat, no hard strobing
      ball.rotation.y += dt * 0.8;
      lasers.forEach((l, i) => { l.rotation.y = Math.sin(t * 0.7 + i) * 0.7; l.rotation.x = -0.12 - Math.abs(Math.sin(t * 0.5 + i * 0.6)) * 0.3; });
      laserMat.color.copy(col.setHSL((beat / 32 + 0.3) % 1, 1, 0.5)).multiplyScalar(3);
    },
  };
}

export const MAP_BUILDERS = { docks: buildDocks, subway: buildSubway, site: buildSite, market: buildMarket, club: buildClub };
