// Per-stage atmosphere: a sky dome (gradient, city glow, stars, cloud bands), an environment map made from it
// (so wet ground, cars and metal reflect the sky), a colour grade, light shafts under lamps and drifting dust.
import * as THREE from 'three';
import { scene, renderer, camera, grade } from './engine.js';
import { level } from './physics.js';

// ---- the look of each stage
const LOOKS = {
  //            sky zenith / horizon / city glow,       stars clouds  grade: shadows tint / highlights tint, saturation, contrast, dust
  lobby:   { top: 0x05040a, hor: 0x1c120c, glow: 0xff8a3a, stars: 0,   clouds: 0,   lo: [1.0, 0.92, 0.85], hi: [1.06, 1.0, 0.9], sat: 1.0, con: 1.06, dust: 1 },
  rooftop: { top: 0x070816, hor: 0x2a1424, glow: 0xff5a3a, stars: 0.8, clouds: 0.6, lo: [0.86, 0.9, 1.12], hi: [1.1, 0.98, 0.9], sat: 1.08, con: 1.08, dust: 0.4 },
  city:    { top: 0x080a18, hor: 0x2c1a14, glow: 0xff9a4a, stars: 0.5, clouds: 0.8, lo: [0.9, 0.92, 1.08], hi: [1.12, 1.0, 0.86], sat: 1.05, con: 1.06, dust: 0.5 },
  docks:   { top: 0x04080e, hor: 0x10202a, glow: 0x6ab4ff, stars: 0.9, clouds: 0.5, lo: [0.8, 0.98, 1.12], hi: [1.12, 1.0, 0.9], sat: 0.95, con: 1.1, dust: 0.3 },
  subway:  { top: 0x020302, hor: 0x0a0c08, glow: 0x9aff9a, stars: 0,   clouds: 0,   lo: [0.9, 1.06, 0.92], hi: [1.02, 1.05, 0.92], sat: 0.85, con: 1.1, dust: 1 },
  site:    { top: 0x0a0812, hor: 0x2a1a10, glow: 0xffa040, stars: 0.6, clouds: 0.7, lo: [0.95, 0.9, 0.85], hi: [1.12, 1.02, 0.84], sat: 0.95, con: 1.05, dust: 1.4 },
  market:  { top: 0x0c0412, hor: 0x2e0c16, glow: 0xff3a5a, stars: 0.3, clouds: 0.9, lo: [1.05, 0.86, 1.02], hi: [1.14, 0.96, 0.92], sat: 1.15, con: 1.06, dust: 0.6 },
  club:    { top: 0x04020a, hor: 0x120618, glow: 0xb050ff, stars: 0,   clouds: 0,   lo: [0.98, 0.86, 1.18], hi: [1.06, 0.96, 1.1], sat: 1.15, con: 1.1, dust: 0.8 },
};

// ---- sky dome
const skyMat = new THREE.ShaderMaterial({
  uniforms: {
    top: { value: new THREE.Color() }, hor: { value: new THREE.Color() }, glow: { value: new THREE.Color() },
    stars: { value: 0 }, clouds: { value: 0 }, time: { value: 0 }, moonDir: { value: new THREE.Vector3(-0.22, 0.34, -0.91).normalize() },
  },
  vertexShader: 'varying vec3 vDir; void main(){ vDir = normalize(position); vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0); gl_Position = p.xyww; }',
  fragmentShader: `
    uniform vec3 top, hor, glow; uniform float stars, clouds, time; uniform vec3 moonDir; varying vec3 vDir;
    float hash(vec3 p){ p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
    float noise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
      float a = hash(vec3(i, 1.0)), b = hash(vec3(i + vec2(1, 0), 1.0)), c = hash(vec3(i + vec2(0, 1), 1.0)), d = hash(vec3(i + 1.0, 1.0));
      return mix(mix(a, b, f.x), mix(c, d, f.x), f.y); }
    float fbm(vec2 p){ float v = 0.0, a = 0.5; for (int i = 0; i < 4; i++) { v += a * noise(p); p *= 2.03; a *= 0.5; } return v; }
    void main(){
      vec3 d = normalize(vDir); float h = d.y;
      vec3 col = mix(hor, top, smoothstep(-0.02, 0.55, h));
      col += glow * 0.55 * exp(-max(h, 0.0) * 9.0);                       // light pollution off the city
      if (stars > 0.0) { vec3 q = floor(d * 380.0); float s = step(0.9975, hash(q)) * smoothstep(0.05, 0.4, h); col += vec3(s) * stars * (0.6 + 0.4 * sin(time * 2.0 + hash(q + 3.0) * 40.0)); }
      if (clouds > 0.0 && h > 0.0) {                                       // dark cloud bands, lit from below by the city
        vec2 uv = d.xz / (h + 0.18) * 1.6 + vec2(time * 0.004, 0.0);
        float c = smoothstep(0.45, 0.85, fbm(uv)) * clouds * smoothstep(0.0, 0.25, h);
        col = mix(col, top * 0.6 + glow * 0.18 * exp(-h * 3.0), c * 0.85);
      }
      float m = max(dot(d, moonDir), 0.0);
      col += vec3(1.0, 0.92, 0.8) * (pow(m, 900.0) * 6.0 + pow(m, 30.0) * 0.12);  // moon disc and halo
      gl_FragColor = vec4(col, 1.0);
    }`,
  side: THREE.BackSide, depthWrite: false, depthTest: false, fog: false, // drawn first, behind everything
});
const sky = new THREE.Mesh(new THREE.SphereGeometry(500, 48, 24), skyMat);
sky.renderOrder = -1; sky.frustumCulled = false;
scene.add(sky);

// ---- environment map: the sky (dimmed) baked into a reflection probe, so glossy things pick up its colour
const pmrem = new THREE.PMREMGenerator(renderer);
let envRT = null;
function bakeEnvironment(l) {
  const envScene = new THREE.Scene();
  const dim = skyMat.clone(); dim.uniforms = THREE.UniformsUtils.clone(skyMat.uniforms);
  for (const k of ['top', 'hor', 'glow']) dim.uniforms[k].value.copy(skyMat.uniforms[k].value).multiplyScalar(0.28); // a hint of sky in glossy things, not a second ambient light
  dim.uniforms.stars.value = 0;
  envScene.add(new THREE.Mesh(new THREE.SphereGeometry(10, 32, 16), dim));
  // a few warm "street light" blobs low on the horizon give puddles something to mirror
  const blob = new THREE.MeshBasicMaterial({ color: new THREE.Color(l.glow).multiplyScalar(2.2) });
  for (let i = 0; i < 9; i++) { const a = i / 9 * Math.PI * 2; const m = new THREE.Mesh(new THREE.SphereGeometry(0.35, 8, 6), blob); m.position.set(Math.cos(a) * 9, 0.4 + (i % 3) * 0.5, Math.sin(a) * 9); envScene.add(m); }
  if (envRT) envRT.dispose();
  envRT = pmrem.fromScene(envScene, 0.02);
  scene.environment = envRT.texture;
  dim.dispose(); blob.dispose();
}

// ---- light shafts: soft additive cones under lamps, brightest at the lamp and fading to the ground
const shaftMat = new THREE.ShaderMaterial({
  uniforms: { color: { value: new THREE.Color(1, 0.7, 0.4) } },
  vertexShader: `varying float vH; varying vec3 vN; varying vec3 vV;
    void main(){ vH = uv.y; vec4 wp = modelMatrix * vec4(position, 1.0); vN = normalize(mat3(modelMatrix) * normal); vV = normalize(cameraPosition - wp.xyz); gl_Position = projectionMatrix * viewMatrix * wp; }`,
  fragmentShader: `uniform vec3 color; varying float vH; varying vec3 vN; varying vec3 vV;
    void main(){ float edge = pow(abs(dot(vN, vV)), 1.6); float a = edge * vH * vH * 0.16; gl_FragColor = vec4(color * a, a); }`,
  transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
});
/** A shaft of light from a lamp at (x, y, z) down to the ground below it. */
export function lightShaft(x, y, z, ground, radius = 2.6, color = 0xffb070) {
  const h = Math.max(1, y - ground);
  const geo = new THREE.CylinderGeometry(0.25, radius, h, 20, 1, true);
  geo.translate(0, -h / 2, 0);
  const mat = shaftMat.clone(); mat.uniforms.color.value = new THREE.Color(color);
  const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.renderOrder = 2;
  level.group.add(m);
  return m;
}

// ---- dust: motes drifting in the light around the camera
const DUST = 260;
const dustGeo = new THREE.BufferGeometry(), dustPos = new Float32Array(DUST * 3), dustSeed = [];
for (let i = 0; i < DUST; i++) dustSeed.push([Math.random() * 30 - 15, Math.random() * 10 - 2, Math.random() * 30 - 15, Math.random()]);
dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
const dustMat = new THREE.PointsMaterial({ color: 0xffd8b0, size: 0.05, transparent: true, opacity: 0.5, depthWrite: false, blending: THREE.AdditiveBlending });
const dust = new THREE.Points(dustGeo, dustMat); dust.frustumCulled = false; scene.add(dust);

let t = 0;
/** Set the stage's sky, reflections, grade and dust (called when a stage loads). */
export function applyAtmosphere(name) {
  const l = LOOKS[name] || LOOKS.city;
  skyMat.uniforms.top.value.setHex(l.top); skyMat.uniforms.hor.value.setHex(l.hor); skyMat.uniforms.glow.value.setHex(l.glow);
  skyMat.uniforms.stars.value = l.stars; skyMat.uniforms.clouds.value = l.clouds;
  if (scene.fog) scene.fog.color.setHex(l.hor).lerp(new THREE.Color(l.glow), 0.12); // distance fades into the horizon
  bakeEnvironment(l);
  grade.uniforms.lo.value.set(...l.lo); grade.uniforms.hi.value.set(...l.hi);
  grade.uniforms.sat.value = l.sat; grade.uniforms.con.value = l.con;
  dustMat.opacity = 0.45 * l.dust; dust.visible = l.dust > 0;
}
/** Once a frame: twinkle, drift the dust round the camera. */
export function updateAtmosphere(dt) {
  t += dt; skyMat.uniforms.time.value = t;
  sky.position.copy(camera.position);
  if (!dust.visible) return;
  const c = camera.position;
  for (let i = 0; i < DUST; i++) {
    const s = dustSeed[i];
    s[0] += Math.sin(t * 0.3 + s[3] * 9) * dt * 0.25; s[1] += Math.sin(t * 0.2 + s[3] * 5) * dt * 0.12; s[2] += dt * 0.15;
    const wrap = v => ((v + 15) % 30 + 30) % 30 - 15;
    dustPos[i * 3] = c.x + wrap(s[0]); dustPos[i * 3 + 1] = c.y + ((s[1] + 6) % 12 + 12) % 12 - 6; dustPos[i * 3 + 2] = c.z + wrap(s[2]);
  }
  dustGeo.attributes.position.needsUpdate = true;
}
