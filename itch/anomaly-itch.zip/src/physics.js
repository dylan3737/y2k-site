// Axis-aligned box collision and ray casts against the current level.

/** The loaded level's collision and spawn data. `info` holds the stage's name, start and camera settings. */
export const level = { boxes: [], spawns: [], floorY: 0, group: null, info: null };

/** Does a vertical capsule-ish box (radius r, height h, feet at pos) overlap box b? */
export function overlaps(pos, r, h, b) {
  return pos.x - r < b.max.x - 1e-4 && pos.x + r > b.min.x + 1e-4 &&
         pos.y < b.max.y - 1e-4 && pos.y + h > b.min.y + 1e-4 &&
         pos.z - r < b.max.z - 1e-4 && pos.z + r > b.min.z + 1e-4;
}

/** Move a body ({pos, vel, r, h}) by vel*dt, resolving one axis at a time. Returns true if it ended up standing on something. */
export function moveBody(o, dt) {
  let grounded = false;
  for (const ax of ['x', 'z', 'y']) {
    o.pos[ax] += o.vel[ax] * dt;
    for (const b of level.boxes) {
      if (!overlaps(o.pos, o.r, o.h, b)) continue;
      if (ax === 'y') {
        if (o.vel.y <= 0) { o.pos.y = b.max.y; grounded = true; } else o.pos.y = b.min.y - o.h;
        o.vel.y = 0;
      } else {
        const c = (b.min[ax] + b.max[ax]) / 2;
        const dir = o.vel[ax] !== 0 ? Math.sign(o.vel[ax]) : Math.sign(c - o.pos[ax]);
        o.pos[ax] = dir > 0 ? b.min[ax] - o.r - 1e-3 : b.max[ax] + o.r + 1e-3;
        o.vel[ax] = 0;
      }
    }
  }
  if (o.pos.y <= level.floorY) { o.pos.y = level.floorY; if (o.vel.y < 0) o.vel.y = 0; grounded = true; }
  return grounded;
}

/** Slab test. Returns the hit distance along unit ray d, or Infinity. */
export function rayAABB(o, d, mnx, mny, mnz, mxx, mxy, mxz, maxT) {
  let t0 = 0, t1 = maxT;
  const O = [o.x, o.y, o.z], D = [d.x, d.y, d.z], MN = [mnx, mny, mnz], MX = [mxx, mxy, mxz];
  for (let i = 0; i < 3; i++) {
    if (Math.abs(D[i]) < 1e-9) { if (O[i] < MN[i] || O[i] > MX[i]) return Infinity; continue; }
    let a = (MN[i] - O[i]) / D[i], b = (MX[i] - O[i]) / D[i];
    if (a > b) { const t = a; a = b; b = t; }
    if (a > t0) t0 = a;
    if (b < t1) t1 = b;
    if (t0 > t1) return Infinity;
  }
  return t0;
}

/** Distance to the first level surface along the ray, capped at maxT. */
export function rayWorld(o, d, maxT) {
  let t = maxT;
  if (d.y < 0 && level.floorY > -1e3) { const tf = (level.floorY - o.y) / d.y; if (tf < t) t = tf; }
  for (const b of level.boxes) { const tb = rayAABB(o, d, b.min.x, b.min.y, b.min.z, b.max.x, b.max.y, b.max.z, t); if (tb < t) t = tb; }
  return t;
}

/** Is there something to stand on at (x, z) near height y? Always true on stages with a floor. */
export function groundBelow(x, z, y) {
  if (level.floorY > -1e3) return true;
  for (const b of level.boxes) if (x > b.min.x && x < b.max.x && z > b.min.z && z < b.max.z && b.max.y <= y + 0.5 && b.max.y >= y - 2.5) return true;
  return false;
}
