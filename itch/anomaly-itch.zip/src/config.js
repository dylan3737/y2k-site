// Gameplay tuning and content tables. Change numbers here, not in the systems.

export const T = {
  gravity: 24,
  // movement
  runSpeed: 9.5,
  groundAccel: 14,
  airAccel: 24,
  jump: 8.6,
  airJump: 8.2,
  coyote: 0.12,
  wallRunTime: 2,
  wallRunSpeed: 10.5,
  wallKick: 8.5,
  climbTime: 3.3,        // seconds of climbing per trip off the ground (~30 m)
  climbSpeed: 9.5,
  vaultUp: 7.6,
  vaultPush: 5.5,
  diveSpeed: 12.5,
  diveLift: 5.4,
  diveTime: 1.6,
  slamSpeed: 22,         // falling faster than this slams the ground on landing (a drop of about 10 m)
  surfTime: 4.5,
  // time
  slowFocus: 0.2,
  slowDive: 0.3,
  slowDead: 0.15,
  focusMin: 15,
  focusDrain: 20,
  focusRegen: 4.5,
  // weapons
  magSize: 24,
  reloadTime: 1.1,
  fireEvery: 0.12,
  rapidEvery: 0.06,
  bodyDamage: 34,
  headDamage: 150,
  slashDamage: 140,   // one basic cut kills a grunt at any wave (their health tops out at 140)
  slashTime: 0.2,
  slashCooldown: 0.35,
  dashCooldown: 5,    // seconds before the next dash-cut can charge
  hpGrowthWaves: 20,  // enemy health stops growing after this wave, so headshots always one-shot a grunt
  deflectSpeed: 55,   // bullets you bat back fly faster than they came
  deflectDamage: 120,
  enemyBulletSpeed: 34,
  // scoring
  comboWindow: 4,
  firstExtraLife: 25000,
  extraLifeEvery: 40000,
  startLives: 3,
  maxContinues: 3,   // continues allowed per run
  startHellfire: 2,
};

// indexed by chain length: a single kill has no name
export const CHAIN_NAMES = [null, null, 'DOUBLE TAP', 'TRIPLE THREAT', 'MINCEMEAT', 'GROUND BEEF', 'MEAT GRINDER', 'SLAUGHTERHOUSE', 'BUTCHER SHOP', 'CARNAGE!!'];

export const POWER = {
  rapid: { label: 'RAPID FIRE', color: [3, 2.4, 0.6] },
  spread: { label: 'SPREAD SHOT', color: [3, 0.9, 2.4] },
  pierce: { label: 'PIERCE', color: [0.6, 2.2, 3.2] },
};

export const PICKUPS = {
  health: { label: '+40 HEALTH', color: [3.2, 0.35, 0.3], cls: 'red' },
  focus: { label: '+50 FOCUS', color: [3, 2.2, 0.5], cls: 'gold' },
  rapid: { label: 'RAPID FIRE', color: POWER.rapid.color, cls: 'gold' },
  spread: { label: 'SPREAD SHOT', color: POWER.spread.color, cls: 'gold' },
  pierce: { label: 'PIERCE', color: POWER.pierce.color, cls: 'cyan' },
  hellfire: { label: '+1 HELLFIRE', color: [3.2, 1.0, 0.2], cls: 'gold' },
  life: { label: '1UP', color: [3.2, 3.2, 3.2], cls: 'gold' },
};
export const DROP_TABLE = [['health', 30], ['focus', 18], ['rapid', 14], ['spread', 14], ['pierce', 12], ['hellfire', 9], ['life', 3]];
export const DROP_CHANCE = 0.3;

// Stage order; the game rotates through them every five waves.
/**
 * Wave difficulty. Health grows slowly and stops at wave 20 (headshots stay one-shots);
 * past wave 10 the pressure keeps rising through numbers, fire rate, accuracy and damage instead.
 */
export const difficulty = w => {
  const late = Math.max(0, w - 10);
  return {
    hp: 100 + Math.min(w, T.hpGrowthWaves) * 2,                              // grunt health: 102 at wave 1, 140 from wave 20
    maxAlive: Math.min(12, Math.min(2 + w, 8) + Math.floor(late / 3)),       // on screen at once: 8 by wave 6, then +1 every 3 waves, up to 12
    pace: w <= 10 ? 1 - w * 0.05 : Math.max(0.32, 0.5 - late * 0.015),     // time between enemy shots (multiplier)
    aim: Math.max(0.6, 1 - late * 0.025),                                    // enemy spread multiplier: tighter late on
    damage: Math.min(7 + 2 * w, 22) + Math.min(12, late * 0.8),              // per enemy round: 22 by wave 8, up to 34
  };
};

export const STAGES = ['lobby', 'rooftop', 'city', 'docks', 'subway', 'site', 'market', 'club'];
export const DEFAULT_STAGE = 2;

export const DEFAULT_SCORES = [
  { n: 'ACE', s: 50000 }, { n: 'RIP', s: 30000 }, { n: 'GOR', s: 20000 }, { n: 'VEX', s: 10000 }, { n: 'KAT', s: 5000 },
];
